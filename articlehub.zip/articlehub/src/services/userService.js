import { supabase } from '../lib/supabase';

export const userService = {
  async getUserProfile(userId) {
    try {
      const { data, error } = await supabase?.from('user_profiles')?.select('*')?.eq('id', userId)?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      throw error;
    }
  },

  async getUserByUsername(username) {
    try {
      const { data, error } = await supabase?.from('user_profiles')?.select('*')?.eq('username', username)?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error fetching user by username:', error);
      throw error;
    }
  },

  async updateUserProfile(userId, profileData) {
    try {
      const { data, error } = await supabase?.from('user_profiles')?.update({
          ...profileData,
          updated_at: new Date()?.toISOString()
        })?.eq('id', userId)?.select()?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  },

  async followUser(userId) {
    try {
      const { data, error } = await supabase?.from('follows')?.insert([{ following_id: userId }])?.select()?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error following user:', error);
      throw error;
    }
  },

  async unfollowUser(userId) {
    try {
      const { error } = await supabase?.from('follows')?.delete()?.eq('following_id', userId);
      
      if (error) {
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Error unfollowing user:', error);
      throw error;
    }
  },

  async getFollowStatus(userId) {
    try {
      const { data, error } = await supabase?.from('follows')?.select('id')?.eq('following_id', userId)?.single();
      
      if (error && error?.code !== 'PGRST116') {
        throw new Error(error.message);
      }
      
      return !!data;
    } catch (error) {
      console.error('Error checking follow status:', error);
      return false;
    }
  },

  async getUserFollowers(userId) {
    try {
      const { data, error } = await supabase?.from('follows')?.select(`
          id,
          created_at,
          follower:user_profiles!follows_follower_id_fkey(
            id, full_name, username, avatar_url, bio
          )
        `)?.eq('following_id', userId)?.order('created_at', { ascending: false });
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error) {
      console.error('Error fetching followers:', error);
      throw error;
    }
  },

  async getUserFollowing(userId) {
    try {
      const { data, error } = await supabase?.from('follows')?.select(`
          id,
          created_at,
          following:user_profiles!follows_following_id_fkey(
            id, full_name, username, avatar_url, bio
          )
        `)?.eq('follower_id', userId)?.order('created_at', { ascending: false });
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error) {
      console.error('Error fetching following:', error);
      throw error;
    }
  },

  async uploadAvatar(userId, file) {
    try {
      const fileExt = file?.name?.split('.')?.pop();
      const fileName = `${userId}/avatar.${fileExt}`;

      const { data, error } = await supabase?.storage?.from('user-avatars')?.upload(fileName, file, {
          upsert: true
        });

      if (error) {
        throw new Error(error.message);
      }

      const { data: { publicUrl } } = supabase?.storage?.from('user-avatars')?.getPublicUrl(fileName);

      // Update user profile with new avatar URL
      await this.updateUserProfile(userId, {
        avatar_url: publicUrl
      });

      return publicUrl;
    } catch (error) {
      console.error('Error uploading avatar:', error);
      throw error;
    }
  }
};