import { supabase } from '../lib/supabase';

export const commentService = {
  async getArticleComments(articleId) {
    try {
      const { data, error } = await supabase?.from('comments')?.select(`
          *,
          author:user_profiles(id, full_name, username, avatar_url),
          replies:comments(
            *,
            author:user_profiles(id, full_name, username, avatar_url)
          )
        `)?.eq('article_id', articleId)?.eq('status', 'visible')?.is('parent_comment_id', null)?.order('created_at', { ascending: false });
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error) {
      console.error('Error fetching comments:', error);
      throw error;
    }
  },

  async createComment(commentData) {
    try {
      const { data, error } = await supabase?.from('comments')?.insert([commentData])?.select(`
          *,
          author:user_profiles(id, full_name, username, avatar_url)
        `)?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error creating comment:', error);
      throw error;
    }
  },

  async updateComment(commentId, content) {
    try {
      const { data, error } = await supabase?.from('comments')?.update({
          content,
          updated_at: new Date()?.toISOString()
        })?.eq('id', commentId)?.select(`
          *,
          author:user_profiles(id, full_name, username, avatar_url)
        `)?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error updating comment:', error);
      throw error;
    }
  },

  async deleteComment(commentId) {
    try {
      const { error } = await supabase?.from('comments')?.delete()?.eq('id', commentId);
      
      if (error) {
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Error deleting comment:', error);
      throw error;
    }
  },

  async toggleCommentLike(commentId) {
    try {
      // Check if user already liked this comment
      const { data: existingLike } = await supabase?.from('likes')?.select('id')?.eq('comment_id', commentId)?.single();

      if (existingLike) {
        // Unlike
        const { error } = await supabase?.from('likes')?.delete()?.eq('comment_id', commentId);
        
        if (error) throw new Error(error.message);
        return false;
      } else {
        // Like
        const { error } = await supabase?.from('likes')?.insert([{ comment_id: commentId }]);
        
        if (error) throw new Error(error.message);
        return true;
      }
    } catch (error) {
      console.error('Error toggling comment like:', error);
      throw error;
    }
  }
};