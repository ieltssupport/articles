import { supabase } from '../lib/supabase';

export const categoryService = {
  async getAllCategories() {
    try {
      const { data, error } = await supabase?.from('categories')?.select('*')?.order('name');
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error) {
      console.error('Error fetching categories:', error);
      throw error;
    }
  },

  async getCategoryBySlug(slug) {
    try {
      const { data, error } = await supabase?.from('categories')?.select('*')?.eq('slug', slug)?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error fetching category:', error);
      throw error;
    }
  },

  async createCategory(categoryData) {
    try {
      const slug = categoryData?.name?.toLowerCase()?.replace(/[^a-z0-9]+/g, '-')?.replace(/(^-|-$)/g, '');

      const { data, error } = await supabase?.from('categories')?.insert([{
          ...categoryData,
          slug
        }])?.select()?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error creating category:', error);
      throw error;
    }
  },

  async updateCategory(id, categoryData) {
    try {
      const { data, error } = await supabase?.from('categories')?.update(categoryData)?.eq('id', id)?.select()?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error updating category:', error);
      throw error;
    }
  },

  async deleteCategory(id) {
    try {
      const { error } = await supabase?.from('categories')?.delete()?.eq('id', id);
      
      if (error) {
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Error deleting category:', error);
      throw error;
    }
  }
};