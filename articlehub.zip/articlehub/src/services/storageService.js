import { supabase } from '../lib/supabase';

export const storageService = {
  async uploadArticleImage(file, articleId = null) {
    try {
      const fileExt = file?.name?.split('.')?.pop();
      const fileName = articleId 
        ? `articles/${articleId}/${Date.now()}.${fileExt}`
        : `uploads/${Date.now()}.${fileExt}`;

      const { data, error } = await supabase?.storage?.from('article-images')?.upload(fileName, file);

      if (error) {
        throw new Error(error.message);
      }

      const { data: { publicUrl } } = supabase?.storage?.from('article-images')?.getPublicUrl(fileName);

      return {
        path: data?.path,
        url: publicUrl
      };
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  },

  async deleteArticleImage(path) {
    try {
      const { error } = await supabase?.storage?.from('article-images')?.remove([path]);

      if (error) {
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Error deleting image:', error);
      throw error;
    }
  },

  async uploadUserAvatar(userId, file) {
    try {
      const fileExt = file?.name?.split('.')?.pop();
      const fileName = `${userId}/avatar.${fileExt}`;

      const { data, error } = await supabase?.storage?.from('user-avatars')?.upload(fileName, file, {
          upsert: true
        });

      if (error) {
        throw new Error(error.message);
      }

      const { data: { publicUrl } } = supabase?.storage?.from('user-avatars')?.getPublicUrl(fileName);

      return {
        path: data?.path,
        url: publicUrl
      };
    } catch (error) {
      console.error('Error uploading avatar:', error);
      throw error;
    }
  },

  getPublicUrl(bucket, path) {
    const { data: { publicUrl } } = supabase?.storage?.from(bucket)?.getPublicUrl(path);
    
    return publicUrl;
  }
};