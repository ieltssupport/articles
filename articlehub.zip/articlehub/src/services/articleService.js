import { supabase } from '../lib/supabase';

export const articleService = {
  async getAllArticles(filters = {}) {
    try {
      let query = supabase?.from('articles')?.select(`
          *,
          author:user_profiles(id, full_name, username, avatar_url),
          category:categories(id, name, slug, color),
          article_tags(
            tag:tags(id, name, slug)
          )
        `)?.eq('status', 'published')?.order('published_at', { ascending: false });

      if (filters?.category) {
        query = query?.eq('category_id', filters?.category);
      }

      if (filters?.author) {
        query = query?.eq('author_id', filters?.author);
      }

      if (filters?.search) {
        query = query?.or(`title.ilike.%${filters?.search}%,excerpt.ilike.%${filters?.search}%`);
      }

      if (filters?.tag) {
        query = query?.in('id', 
          supabase?.from('article_tags')?.select('article_id')?.eq('tag_id', filters?.tag)
        );
      }

      if (filters?.limit) {
        query = query?.limit(filters?.limit);
      }

      const { data, error } = await query;
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error) {
      console.error('Error fetching articles:', error);
      throw error;
    }
  },

  async getArticleBySlug(slug) {
    try {
      const { data, error } = await supabase?.from('articles')?.select(`
          *,
          author:user_profiles(id, full_name, username, avatar_url, bio),
          category:categories(id, name, slug, color),
          article_tags(
            tag:tags(id, name, slug)
          )
        `)?.eq('slug', slug)?.eq('status', 'published')?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error fetching article:', error);
      throw error;
    }
  },

  async getUserArticles(userId, status = 'all') {
    try {
      let query = supabase?.from('articles')?.select(`
          *,
          category:categories(id, name, slug, color),
          article_tags(
            tag:tags(id, name, slug)
          )
        `)?.eq('author_id', userId)?.order('created_at', { ascending: false });

      if (status !== 'all') {
        query = query?.eq('status', status);
      }

      const { data, error } = await query;
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error) {
      console.error('Error fetching user articles:', error);
      throw error;
    }
  },

  async createArticle(articleData) {
    try {
      const slug = articleData?.title?.toLowerCase()?.replace(/[^a-z0-9]+/g, '-')?.replace(/(^-|-$)/g, '');

      const { data, error } = await supabase?.from('articles')?.insert([{
          ...articleData,
          slug: `${slug}-${Date.now()}` // Add timestamp to ensure uniqueness
        }])?.select()?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error creating article:', error);
      throw error;
    }
  },

  async updateArticle(id, articleData) {
    try {
      const { data, error } = await supabase?.from('articles')?.update({
          ...articleData,
          updated_at: new Date()?.toISOString()
        })?.eq('id', id)?.select()?.single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error updating article:', error);
      throw error;
    }
  },

  async deleteArticle(id) {
    try {
      const { error } = await supabase?.from('articles')?.delete()?.eq('id', id);
      
      if (error) {
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Error deleting article:', error);
      throw error;
    }
  },

  async toggleLike(articleId) {
    try {
      // Check if user already liked this article
      const { data: existingLike } = await supabase?.from('likes')?.select('id')?.eq('article_id', articleId)?.single();

      if (existingLike) {
        // Unlike
        const { error } = await supabase?.from('likes')?.delete()?.eq('article_id', articleId);
        
        if (error) throw new Error(error.message);
        return false;
      } else {
        // Like
        const { error } = await supabase?.from('likes')?.insert([{ article_id: articleId }]);
        
        if (error) throw new Error(error.message);
        return true;
      }
    } catch (error) {
      console.error('Error toggling like:', error);
      throw error;
    }
  },

  async toggleBookmark(articleId) {
    try {
      // Check if user already bookmarked this article
      const { data: existingBookmark } = await supabase?.from('bookmarks')?.select('id')?.eq('article_id', articleId)?.single();

      if (existingBookmark) {
        // Remove bookmark
        const { error } = await supabase?.from('bookmarks')?.delete()?.eq('article_id', articleId);
        
        if (error) throw new Error(error.message);
        return false;
      } else {
        // Add bookmark
        const { error } = await supabase?.from('bookmarks')?.insert([{ article_id: articleId }]);
        
        if (error) throw new Error(error.message);
        return true;
      }
    } catch (error) {
      console.error('Error toggling bookmark:', error);
      throw error;
    }
  },

  async getUserBookmarks(userId) {
    try {
      const { data, error } = await supabase?.from('bookmarks')?.select(`
          id,
          created_at,
          article:articles(
            *,
            author:user_profiles(id, full_name, username, avatar_url),
            category:categories(id, name, slug, color)
          )
        `)?.eq('user_id', userId)?.order('created_at', { ascending: false });
      
      if (error) {
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error) {
      console.error('Error fetching bookmarks:', error);
      throw error;
    }
  },

  async incrementViewCount(articleId) {
    try {
      const { error } = await supabase?.from('articles')?.update({ 
          views_count: supabase?.raw('views_count + 1') 
        })?.eq('id', articleId);
      
      if (error) {
        console.error('Error incrementing view count:', error);
      }
    } catch (error) {
      console.error('Error incrementing view count:', error);
    }
  }
};