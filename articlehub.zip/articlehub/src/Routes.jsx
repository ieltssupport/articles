import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import ArticleFeedHome from './pages/article-feed-home';
import SearchResults from './pages/search-results';
import ArticleEditor from './pages/article-editor';
import LoginRegister from './pages/login-register';
import async from './pages/article-detail-reading';
import UserProfile from './pages/user-profile';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<async />} />
        <Route path="/article-feed-home" element={<ArticleFeedHome />} />
        <Route path="/search-results" element={<SearchResults />} />
        <Route path="/article-editor" element={<ArticleEditor />} />
        <Route path="/login-register" element={<LoginRegister />} />
        <Route path="/article-detail-reading" element={<async />} />
        <Route path="/user-profile" element={<UserProfile />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
