import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useAuth } from '../../contexts/AuthContext';
import { userService } from '../../services/userService';
import { articleService } from '../../services/articleService';
import ProfileHeader from './components/ProfileHeader';
import ProfileTabs from './components/ProfileTabs';
import ProfileStats from './components/ProfileStats';
import ArticleGrid from './components/ArticleGrid';
import ActivityFeed from './components/ActivityFeed';
import BookmarkSection from './components/BookmarkSection';

export default function UserProfilePage() {
  const { username } = useParams();
  const navigate = useNavigate();
  const { user, profile: currentUserProfile } = useAuth();
  
  const [profileUser, setProfileUser] = useState(null);
  const [userArticles, setUserArticles] = useState([]);
  const [bookmarks, setBookmarks] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('articles');
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);

  const isOwnProfile = user && profileUser && user?.id === profileUser?.id;

  useEffect(() => {
    if (username) {
      loadUserProfile();
    } else if (user) {
      // If no username provided, redirect to current user's profile
      navigate(`/profile/${currentUserProfile?.username || 'me'}`);
    } else {
      navigate('/login-register');
    }
  }, [username, user, currentUserProfile, navigate]);

  const loadUserProfile = async () => {
    setLoading(true);
    try {
      const userData = await userService?.getUserByUsername(username);
      setProfileUser(userData);

      // Load user's articles
      const articlesData = await articleService?.getUserArticles(userData?.id, isOwnProfile ? 'all' : 'published');
      setUserArticles(articlesData);

      // Load bookmarks if it's the current user's profile
      if (isOwnProfile) {
        const bookmarksData = await articleService?.getUserBookmarks(userData?.id);
        setBookmarks(bookmarksData);
      }

      // Load followers and following
      const [followersData, followingData] = await Promise.all([
        userService?.getUserFollowers(userData?.id),
        userService?.getUserFollowing(userData?.id)
      ]);
      setFollowers(followersData);
      setFollowing(followingData);

      // Check if current user follows this profile user
      if (user && !isOwnProfile) {
        const followStatus = await userService?.getFollowStatus(userData?.id);
        setIsFollowing(followStatus);
      }
    } catch (err) {
      setError('User not found');
      console.error('Error loading user profile:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFollow = async () => {
    if (!user || followLoading) return;

    setFollowLoading(true);
    try {
      if (isFollowing) {
        await userService?.unfollowUser(profileUser?.id);
        setIsFollowing(false);
        setFollowers(prev => prev?.filter(f => f?.follower?.id !== user?.id));
      } else {
        await userService?.followUser(profileUser?.id);
        setIsFollowing(true);
        setFollowers(prev => [...prev, { 
          id: Date.now(), 
          follower: {
            id: user?.id,
            full_name: currentUserProfile?.full_name,
            username: currentUserProfile?.username,
            avatar_url: currentUserProfile?.avatar_url
          }
        }]);
      }
    } catch (err) {
      console.error('Error toggling follow:', err);
    } finally {
      setFollowLoading(false);
    }
  };

  const handleProfileUpdate = (updatedProfile) => {
    setProfileUser(prev => ({ ...prev, ...updatedProfile }));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (error || !profileUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">User Not Found</h2>
          <p className="text-gray-600 mb-6">
            The user profile you're looking for doesn't exist.
          </p>
          <button
            onClick={() => navigate('/')}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  }

  const stats = {
    articles: userArticles?.length || 0,
    followers: followers?.length || 0,
    following: following?.length || 0
  };

  return (
    <>
      <Helmet>
        <title>{profileUser?.full_name} (@{profileUser?.username}) | ArticleHub</title>
        <meta name="description" content={profileUser?.bio || `${profileUser?.full_name}'s profile on ArticleHub`} />
        <meta property="og:title" content={`${profileUser?.full_name} (@${profileUser?.username})`} />
        <meta property="og:description" content={profileUser?.bio || `${profileUser?.full_name}'s profile on ArticleHub`} />
        <meta property="og:type" content="profile" />
        {profileUser?.avatar_url && (
          <meta property="og:image" content={profileUser?.avatar_url} />
        )}
      </Helmet>
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            {/* Profile Header */}
            <ProfileHeader
              user={profileUser}
              stats={stats}
              isOwnProfile={isOwnProfile}
              isFollowing={isFollowing}
              followLoading={followLoading}
              onFollow={handleFollow}
              onUpdate={handleProfileUpdate}
              onEditProfile={handleProfileUpdate}
              onAvatarUpload={handleProfileUpdate}
            />

            {/* Profile Stats */}
            <div className="mt-8">
              <ProfileStats stats={stats} />
            </div>

            {/* Profile Tabs */}
            <div className="mt-8">
              <ProfileTabs
                activeTab={activeTab}
                onTabChange={setActiveTab}
                isOwnProfile={isOwnProfile}
                stats={stats}
              />
            </div>

            {/* Tab Content */}
            <div className="mt-8">
              {activeTab === 'articles' && (
                <ArticleGrid
                  articles={userArticles}
                  isOwnProfile={isOwnProfile}
                  onArticleUpdate={(updatedArticle) => {
                    setUserArticles(prev =>
                      prev?.map(article =>
                        article?.id === updatedArticle?.id ? updatedArticle : article
                      )
                    );
                  }}
                />
              )}

              {activeTab === 'bookmarks' && isOwnProfile && (
                <BookmarkSection
                  bookmarks={bookmarks}
                  onBookmarkRemove={(bookmarkId) => {
                    setBookmarks(prev => prev?.filter(b => b?.id !== bookmarkId));
                  }}
                />
              )}

              {activeTab === 'activity' && (
                <ActivityFeed
                  userId={profileUser?.id}
                  isOwnProfile={isOwnProfile}
                  activities={[]}
                />
              )}

              {activeTab === 'followers' && (
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Followers ({followers?.length || 0})
                  </h3>
                  {followers?.length > 0 ? (
                    <div className="space-y-4">
                      {followers?.map((follow) => (
                        <div key={follow?.id} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden">
                              {follow?.follower?.avatar_url ? (
                                <img
                                  src={follow?.follower?.avatar_url}
                                  alt={follow?.follower?.full_name}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-semibold">
                                  {follow?.follower?.full_name?.charAt(0)?.toUpperCase()}
                                </div>
                              )}
                            </div>
                            <div>
                              <div className="font-medium text-gray-900">
                                {follow?.follower?.full_name}
                              </div>
                              <div className="text-sm text-gray-500">
                                @{follow?.follower?.username}
                              </div>
                            </div>
                          </div>
                          <button
                            onClick={() => navigate(`/profile/${follow?.follower?.username}`)}
                            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                          >
                            View Profile
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center py-8">No followers yet.</p>
                  )}
                </div>
              )}

              {activeTab === 'following' && (
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Following ({following?.length || 0})
                  </h3>
                  {following?.length > 0 ? (
                    <div className="space-y-4">
                      {following?.map((follow) => (
                        <div key={follow?.id} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden">
                              {follow?.following?.avatar_url ? (
                                <img
                                  src={follow?.following?.avatar_url}
                                  alt={follow?.following?.full_name}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-semibold">
                                  {follow?.following?.full_name?.charAt(0)?.toUpperCase()}
                                </div>
                              )}
                            </div>
                            <div>
                              <div className="font-medium text-gray-900">
                                {follow?.following?.full_name}
                              </div>
                              <div className="text-sm text-gray-500">
                                @{follow?.following?.username}
                              </div>
                            </div>
                          </div>
                          <button
                            onClick={() => navigate(`/profile/${follow?.following?.username}`)}
                            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                          >
                            View Profile
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center py-8">Not following anyone yet.</p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}