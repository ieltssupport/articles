import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ActivityFeed = ({ activities, isOwnProfile = false }) => {
  const [filter, setFilter] = useState('all');

  const filterOptions = [
    { id: 'all', label: 'All Activity', icon: 'Activity' },
    { id: 'likes', label: 'Likes', icon: 'Heart' },
    { id: 'comments', label: 'Comments', icon: 'MessageCircle' },
    { id: 'follows', label: 'Follows', icon: 'UserPlus' },
    { id: 'articles', label: 'Articles', icon: 'FileText' }
  ];

  const filteredActivities = activities?.filter(activity => 
    filter === 'all' || activity?.type === filter
  );

  const getActivityIcon = (type) => {
    const iconMap = {
      like: 'Heart',
      comment: 'MessageCircle',
      follow: 'UserPlus',
      article: 'FileText',
      bookmark: 'Bookmark'
    };
    return iconMap?.[type] || 'Activity';
  };

  const getActivityColor = (type) => {
    const colorMap = {
      like: 'text-red-500',
      comment: 'text-blue-500',
      follow: 'text-green-500',
      article: 'text-purple-500',
      bookmark: 'text-yellow-500'
    };
    return colorMap?.[type] || 'text-muted-foreground';
  };

  const formatActivityText = (activity) => {
    switch (activity?.type) {
      case 'like':
        return `liked the article "${activity?.articleTitle}"`;
      case 'comment':
        return `commented on "${activity?.articleTitle}"`;
      case 'follow':
        return `started following ${activity?.targetUser}`;
      case 'article':
        return `published "${activity?.articleTitle}"`;
      case 'bookmark':
        return `bookmarked "${activity?.articleTitle}"`;
      default:
        return activity?.description;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else if (diffInHours < 168) {
      return `${Math.floor(diffInHours / 24)}d ago`;
    } else {
      return date?.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    }
  };

  if (!activities || activities?.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Activity" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">No activity yet</h3>
        <p className="text-muted-foreground">
          {isOwnProfile ? "Your activity will appear here as you interact with articles." : "This user hasn't been active recently."}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Activity Filters */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2">
        {filterOptions?.map((option) => (
          <button
            key={option?.id}
            onClick={() => setFilter(option?.id)}
            className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap transition-colors ${
              filter === option?.id
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            <Icon name={option?.icon} size={16} />
            <span>{option?.label}</span>
          </button>
        ))}
      </div>
      {/* Activity List */}
      {filteredActivities?.length === 0 ? (
        <div className="text-center py-8">
          <Icon name="Filter" size={24} className="text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">No activities found for the selected filter.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredActivities?.map((activity) => (
            <div key={activity?.id} className="bg-card border border-border rounded-lg p-4 hover:bg-muted/20 transition-colors">
              <div className="flex items-start space-x-3">
                {/* Activity Icon */}
                <div className={`w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0 ${getActivityColor(activity?.type)}`}>
                  <Icon name={getActivityIcon(activity?.type)} size={16} />
                </div>

                {/* Activity Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-foreground">
                        <span className="font-medium">
                          {isOwnProfile ? 'You' : activity?.userName}
                        </span>{' '}
                        {formatActivityText(activity)}
                      </p>
                      
                      {activity?.comment && (
                        <div className="mt-2 p-3 bg-muted/50 rounded-md">
                          <p className="text-sm text-muted-foreground italic">
                            "{activity?.comment}"
                          </p>
                        </div>
                      )}
                      
                      <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                        <span>{formatDate(activity?.createdAt)}</span>
                        {activity?.articleId && (
                          <button className="hover:text-primary transition-colors">
                            View Article
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Activity Thumbnail */}
                    {activity?.thumbnail && (
                      <div className="w-12 h-12 bg-muted rounded-md overflow-hidden ml-3 flex-shrink-0">
                        <Image
                          src={activity?.thumbnail}
                          alt="Activity thumbnail"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {/* Load More */}
      {filteredActivities?.length >= 10 && (
        <div className="text-center">
          <Button variant="outline">
            Load More Activity
          </Button>
        </div>
      )}
    </div>
  );
};

export default ActivityFeed;