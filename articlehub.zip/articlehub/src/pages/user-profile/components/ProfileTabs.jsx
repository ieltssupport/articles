import React from 'react';
import Icon from '../../../components/AppIcon';

const ProfileTabs = ({ 
  activeTab, 
  onTabChange, 
  isOwnProfile = false,
  articleCount = 0,
  draftCount = 0,
  bookmarkCount = 0 
}) => {
  const tabs = [
    {
      id: 'articles',
      label: 'Published',
      icon: 'FileText',
      count: articleCount,
      visible: true
    },
    {
      id: 'drafts',
      label: 'Drafts',
      icon: 'Edit3',
      count: draftCount,
      visible: isOwnProfile
    },
    {
      id: 'bookmarks',
      label: 'Bookmarks',
      icon: 'Bookmark',
      count: bookmarkCount,
      visible: isOwnProfile
    },
    {
      id: 'activity',
      label: 'Activity',
      icon: 'Activity',
      visible: true
    }
  ];

  const visibleTabs = tabs?.filter(tab => tab?.visible);

  return (
    <div className="bg-card border border-border rounded-lg mb-6 overflow-hidden">
      <div className="flex overflow-x-auto">
        {visibleTabs?.map((tab) => (
          <button
            key={tab?.id}
            onClick={() => onTabChange(tab?.id)}
            className={`flex items-center space-x-2 px-4 md:px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              activeTab === tab?.id
                ? 'border-primary text-primary bg-primary/5' :'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/50'
            }`}
          >
            <Icon name={tab?.icon} size={16} />
            <span>{tab?.label}</span>
            {typeof tab?.count === 'number' && (
              <span className={`px-2 py-0.5 rounded-full text-xs ${
                activeTab === tab?.id
                  ? 'bg-primary/20 text-primary' :'bg-muted text-muted-foreground'
              }`}>
                {tab?.count}
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ProfileTabs;