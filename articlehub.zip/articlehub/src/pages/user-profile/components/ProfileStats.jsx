import React from 'react';
import Icon from '../../../components/AppIcon';

const ProfileStats = ({ stats, isOwnProfile = false }) => {
  const statItems = [
    {
      label: 'Followers',
      value: stats?.followers || 0,
      icon: 'Users',
      key: 'followers'
    },
    {
      label: 'Following',
      value: stats?.following || 0,
      icon: 'UserPlus',
      key: 'following'
    },
    {
      label: 'Articles',
      value: stats?.articles || 0,
      icon: 'FileText',
      key: 'articles'
    },
    {
      label: 'Total Likes',
      value: stats?.totalLikes || 0,
      icon: 'Heart',
      key: 'totalLikes'
    }
  ];

  const formatNumber = (num) => {
    if (num >= 1000000) {
      return (num / 1000000)?.toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000)?.toFixed(1) + 'K';
    }
    return num?.toString();
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 md:p-6 mb-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {statItems?.map((item) => (
          <div key={item?.key} className="text-center">
            <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-full mx-auto mb-2">
              <Icon name={item?.icon} size={20} className="text-primary" />
            </div>
            <div className="text-2xl font-bold text-foreground mb-1">
              {formatNumber(item?.value)}
            </div>
            <div className="text-sm text-muted-foreground">
              {item?.label}
            </div>
          </div>
        ))}
      </div>
      {isOwnProfile && (
        <div className="mt-6 pt-4 border-t border-border">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Profile Views</span>
              <span className="font-medium">{formatNumber(stats?.profileViews || 0)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Article Views</span>
              <span className="font-medium">{formatNumber(stats?.articleViews || 0)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Engagement Rate</span>
              <span className="font-medium">{(stats?.engagementRate || 0)?.toFixed(1)}%</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileStats;