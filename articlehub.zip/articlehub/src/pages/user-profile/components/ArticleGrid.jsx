import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ArticleGrid = ({ 
  articles, 
  isOwnProfile = false, 
  onEditArticle, 
  onDeleteArticle,
  onNavigateToArticle 
}) => {
  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatReadTime = (minutes) => {
    return minutes < 1 ? '< 1 min read' : `${Math.round(minutes)} min read`;
  };

  if (!articles || articles?.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="FileText" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">No articles yet</h3>
        <p className="text-muted-foreground mb-6">
          {isOwnProfile ? "Start writing your first article!" : "This author hasn't published any articles yet."}
        </p>
        {isOwnProfile && (
          <Button
            variant="default"
            onClick={() => window.location.href = '/article-editor'}
            iconName="Plus"
            iconPosition="left"
            iconSize={16}
          >
            Write Article
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {articles?.map((article) => (
        <div key={article?.id} className="bg-card border border-border rounded-lg overflow-hidden hover:elevation-1 transition-all group">
          {/* Cover Image */}
          <div className="aspect-video bg-muted overflow-hidden">
            <Image
              src={article?.coverImage || '/assets/images/no_image.png'}
              alt={article?.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>

          {/* Content */}
          <div className="p-4">
            {/* Category & Date */}
            <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
              <span className="bg-primary/10 text-primary px-2 py-1 rounded-full">
                {article?.category || 'General'}
              </span>
              <span>{formatDate(article?.publishedAt || article?.createdAt)}</span>
            </div>

            {/* Title */}
            <h3 
              className="font-semibold text-foreground mb-2 line-clamp-2 cursor-pointer hover:text-primary transition-colors"
              onClick={() => onNavigateToArticle(article?.id)}
            >
              {article?.title}
            </h3>

            {/* Excerpt */}
            <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
              {article?.excerpt || article?.content?.substring(0, 150) + '...'}
            </p>

            {/* Stats */}
            <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <Icon name="Heart" size={14} />
                  <span>{article?.likes || 0}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="MessageCircle" size={14} />
                  <span>{article?.comments || 0}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Eye" size={14} />
                  <span>{article?.views || 0}</span>
                </div>
              </div>
              <span>{formatReadTime(article?.readingTime || 5)}</span>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onNavigateToArticle(article?.id)}
              >
                Read More
              </Button>

              {isOwnProfile && (
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onEditArticle(article?.id)}
                    iconName="Edit"
                    iconSize={14}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDeleteArticle(article?.id)}
                    iconName="Trash2"
                    iconSize={14}
                    className="text-destructive hover:text-destructive"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Status Badge for Drafts */}
          {article?.status === 'draft' && (
            <div className="absolute top-2 right-2">
              <span className="bg-warning text-warning-foreground px-2 py-1 rounded-full text-xs font-medium">
                Draft
              </span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default ArticleGrid;