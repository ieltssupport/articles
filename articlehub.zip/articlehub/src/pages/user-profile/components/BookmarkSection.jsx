import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const BookmarkSection = ({ bookmarks, onRemoveBookmark, onNavigateToArticle }) => {
  const [selectedFolder, setSelectedFolder] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const folders = [
    { id: 'all', name: 'All Bookmarks', count: bookmarks?.length },
    { id: 'reading-list', name: 'Reading List', count: bookmarks?.filter(b => b?.folder === 'reading-list')?.length },
    { id: 'favorites', name: 'Favorites', count: bookmarks?.filter(b => b?.folder === 'favorites')?.length },
    { id: 'tech', name: 'Technology', count: bookmarks?.filter(b => b?.folder === 'tech')?.length },
    { id: 'design', name: 'Design', count: bookmarks?.filter(b => b?.folder === 'design')?.length }
  ];

  const filteredBookmarks = bookmarks?.filter(bookmark => {
    const matchesFolder = selectedFolder === 'all' || bookmark?.folder === selectedFolder;
    const matchesSearch = bookmark?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                         bookmark?.author?.toLowerCase()?.includes(searchQuery?.toLowerCase());
    return matchesFolder && matchesSearch;
  });

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (!bookmarks || bookmarks?.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Bookmark" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">No bookmarks yet</h3>
        <p className="text-muted-foreground">
          Save articles you want to read later by clicking the bookmark icon.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Icon name="Search" size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search bookmarks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        
        <div className="flex items-center space-x-2 overflow-x-auto">
          {folders?.map((folder) => (
            <button
              key={folder?.id}
              onClick={() => setSelectedFolder(folder?.id)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap transition-colors ${
                selectedFolder === folder?.id
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <span>{folder?.name}</span>
              <span className={`px-1.5 py-0.5 rounded-full text-xs ${
                selectedFolder === folder?.id
                  ? 'bg-primary-foreground/20'
                  : 'bg-background'
              }`}>
                {folder?.count}
              </span>
            </button>
          ))}
        </div>
      </div>
      {/* Bookmarks Grid */}
      {filteredBookmarks?.length === 0 ? (
        <div className="text-center py-8">
          <Icon name="Search" size={24} className="text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">No bookmarks found matching your criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredBookmarks?.map((bookmark) => (
            <div key={bookmark?.id} className="bg-card border border-border rounded-lg p-4 hover:elevation-1 transition-all">
              <div className="flex space-x-4">
                {/* Thumbnail */}
                <div className="w-20 h-20 bg-muted rounded-md overflow-hidden flex-shrink-0">
                  <Image
                    src={bookmark?.coverImage || '/assets/images/no_image.png'}
                    alt={bookmark?.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <h4 
                    className="font-medium text-foreground mb-1 line-clamp-2 cursor-pointer hover:text-primary transition-colors"
                    onClick={() => onNavigateToArticle(bookmark?.articleId)}
                  >
                    {bookmark?.title}
                  </h4>
                  
                  <p className="text-sm text-muted-foreground mb-2">
                    by {bookmark?.author}
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>Saved {formatDate(bookmark?.savedAt)}</span>
                    <div className="flex items-center space-x-2">
                      <span className="bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                        {bookmark?.category}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onRemoveBookmark(bookmark?.id)}
                        iconName="X"
                        iconSize={14}
                        className="w-6 h-6 text-muted-foreground hover:text-destructive"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BookmarkSection;