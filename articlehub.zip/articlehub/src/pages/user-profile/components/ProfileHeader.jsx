import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ProfileHeader = ({ 
  user, 
  isOwnProfile = false, 
  isFollowing = false, 
  onFollow, 
  onEditProfile,
  onAvatarUpload 
}) => {
  const [showEditModal, setShowEditModal] = useState(false);
  const [editData, setEditData] = useState({
    displayName: user?.displayName || '',
    bio: user?.bio || '',
    location: user?.location || '',
    website: user?.website || '',
    twitter: user?.twitter || '',
    linkedin: user?.linkedin || '',
    github: user?.github || ''
  });

  const handleSaveProfile = () => {
    onEditProfile(editData);
    setShowEditModal(false);
  };

  const handleAvatarClick = () => {
    if (isOwnProfile) {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.onchange = (e) => {
        const file = e?.target?.files?.[0];
        if (file) {
          onAvatarUpload(file);
        }
      };
      input?.click();
    }
  };

  return (
    <>
      <div className="relative bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-border">
        {/* Cover Image */}
        <div className="h-32 md:h-48 bg-gradient-to-r from-primary/10 to-accent/10 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
        </div>

        {/* Profile Content */}
        <div className="container px-4 lg:px-6 pb-6">
          <div className="relative -mt-16 md:-mt-20">
            <div className="flex flex-col md:flex-row md:items-end md:space-x-6">
              {/* Avatar */}
              <div className="relative">
                <div 
                  className={`w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-background bg-muted overflow-hidden elevation-2 ${
                    isOwnProfile ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''
                  }`}
                  onClick={handleAvatarClick}
                >
                  <Image
                    src={user?.avatar || '/assets/images/no_image.png'}
                    alt={user?.displayName || 'User avatar'}
                    className="w-full h-full object-cover"
                  />
                  {isOwnProfile && (
                    <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Icon name="Camera" size={24} className="text-white" />
                    </div>
                  )}
                </div>
              </div>

              {/* Profile Info */}
              <div className="flex-1 mt-4 md:mt-0 md:pb-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="mb-4 md:mb-0">
                    <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
                      {user?.displayName || 'User Name'}
                    </h1>
                    <p className="text-muted-foreground mb-3 max-w-2xl">
                      {user?.bio || 'No bio available'}
                    </p>
                    
                    {/* Location and Links */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                      {user?.location && (
                        <div className="flex items-center space-x-1">
                          <Icon name="MapPin" size={16} />
                          <span>{user?.location}</span>
                        </div>
                      )}
                      {user?.website && (
                        <a 
                          href={user?.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center space-x-1 hover:text-primary transition-colors"
                        >
                          <Icon name="Globe" size={16} />
                          <span>Website</span>
                        </a>
                      )}
                      <div className="flex items-center space-x-1">
                        <Icon name="Calendar" size={16} />
                        <span>Joined {new Date(user.joinedDate)?.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                      </div>
                    </div>

                    {/* Social Links */}
                    <div className="flex items-center space-x-3 mt-3">
                      {user?.twitter && (
                        <a 
                          href={`https://twitter.com/${user?.twitter}`} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Icon name="Twitter" size={20} />
                        </a>
                      )}
                      {user?.linkedin && (
                        <a 
                          href={user?.linkedin} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Icon name="Linkedin" size={20} />
                        </a>
                      )}
                      {user?.github && (
                        <a 
                          href={`https://github.com/${user?.github}`} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Icon name="Github" size={20} />
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center space-x-3">
                    {isOwnProfile ? (
                      <Button
                        variant="outline"
                        onClick={() => setShowEditModal(true)}
                        iconName="Edit"
                        iconPosition="left"
                        iconSize={16}
                      >
                        Edit Profile
                      </Button>
                    ) : (
                      <>
                        <Button
                          variant={isFollowing ? "outline" : "default"}
                          onClick={onFollow}
                          iconName={isFollowing ? "UserMinus" : "UserPlus"}
                          iconPosition="left"
                          iconSize={16}
                        >
                          {isFollowing ? 'Unfollow' : 'Follow'}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          iconName="MessageCircle"
                          iconSize={16}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          iconName="MoreHorizontal"
                          iconSize={16}
                        />
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Edit Profile Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background border border-border rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto elevation-2">
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Edit Profile</h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowEditModal(false)}
                  iconName="X"
                  iconSize={20}
                />
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Display Name</label>
                <input
                  type="text"
                  value={editData?.displayName}
                  onChange={(e) => setEditData({...editData, displayName: e?.target?.value})}
                  className="w-full px-3 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Your display name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Bio</label>
                <textarea
                  value={editData?.bio}
                  onChange={(e) => setEditData({...editData, bio: e?.target?.value})}
                  rows={4}
                  className="w-full px-3 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                  placeholder="Tell us about yourself..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Location</label>
                <input
                  type="text"
                  value={editData?.location}
                  onChange={(e) => setEditData({...editData, location: e?.target?.value})}
                  className="w-full px-3 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="City, Country"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Website</label>
                <input
                  type="url"
                  value={editData?.website}
                  onChange={(e) => setEditData({...editData, website: e?.target?.value})}
                  className="w-full px-3 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="https://yourwebsite.com"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Twitter</label>
                  <input
                    type="text"
                    value={editData?.twitter}
                    onChange={(e) => setEditData({...editData, twitter: e?.target?.value})}
                    className="w-full px-3 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="username"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">LinkedIn</label>
                  <input
                    type="url"
                    value={editData?.linkedin}
                    onChange={(e) => setEditData({...editData, linkedin: e?.target?.value})}
                    className="w-full px-3 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="LinkedIn URL"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">GitHub</label>
                  <input
                    type="text"
                    value={editData?.github}
                    onChange={(e) => setEditData({...editData, github: e?.target?.value})}
                    className="w-full px-3 py-2 border border-border rounded-md bg-input focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="username"
                  />
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-border flex justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowEditModal(false)}
              >
                Cancel
              </Button>
              <Button
                variant="default"
                onClick={handleSaveProfile}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ProfileHeader;