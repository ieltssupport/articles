import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ArticleEngagement = ({ 
  article, 
  onLike, 
  onBookmark, 
  onShare,
  isLiked = false,
  isBookmarked = false,
  isMobile = false 
}) => {
  const [showShareMenu, setShowShareMenu] = useState(false);

  const shareOptions = [
    { name: 'Twitter', icon: 'Twitter', action: () => shareToTwitter() },
    { name: 'Facebook', icon: 'Facebook', action: () => shareToFacebook() },
    { name: 'LinkedIn', icon: 'Linkedin', action: () => shareToLinkedIn() },
    { name: 'Copy Link', icon: 'Link', action: () => copyToClipboard() }
  ];

  const shareToTwitter = () => {
    const text = `${article?.title} by ${article?.author?.name}`;
    const url = window.location?.href;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
    setShowShareMenu(false);
  };

  const shareToFacebook = () => {
    const url = window.location?.href;
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
    setShowShareMenu(false);
  };

  const shareToLinkedIn = () => {
    const url = window.location?.href;
    const title = article?.title;
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`, '_blank');
    setShowShareMenu(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard?.writeText(window.location?.href);
    setShowShareMenu(false);
    // You could add a toast notification here
  };

  if (isMobile) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur border-t border-border p-4 z-40">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <Button
            variant="ghost"
            size="sm"
            onClick={onLike}
            iconName={isLiked ? "Heart" : "Heart"}
            iconPosition="left"
            iconSize={20}
            className={`flex-col h-auto py-2 ${isLiked ? 'text-red-500' : 'text-muted-foreground'}`}
          >
            <span className="text-xs mt-1">{article?.likesCount || 0}</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowShareMenu(!showShareMenu)}
            iconName="Share"
            iconPosition="left"
            iconSize={20}
            className="flex-col h-auto py-2 text-muted-foreground"
          >
            <span className="text-xs mt-1">Share</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={onBookmark}
            iconName={isBookmarked ? "BookmarkCheck" : "Bookmark"}
            iconPosition="left"
            iconSize={20}
            className={`flex-col h-auto py-2 ${isBookmarked ? 'text-primary' : 'text-muted-foreground'}`}
          >
            <span className="text-xs mt-1">{isBookmarked ? 'Saved' : 'Save'}</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            iconName="MoreHorizontal"
            iconPosition="left"
            iconSize={20}
            className="flex-col h-auto py-2 text-muted-foreground"
          >
            <span className="text-xs mt-1">More</span>
          </Button>
        </div>
        {/* Mobile Share Menu */}
        {showShareMenu && (
          <div className="absolute bottom-full left-4 right-4 mb-2 bg-popover border border-border rounded-lg elevation-2 p-2">
            <div className="grid grid-cols-2 gap-2">
              {shareOptions?.map((option, index) => (
                <button
                  key={index}
                  onClick={option?.action}
                  className="flex items-center space-x-3 p-3 rounded-md hover-ambient transition-smooth"
                >
                  <Icon name={option?.icon} size={20} className="text-muted-foreground" />
                  <span className="text-sm font-medium">{option?.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="sticky top-24 space-y-4">
      <div className="flex flex-col space-y-2 bg-card border border-border rounded-lg p-3 elevation-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={onLike}
          iconName={isLiked ? "Heart" : "Heart"}
          iconPosition="left"
          iconSize={18}
          className={`justify-start ${isLiked ? 'text-red-500' : 'text-muted-foreground hover:text-foreground'}`}
        >
          {article?.likesCount || 0}
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowShareMenu(!showShareMenu)}
          iconName="Share"
          iconPosition="left"
          iconSize={18}
          className="justify-start text-muted-foreground hover:text-foreground"
        >
          Share
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={onBookmark}
          iconName={isBookmarked ? "BookmarkCheck" : "Bookmark"}
          iconPosition="left"
          iconSize={18}
          className={`justify-start ${isBookmarked ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
        >
          {isBookmarked ? 'Saved' : 'Save'}
        </Button>
      </div>
      {/* Desktop Share Menu */}
      {showShareMenu && (
        <div className="bg-popover border border-border rounded-lg p-3 elevation-2 space-y-2">
          {shareOptions?.map((option, index) => (
            <button
              key={index}
              onClick={option?.action}
              className="flex items-center space-x-3 w-full p-2 rounded-md hover-ambient transition-smooth text-left"
            >
              <Icon name={option?.icon} size={16} className="text-muted-foreground" />
              <span className="text-sm">{option?.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ArticleEngagement;