import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RelatedArticles = ({ articles, onNavigateToArticle }) => {
  const formatReadingTime = (minutes) => {
    return minutes < 1 ? '< 1 min read' : `${Math.round(minutes)} min read`;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-foreground">Related Articles</h3>
      <div className="space-y-4">
        {articles?.map((article, index) => (
          <article
            key={index}
            className="group cursor-pointer"
            onClick={() => onNavigateToArticle(article?.id)}
          >
            <div className="flex space-x-3 p-3 rounded-lg hover-ambient transition-smooth">
              {/* Article Image */}
              <div className="w-16 h-16 rounded-md overflow-hidden bg-muted flex-shrink-0">
                <Image
                  src={article?.coverImage}
                  alt={article?.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>

              {/* Article Info */}
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-foreground text-sm leading-tight mb-1 line-clamp-2 group-hover:text-primary transition-smooth">
                  {article?.title}
                </h4>
                
                <div className="flex items-center space-x-2 text-xs text-muted-foreground mb-2">
                  <span>{article?.author?.name}</span>
                  <span>•</span>
                  <span>{formatDate(article?.publishedAt)}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    {formatReadingTime(article?.readingTime)}
                  </span>
                  <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                    <Icon name="Heart" size={12} />
                    <span>{article?.likesCount || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
      <Button
        variant="outline"
        fullWidth
        iconName="ArrowRight"
        iconPosition="right"
        iconSize={16}
        className="mt-4"
      >
        View More Articles
      </Button>
    </div>
  );
};

export default RelatedArticles;