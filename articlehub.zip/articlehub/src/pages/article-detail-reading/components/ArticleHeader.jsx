import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ArticleHeader = ({ article, author, onShare, onBookmark, isBookmarked }) => {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatReadingTime = (minutes) => {
    return minutes < 1 ? '< 1 min read' : `${Math.round(minutes)} min read`;
  };

  return (
    <header className="mb-8">
      {/* Cover Image */}
      {article?.coverImage && (
        <div className="w-full h-64 md:h-80 lg:h-96 mb-8 rounded-lg overflow-hidden bg-muted">
          <Image
            src={article?.coverImage}
            alt={article?.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      {/* Article Title */}
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 leading-tight">
        {article?.title}
      </h1>
      {/* Article Subtitle */}
      {article?.subtitle && (
        <p className="text-lg md:text-xl text-muted-foreground mb-6 leading-relaxed">
          {article?.subtitle}
        </p>
      )}
      {/* Author and Meta Information */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6 pb-6 border-b border-border">
        <div className="flex items-center space-x-4">
          {/* Author Avatar */}
          <div className="w-12 h-12 rounded-full overflow-hidden bg-muted">
            <Image
              src={author?.avatar}
              alt={author?.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Author Info */}
          <div className="flex-1">
            <h3 className="font-semibold text-foreground hover:text-primary cursor-pointer">
              {author?.name}
            </h3>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <span>{formatDate(article?.publishedAt)}</span>
              <span>•</span>
              <span>{formatReadingTime(article?.readingTime)}</span>
              {article?.category && (
                <>
                  <span>•</span>
                  <span className="text-primary">{article?.category}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Social Actions */}
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBookmark}
            iconName={isBookmarked ? "BookmarkCheck" : "Bookmark"}
            iconPosition="left"
            iconSize={16}
            className="text-muted-foreground hover:text-foreground"
          >
            {isBookmarked ? 'Saved' : 'Save'}
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={onShare}
            iconName="Share"
            iconPosition="left"
            iconSize={16}
            className="text-muted-foreground hover:text-foreground"
          >
            Share
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground"
            aria-label="More options"
          >
            <Icon name="MoreHorizontal" size={16} />
          </Button>
        </div>
      </div>
      {/* Tags */}
      {article?.tags && article?.tags?.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {article?.tags?.map((tag, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-full hover:bg-accent/10 hover:text-accent cursor-pointer transition-smooth"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}
    </header>
  );
};

export default ArticleHeader;