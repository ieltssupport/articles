import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const TableOfContents = ({ headings, isVisible = true }) => {
  const [activeHeading, setActiveHeading] = useState('');
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      const headingElements = headings?.map(heading => 
        document.getElementById(heading?.id)
      )?.filter(Boolean);

      const currentHeading = headingElements?.find(element => {
        const rect = element?.getBoundingClientRect();
        return rect?.top <= 100 && rect?.bottom >= 100;
      });

      if (currentHeading) {
        setActiveHeading(currentHeading?.id);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [headings]);

  const scrollToHeading = (headingId) => {
    const element = document.getElementById(headingId);
    if (element) {
      element?.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start',
        inline: 'nearest'
      });
    }
  };

  if (!isVisible || headings?.length === 0) return null;

  return (
    <div className="sticky top-24 bg-card border border-border rounded-lg p-4 elevation-1">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">Table of Contents</h3>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-1 rounded-md hover-ambient transition-smooth"
          aria-label={isExpanded ? 'Collapse' : 'Expand'}
        >
          <Icon 
            name={isExpanded ? 'ChevronUp' : 'ChevronDown'} 
            size={16} 
            className="text-muted-foreground"
          />
        </button>
      </div>
      {isExpanded && (
        <nav className="space-y-1">
          {headings?.map((heading, index) => (
            <button
              key={index}
              onClick={() => scrollToHeading(heading?.id)}
              className={`block w-full text-left px-3 py-2 rounded-md text-sm transition-smooth hover-ambient ${
                activeHeading === heading?.id
                  ? 'bg-primary/10 text-primary font-medium' :'text-muted-foreground hover:text-foreground'
              } ${
                heading?.level > 2 ? 'ml-4' : ''
              } ${
                heading?.level > 3 ? 'ml-8' : ''
              }`}
            >
              {heading?.title}
            </button>
          ))}
        </nav>
      )}
    </div>
  );
};

export default TableOfContents;