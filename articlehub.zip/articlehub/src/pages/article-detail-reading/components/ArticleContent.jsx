import React from 'react';
import Image from '../../../components/AppImage';

const ArticleContent = ({ content, tableOfContents }) => {
  const renderContent = (contentBlocks) => {
    return contentBlocks?.map((block, index) => {
      switch (block?.type) {
        case 'heading':
          const HeadingTag = `h${block?.level}`;
          return (
            <HeadingTag
              key={index}
              id={block?.id}
              className={`font-bold text-foreground mb-4 mt-8 ${
                block?.level === 1 ? 'text-3xl' :
                block?.level === 2 ? 'text-2xl' :
                block?.level === 3 ? 'text-xl': 'text-lg'
              }`}
            >
              {block?.content}
            </HeadingTag>
          );

        case 'paragraph':
          return (
            <p key={index} className="text-foreground leading-relaxed mb-6 prose">
              {block?.content}
            </p>
          );

        case 'image':
          return (
            <figure key={index} className="my-8">
              <div className="w-full rounded-lg overflow-hidden bg-muted">
                <Image
                  src={block?.src}
                  alt={block?.alt || 'Article image'}
                  className="w-full h-auto object-cover"
                />
              </div>
              {block?.caption && (
                <figcaption className="text-sm text-muted-foreground text-center mt-2 italic">
                  {block?.caption}
                </figcaption>
              )}
            </figure>
          );

        case 'code':
          return (
            <div key={index} className="my-6">
              <pre className="bg-muted p-4 rounded-lg overflow-x-auto">
                <code className="text-sm font-mono text-foreground">
                  {block?.content}
                </code>
              </pre>
            </div>
          );

        case 'blockquote':
          return (
            <blockquote key={index} className="border-l-4 border-primary pl-6 my-6 italic text-muted-foreground">
              {block?.content}
            </blockquote>
          );

        case 'list':
          const ListTag = block?.ordered ? 'ol' : 'ul';
          return (
            <ListTag key={index} className={`my-6 space-y-2 ${block?.ordered ? 'list-decimal' : 'list-disc'} list-inside`}>
              {block?.items?.map((item, itemIndex) => (
                <li key={itemIndex} className="text-foreground leading-relaxed">
                  {item}
                </li>
              ))}
            </ListTag>
          );

        case 'embed':
          return (
            <div key={index} className="my-8">
              <div className="aspect-video w-full rounded-lg overflow-hidden bg-muted">
                <iframe
                  src={block?.src}
                  title={block?.title || 'Embedded content'}
                  className="w-full h-full"
                  allowFullScreen
                />
              </div>
            </div>
          );

        case 'table':
          return (
            <div key={index} className="my-8 overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    {block?.headers?.map((header, headerIndex) => (
                      <th key={headerIndex} className="border border-border px-4 py-2 text-left font-semibold">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {block?.rows?.map((row, rowIndex) => (
                    <tr key={rowIndex} className="hover:bg-muted/50">
                      {row?.map((cell, cellIndex) => (
                        <td key={cellIndex} className="border border-border px-4 py-2">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );

        default:
          return null;
      }
    });
  };

  return (
    <article className="prose prose-lg max-w-none">
      {renderContent(content)}
    </article>
  );
};

export default ArticleContent;