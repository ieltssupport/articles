import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const AuthorProfile = ({ author, isFollowing = false, onFollow, onNavigateToProfile }) => {
  const [showFullBio, setShowFullBio] = useState(false);

  const truncatedBio = author?.bio && author?.bio?.length > 150 
    ? author?.bio?.substring(0, 150) + '...' 
    : author?.bio;

  return (
    <div className="bg-card border border-border rounded-lg p-6 elevation-1">
      <div className="flex items-start space-x-4 mb-4">
        {/* Author Avatar */}
        <div 
          className="w-16 h-16 rounded-full overflow-hidden bg-muted cursor-pointer"
          onClick={() => onNavigateToProfile(author?.id)}
        >
          <Image
            src={author?.avatar}
            alt={author?.name}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>

        {/* Author Info */}
        <div className="flex-1 min-w-0">
          <h3 
            className="font-semibold text-foreground text-lg cursor-pointer hover:text-primary transition-smooth"
            onClick={() => onNavigateToProfile(author?.id)}
          >
            {author?.name}
          </h3>
          
          {author?.title && (
            <p className="text-muted-foreground text-sm mb-2">{author?.title}</p>
          )}

          <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
            <div className="flex items-center space-x-1">
              <Icon name="Users" size={14} />
              <span>{author?.followersCount || 0} followers</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="FileText" size={14} />
              <span>{author?.articlesCount || 0} articles</span>
            </div>
          </div>

          <Button
            variant={isFollowing ? "outline" : "default"}
            size="sm"
            onClick={onFollow}
            iconName={isFollowing ? "UserCheck" : "UserPlus"}
            iconPosition="left"
            iconSize={16}
          >
            {isFollowing ? 'Following' : 'Follow'}
          </Button>
        </div>
      </div>
      {/* Author Bio */}
      {author?.bio && (
        <div className="mb-4">
          <p className="text-muted-foreground text-sm leading-relaxed">
            {showFullBio ? author?.bio : truncatedBio}
          </p>
          {author?.bio?.length > 150 && (
            <button
              onClick={() => setShowFullBio(!showFullBio)}
              className="text-primary text-sm hover:text-primary/80 transition-smooth mt-1"
            >
              {showFullBio ? 'Show less' : 'Show more'}
            </button>
          )}
        </div>
      )}
      {/* Social Links */}
      {author?.socialLinks && author?.socialLinks?.length > 0 && (
        <div className="flex items-center space-x-3 pt-4 border-t border-border">
          <span className="text-sm text-muted-foreground">Connect:</span>
          {author?.socialLinks?.map((link, index) => (
            <a
              key={index}
              href={link?.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-md hover-ambient transition-smooth"
              aria-label={`${author?.name} on ${link?.platform}`}
            >
              <Icon 
                name={link?.platform === 'twitter' ? 'Twitter' : 
                      link?.platform === 'linkedin' ? 'Linkedin' :
                      link?.platform === 'github' ? 'Github' :
                      link?.platform === 'website' ? 'Globe' : 'ExternalLink'} 
                size={16} 
                className="text-muted-foreground hover:text-foreground"
              />
            </a>
          ))}
        </div>
      )}
      {/* Author's Recent Articles */}
      <div className="pt-4 border-t border-border mt-4">
        <h4 className="font-medium text-foreground mb-3">More from {author?.name}</h4>
        <div className="space-y-2">
          {author?.recentArticles?.slice(0, 3)?.map((article, index) => (
            <div
              key={index}
              className="cursor-pointer p-2 rounded-md hover-ambient transition-smooth"
              onClick={() => onNavigateToProfile(author?.id)}
            >
              <h5 className="text-sm font-medium text-foreground hover:text-primary transition-smooth line-clamp-2">
                {article?.title}
              </h5>
              <div className="flex items-center space-x-2 text-xs text-muted-foreground mt-1">
                <span>{new Date(article.publishedAt)?.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                <span>•</span>
                <span>{article?.readingTime} min read</span>
              </div>
            </div>
          ))}
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigateToProfile(author?.id)}
          iconName="ArrowRight"
          iconPosition="right"
          iconSize={14}
          className="mt-3 w-full justify-center"
        >
          View all articles
        </Button>
      </div>
    </div>
  );
};

export default AuthorProfile;