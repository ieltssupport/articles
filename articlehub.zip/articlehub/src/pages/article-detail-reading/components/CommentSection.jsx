import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const CommentSection = ({ articleId, comments, currentUser, onAddComment, onReplyComment }) => {
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [expandedComments, setExpandedComments] = useState(new Set());

  const handleSubmitComment = (e) => {
    e?.preventDefault();
    if (newComment?.trim()) {
      onAddComment({
        content: newComment,
        articleId,
        parentId: null
      });
      setNewComment('');
    }
  };

  const handleSubmitReply = (e, parentId) => {
    e?.preventDefault();
    if (replyText?.trim()) {
      onReplyComment({
        content: replyText,
        articleId,
        parentId
      });
      setReplyText('');
      setReplyingTo(null);
    }
  };

  const toggleExpanded = (commentId) => {
    const newExpanded = new Set(expandedComments);
    if (newExpanded?.has(commentId)) {
      newExpanded?.delete(commentId);
    } else {
      newExpanded?.add(commentId);
    }
    setExpandedComments(newExpanded);
  };

  const formatTimeAgo = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now - date) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const renderComment = (comment, level = 0) => {
    const hasReplies = comment?.replies && comment?.replies?.length > 0;
    const isExpanded = expandedComments?.has(comment?.id);
    const canReply = level < 3; // Max 3 levels deep

    return (
      <div key={comment?.id} className={`${level > 0 ? 'ml-8 border-l border-border pl-4' : ''}`}>
        <div className="flex space-x-3 mb-4">
          <div className="w-8 h-8 rounded-full overflow-hidden bg-muted flex-shrink-0">
            <Image
              src={comment?.author?.avatar}
              alt={comment?.author?.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <span className="font-medium text-foreground text-sm">
                {comment?.author?.name}
              </span>
              <span className="text-xs text-muted-foreground">
                {formatTimeAgo(comment?.createdAt)}
              </span>
              {comment?.isEdited && (
                <span className="text-xs text-muted-foreground">(edited)</span>
              )}
            </div>

            <p className="text-foreground text-sm leading-relaxed mb-2">
              {comment?.content}
            </p>

            <div className="flex items-center space-x-4">
              <button className="flex items-center space-x-1 text-xs text-muted-foreground hover:text-foreground transition-smooth">
                <Icon name="Heart" size={14} />
                <span>{comment?.likesCount || 0}</span>
              </button>

              {canReply && (
                <button
                  onClick={() => setReplyingTo(replyingTo === comment?.id ? null : comment?.id)}
                  className="text-xs text-muted-foreground hover:text-foreground transition-smooth"
                >
                  Reply
                </button>
              )}

              {hasReplies && (
                <button
                  onClick={() => toggleExpanded(comment?.id)}
                  className="flex items-center space-x-1 text-xs text-primary hover:text-primary/80 transition-smooth"
                >
                  <Icon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={14} />
                  <span>
                    {isExpanded ? 'Hide' : 'Show'} {comment?.replies?.length} {comment?.replies?.length === 1 ? 'reply' : 'replies'}
                  </span>
                </button>
              )}

              <button className="text-xs text-muted-foreground hover:text-foreground transition-smooth">
                <Icon name="MoreHorizontal" size={14} />
              </button>
            </div>

            {/* Reply Form */}
            {replyingTo === comment?.id && (
              <form onSubmit={(e) => handleSubmitReply(e, comment?.id)} className="mt-3">
                <div className="flex space-x-2">
                  <div className="w-6 h-6 rounded-full overflow-hidden bg-muted flex-shrink-0">
                    <Image
                      src={currentUser?.avatar || '/assets/images/no_image.png'}
                      alt="Your avatar"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <Input
                      type="text"
                      placeholder={`Reply to ${comment?.author?.name}...`}
                      value={replyText}
                      onChange={(e) => setReplyText(e?.target?.value)}
                      className="mb-2"
                    />
                    <div className="flex space-x-2">
                      <Button type="submit" size="sm" disabled={!replyText?.trim()}>
                        Reply
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setReplyingTo(null);
                          setReplyText('');
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              </form>
            )}
          </div>
        </div>
        {/* Nested Replies */}
        {hasReplies && isExpanded && (
          <div className="space-y-4">
            {comment?.replies?.map(reply => renderComment(reply, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <section className="mt-12 pt-8 border-t border-border">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-foreground">
          Comments ({comments?.length})
        </h2>
        <Button variant="outline" size="sm" iconName="MessageSquare" iconPosition="left">
          Sort by Latest
        </Button>
      </div>
      {/* Comment Form */}
      {currentUser ? (
        <form onSubmit={handleSubmitComment} className="mb-8">
          <div className="flex space-x-3">
            <div className="w-10 h-10 rounded-full overflow-hidden bg-muted flex-shrink-0">
              <Image
                src={currentUser?.avatar}
                alt="Your avatar"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <Input
                type="text"
                placeholder="Write a comment..."
                value={newComment}
                onChange={(e) => setNewComment(e?.target?.value)}
                className="mb-3"
              />
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <Icon name="Smile" size={16} />
                  <span>Be respectful and constructive</span>
                </div>
                <Button type="submit" size="sm" disabled={!newComment?.trim()}>
                  Comment
                </Button>
              </div>
            </div>
          </div>
        </form>
      ) : (
        <div className="mb-8 p-4 bg-muted rounded-lg text-center">
          <p className="text-muted-foreground mb-3">Join the conversation</p>
          <Button variant="outline" iconName="LogIn" iconPosition="left">
            Sign in to comment
          </Button>
        </div>
      )}
      {/* Comments List */}
      <div className="space-y-6">
        {comments?.length > 0 ? (
          comments?.map(comment => renderComment(comment))
        ) : (
          <div className="text-center py-8">
            <Icon name="MessageSquare" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No comments yet. Be the first to share your thoughts!</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default CommentSection;