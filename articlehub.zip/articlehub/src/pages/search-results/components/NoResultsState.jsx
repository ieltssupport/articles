import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const NoResultsState = ({ query, onClearFilters, onNewSearch }) => {
  const navigate = useNavigate();

  const suggestions = [
    {
      title: 'Check your spelling',
      description: 'Make sure all words are spelled correctly',
      icon: 'CheckCircle'
    },
    {
      title: 'Try different keywords',
      description: 'Use more general terms or synonyms',
      icon: 'Search'
    },
    {
      title: 'Remove filters',
      description: 'Clear some filters to see more results',
      icon: 'Filter'
    },
    {
      title: 'Browse categories',
      description: 'Explore articles by topic',
      icon: 'Grid3X3'
    }
  ];

  const popularTopics = [
    { name: 'Technology', count: 1247, icon: 'Laptop' },
    { name: 'Business', count: 892, icon: 'Briefcase' },
    { name: 'Science', count: 634, icon: 'Microscope' },
    { name: 'Health', count: 578, icon: 'Heart' },
    { name: 'Lifestyle', count: 445, icon: 'Coffee' },
    { name: 'Education', count: 389, icon: 'GraduationCap' }
  ];

  const featuredAuthors = [
    {
      name: 'Dr. Sarah Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
      specialty: 'AI & Machine Learning',
      articles: 45,
      followers: 12500
    },
    {
      name: 'Marcus Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      specialty: 'DevOps & Cloud Computing',
      articles: 32,
      followers: 8900
    },
    {
      name: 'Emily Watson',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      specialty: 'Data Science & Analytics',
      articles: 28,
      followers: 7600
    }
  ];

  return (
    <div className="max-w-4xl mx-auto text-center py-12">
      {/* No Results Illustration */}
      <div className="mb-8">
        <div className="w-32 h-32 mx-auto mb-6 bg-muted rounded-full flex items-center justify-center">
          <Icon name="Search" size={48} className="text-muted-foreground" />
        </div>
        
        <h2 className="text-2xl font-semibold text-foreground mb-2">
          No results found for "{query}"
        </h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          We couldn't find any articles matching your search. Try adjusting your search terms or explore our suggestions below.
        </p>
      </div>
      {/* Search Suggestions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {suggestions?.map((suggestion, index) => (
          <div key={index} className="bg-card border border-border rounded-lg p-4 text-left">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon name={suggestion?.icon} size={20} className="text-accent" />
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-1">{suggestion?.title}</h3>
                <p className="text-sm text-muted-foreground">{suggestion?.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3 justify-center mb-12">
        <Button
          variant="default"
          onClick={onNewSearch}
          iconName="Search"
          iconPosition="left"
        >
          Try New Search
        </Button>
        
        <Button
          variant="outline"
          onClick={onClearFilters}
          iconName="X"
          iconPosition="left"
        >
          Clear All Filters
        </Button>
        
        <Button
          variant="outline"
          onClick={() => navigate('/article-feed-home')}
          iconName="Home"
          iconPosition="left"
        >
          Browse All Articles
        </Button>
      </div>
      {/* Popular Topics */}
      <div className="mb-12">
        <h3 className="text-lg font-semibold text-foreground mb-6">Popular Topics</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {popularTopics?.map((topic, index) => (
            <button
              key={index}
              onClick={() => onNewSearch(topic?.name?.toLowerCase())}
              className="bg-card border border-border rounded-lg p-4 hover-ambient transition-smooth press-feedback"
            >
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Icon name={topic?.icon} size={24} className="text-accent" />
              </div>
              <h4 className="font-medium text-foreground text-sm mb-1">{topic?.name}</h4>
              <p className="text-xs text-muted-foreground">{topic?.count} articles</p>
            </button>
          ))}
        </div>
      </div>
      {/* Featured Authors */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-foreground mb-6">Featured Authors</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredAuthors?.map((author, index) => (
            <div key={index} className="bg-card border border-border rounded-lg p-6 text-center">
              <div className="w-16 h-16 rounded-full overflow-hidden bg-muted mx-auto mb-4">
                <Image
                  src={author?.avatar}
                  alt={author?.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <h4 className="font-semibold text-foreground mb-1">{author?.name}</h4>
              <p className="text-sm text-muted-foreground mb-2">{author?.specialty}</p>
              
              <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground mb-4">
                <span>{author?.articles} articles</span>
                <span>•</span>
                <span>{author?.followers?.toLocaleString()} followers</span>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/user-profile', { state: { author } })}
              >
                View Profile
              </Button>
            </div>
          ))}
        </div>
      </div>
      {/* Help Section */}
      <div className="bg-muted/50 rounded-lg p-6">
        <div className="flex items-center justify-center space-x-2 mb-3">
          <Icon name="HelpCircle" size={20} className="text-accent" />
          <h3 className="font-medium text-foreground">Need Help?</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Can't find what you're looking for? Our search tips and community can help you discover great content.
        </p>
        <div className="flex flex-col sm:flex-row gap-2 justify-center">
          <Button variant="ghost" size="sm">
            Search Tips
          </Button>
          <Button variant="ghost" size="sm">
            Contact Support
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NoResultsState;