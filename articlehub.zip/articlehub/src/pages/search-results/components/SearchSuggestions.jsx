import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SearchSuggestions = ({ query, onSuggestionClick, onSearchModify }) => {
  const suggestions = [
    {
      type: 'correction',
      text: 'Did you mean:',
      suggestion: query?.replace(/javascript/i, 'JavaScript'),
      icon: 'Edit3'
    },
    {
      type: 'related',
      text: 'Related searches:',
      suggestions: [
        'React JavaScript tutorial',
        'JavaScript best practices',
        'Modern JavaScript features',
        'JavaScript frameworks comparison'
      ],
      icon: 'Search'
    },
    {
      type: 'trending',
      text: 'Trending now:',
      suggestions: [
        'AI and Machine Learning',
        'Web3 Development',
        'Remote Work Tips',
        'Sustainable Technology'
      ],
      icon: 'TrendingUp'
    }
  ];

  const recentSearches = [
    'React hooks tutorial',
    'Node.js best practices',
    'CSS Grid layout',
    'TypeScript migration guide',
    'API design patterns'
  ];

  const popularAuthors = [
    {
      name: 'Sarah Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
      specialty: 'Frontend Development',
      articles: 45
    },
    {
      name: 'Marcus Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      specialty: 'DevOps & Cloud',
      articles: 32
    },
    {
      name: 'Emily Watson',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      specialty: 'Data Science',
      articles: 28
    }
  ];

  return (
    <div className="space-y-6">
      {/* Search Suggestions */}
      <div className="space-y-4">
        {suggestions?.map((section, index) => (
          <div key={index} className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-3">
              <Icon name={section?.icon} size={16} className="text-accent" />
              <h4 className="text-sm font-medium text-foreground">{section?.text}</h4>
            </div>
            
            {section?.suggestion ? (
              <button
                onClick={() => onSuggestionClick(section?.suggestion)}
                className="text-sm text-accent hover:underline"
              >
                "{section?.suggestion}"
              </button>
            ) : (
              <div className="flex flex-wrap gap-2">
                {section?.suggestions?.map((suggestion, suggestionIndex) => (
                  <button
                    key={suggestionIndex}
                    onClick={() => onSuggestionClick(suggestion)}
                    className="text-xs bg-muted text-muted-foreground px-3 py-1 rounded-full hover:bg-accent/10 hover:text-accent transition-smooth"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      {/* Recent Searches */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Icon name="Clock" size={16} className="text-muted-foreground" />
          <h4 className="text-sm font-medium text-foreground">Recent Searches</h4>
        </div>
        
        <div className="space-y-2">
          {recentSearches?.map((search, index) => (
            <button
              key={index}
              onClick={() => onSuggestionClick(search)}
              className="flex items-center space-x-3 w-full text-left p-2 rounded-md hover-ambient transition-smooth"
            >
              <Icon name="Search" size={14} className="text-muted-foreground" />
              <span className="text-sm text-foreground">{search}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Popular Authors */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Users" size={16} className="text-muted-foreground" />
          <h4 className="text-sm font-medium text-foreground">Popular Authors</h4>
        </div>
        
        <div className="space-y-3">
          {popularAuthors?.map((author, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-muted">
                <img
                  src={author?.avatar}
                  alt={author?.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{author?.name}</p>
                <p className="text-xs text-muted-foreground">{author?.specialty} • {author?.articles} articles</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onSuggestionClick(`author:${author?.name}`)}
              >
                View
              </Button>
            </div>
          ))}
        </div>
      </div>
      {/* Search Tips */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Icon name="Lightbulb" size={16} className="text-accent" />
          <h4 className="text-sm font-medium text-foreground">Search Tips</h4>
        </div>
        
        <div className="space-y-2 text-xs text-muted-foreground">
          <p>• Use quotes for exact phrases: "machine learning"</p>
          <p>• Search by author: author:john-doe</p>
          <p>• Filter by tag: #javascript #react</p>
          <p>• Exclude terms with minus: javascript -framework</p>
        </div>
      </div>
      {/* Modify Search */}
      <div className="text-center">
        <Button
          variant="outline"
          onClick={onSearchModify}
          iconName="Edit3"
          iconPosition="left"
        >
          Modify Search
        </Button>
      </div>
    </div>
  );
};

export default SearchSuggestions;