import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const SearchResultCard = ({ result, type = 'article' }) => {
  const [isBookmarked, setIsBookmarked] = useState(result?.isBookmarked || false);
  const [isLiked, setIsLiked] = useState(result?.isLiked || false);
  const [likeCount, setLikeCount] = useState(result?.likes || 0);
  const navigate = useNavigate();

  const handleBookmark = (e) => {
    e?.stopPropagation();
    setIsBookmarked(!isBookmarked);
  };

  const handleLike = (e) => {
    e?.stopPropagation();
    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
  };

  const handleCardClick = () => {
    if (type === 'article') {
      navigate('/article-detail-reading', { state: { article: result } });
    } else if (type === 'author') {
      navigate('/user-profile', { state: { userId: result?.id } });
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const formatReadingTime = (minutes) => {
    return minutes < 1 ? '< 1 min read' : `${Math.round(minutes)} min read`;
  };

  if (type === 'author') {
    return (
      <div 
        className="bg-card border border-border rounded-lg p-6 hover-ambient transition-smooth cursor-pointer press-feedback"
        onClick={handleCardClick}
      >
        <div className="flex items-start space-x-4">
          <div className="w-16 h-16 rounded-full overflow-hidden bg-muted flex-shrink-0">
            <Image
              src={result?.avatar}
              alt={result?.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-foreground mb-1">
                  {result?.name}
                </h3>
                {result?.verified && (
                  <div className="flex items-center space-x-1 mb-2">
                    <Icon name="CheckCircle" size={16} className="text-accent" />
                    <span className="text-xs text-accent">Verified Author</span>
                  </div>
                )}
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                  {result?.bio}
                </p>
                
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <span>{result?.articleCount} articles</span>
                  <span>{result?.followers} followers</span>
                  <span>Joined {formatDate(result?.joinedDate)}</span>
                </div>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e?.stopPropagation();
                  // Handle follow logic
                }}
              >
                {result?.isFollowing ? 'Following' : 'Follow'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (type === 'tag') {
    return (
      <div className="bg-card border border-border rounded-lg p-6 hover-ambient transition-smooth cursor-pointer press-feedback">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
              <Icon name="Hash" size={20} className="text-accent" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">#{result?.name}</h3>
              <p className="text-sm text-muted-foreground">{result?.articleCount} articles</p>
            </div>
          </div>
          
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Trending</p>
            <div className="flex items-center space-x-1 mt-1">
              <Icon name="TrendingUp" size={14} className="text-success" />
              <span className="text-xs text-success">+{result?.growth}%</span>
            </div>
          </div>
        </div>
        {result?.relatedTags && (
          <div className="mt-4">
            <p className="text-xs text-muted-foreground mb-2">Related tags:</p>
            <div className="flex flex-wrap gap-1">
              {result?.relatedTags?.slice(0, 5)?.map((tag, index) => (
                <span 
                  key={index}
                  className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-full"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <article 
      className="bg-card border border-border rounded-lg overflow-hidden hover-ambient transition-smooth cursor-pointer press-feedback"
      onClick={handleCardClick}
    >
      {result?.coverImage && (
        <div className="aspect-video overflow-hidden bg-muted">
          <Image
            src={result?.coverImage}
            alt={result?.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-3 min-w-0 flex-1">
            <div className="w-8 h-8 rounded-full overflow-hidden bg-muted flex-shrink-0">
              <Image
                src={result?.author?.avatar}
                alt={result?.author?.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {result?.author?.name}
              </p>
              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                <span>{formatDate(result?.publishedAt)}</span>
                <span>•</span>
                <span>{formatReadingTime(result?.readingTime)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-1">
            {result?.relevanceScore && (
              <div className="flex items-center space-x-1">
                <Icon name="Target" size={14} className="text-accent" />
                <span className="text-xs text-accent">{Math.round(result?.relevanceScore * 100)}%</span>
              </div>
            )}
          </div>
        </div>

        <h2 className="text-xl font-semibold text-foreground mb-2 line-clamp-2">
          {result?.title}
        </h2>
        
        {result?.subtitle && (
          <p className="text-sm text-muted-foreground mb-3 line-clamp-1">
            {result?.subtitle}
          </p>
        )}
        
        <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
          {result?.excerpt}
        </p>

        {result?.tags && result?.tags?.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {result?.tags?.slice(0, 3)?.map((tag, index) => (
              <span 
                key={index}
                className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-full"
              >
                {tag}
              </span>
            ))}
            {result?.tags?.length > 3 && (
              <span className="text-xs text-muted-foreground">
                +{result?.tags?.length - 3} more
              </span>
            )}
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleLike}
              className="flex items-center space-x-1 text-muted-foreground hover:text-foreground transition-smooth"
            >
              <Icon 
                name={isLiked ? "Heart" : "Heart"} 
                size={16} 
                className={isLiked ? "text-error fill-current" : ""} 
              />
              <span className="text-xs">{likeCount}</span>
            </button>
            
            <div className="flex items-center space-x-1 text-muted-foreground">
              <Icon name="MessageCircle" size={16} />
              <span className="text-xs">{result?.comments || 0}</span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleBookmark}
              className="p-1 text-muted-foreground hover:text-foreground transition-smooth"
            >
              <Icon 
                name="Bookmark" 
                size={16} 
                className={isBookmarked ? "text-accent fill-current" : ""} 
              />
            </button>
            
            <button className="p-1 text-muted-foreground hover:text-foreground transition-smooth">
              <Icon name="Share" size={16} />
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};

export default SearchResultCard;