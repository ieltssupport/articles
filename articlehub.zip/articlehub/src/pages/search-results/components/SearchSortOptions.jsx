import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SearchSortOptions = ({ currentSort, onSortChange, resultCount }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const sortOptions = [
    { value: 'relevance', label: 'Most Relevant', icon: 'Target' },
    { value: 'newest', label: 'Newest First', icon: 'Calendar' },
    { value: 'oldest', label: 'Oldest First', icon: 'CalendarDays' },
    { value: 'most_liked', label: 'Most Liked', icon: 'Heart' },
    { value: 'most_commented', label: 'Most Discussed', icon: 'MessageCircle' },
    { value: 'reading_time_asc', label: 'Quick Reads', icon: 'Clock' },
    { value: 'reading_time_desc', label: 'Long Reads', icon: 'BookOpen' }
  ];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  const getCurrentSortOption = () => {
    return sortOptions?.find(option => option?.value === currentSort) || sortOptions?.[0];
  };

  const handleSortSelect = (sortValue) => {
    onSortChange(sortValue);
    setIsOpen(false);
  };

  const formatResultCount = (count) => {
    if (count >= 1000000) {
      return `${(count / 1000000)?.toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000)?.toFixed(1)}K`;
    }
    return count?.toString();
  };

  return (
    <div className="flex items-center justify-between mb-6">
      {/* Results Count */}
      <div className="flex items-center space-x-2">
        <p className="text-sm text-muted-foreground">
          <span className="font-medium text-foreground">{formatResultCount(resultCount)}</span> results found
        </p>
        {resultCount > 0 && (
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Icon name="Clock" size={12} />
            <span>0.{Math.floor(Math.random() * 9) + 1}s</span>
          </div>
        )}
      </div>
      {/* Sort Dropdown */}
      <div className="relative" ref={dropdownRef}>
        <Button
          variant="outline"
          onClick={() => setIsOpen(!isOpen)}
          iconName="ChevronDown"
          iconPosition="right"
          iconSize={16}
          className="min-w-[140px] justify-between"
        >
          <div className="flex items-center space-x-2">
            <Icon name={getCurrentSortOption()?.icon} size={16} />
            <span className="hidden sm:inline">{getCurrentSortOption()?.label}</span>
            <span className="sm:hidden">Sort</span>
          </div>
        </Button>

        {isOpen && (
          <div className="absolute right-0 mt-2 w-56 bg-popover border border-border rounded-md elevation-2 z-50 animate-fade-in">
            <div className="p-1">
              {sortOptions?.map((option) => (
                <button
                  key={option?.value}
                  onClick={() => handleSortSelect(option?.value)}
                  className={`flex items-center space-x-3 w-full px-3 py-2 text-sm text-left rounded-md transition-smooth hover-ambient ${
                    currentSort === option?.value
                      ? 'bg-accent/10 text-accent' :'text-popover-foreground hover:text-foreground'
                  }`}
                >
                  <Icon 
                    name={option?.icon} 
                    size={16} 
                    className={currentSort === option?.value ? 'text-accent' : 'text-muted-foreground'}
                  />
                  <span>{option?.label}</span>
                  {currentSort === option?.value && (
                    <Icon name="Check" size={14} className="text-accent ml-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchSortOptions;