import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ActiveFilters = ({ filters, onRemoveFilter, onClearAll }) => {
  const getFilterChips = () => {
    const chips = [];

    // Category filters
    if (filters?.categories?.length) {
      filters?.categories?.forEach(category => {
        chips?.push({
          type: 'category',
          value: category,
          label: category?.charAt(0)?.toUpperCase() + category?.slice(1),
          color: 'bg-blue-100 text-blue-800'
        });
      });
    }

    // Content type filters
    if (filters?.contentTypes?.length) {
      filters?.contentTypes?.forEach(type => {
        chips?.push({
          type: 'contentType',
          value: type,
          label: type?.charAt(0)?.toUpperCase() + type?.slice(1),
          color: 'bg-green-100 text-green-800'
        });
      });
    }

    // Tag filters
    if (filters?.tags?.length) {
      filters?.tags?.forEach(tag => {
        chips?.push({
          type: 'tag',
          value: tag,
          label: `#${tag}`,
          color: 'bg-purple-100 text-purple-800'
        });
      });
    }

    // Date range filter
    if (filters?.dateRange?.start || filters?.dateRange?.end) {
      const start = filters?.dateRange?.start ? new Date(filters.dateRange.start)?.toLocaleDateString() : '';
      const end = filters?.dateRange?.end ? new Date(filters.dateRange.end)?.toLocaleDateString() : '';
      let label = 'Date: ';
      
      if (start && end) {
        label += `${start} - ${end}`;
      } else if (start) {
        label += `From ${start}`;
      } else if (end) {
        label += `Until ${end}`;
      }

      chips?.push({
        type: 'dateRange',
        value: 'dateRange',
        label,
        color: 'bg-orange-100 text-orange-800'
      });
    }

    // Author filter
    if (filters?.author) {
      chips?.push({
        type: 'author',
        value: filters?.author,
        label: `Author: ${filters?.author}`,
        color: 'bg-indigo-100 text-indigo-800'
      });
    }

    return chips;
  };

  const handleRemoveFilter = (chip) => {
    const updatedFilters = { ...filters };

    switch (chip?.type) {
      case 'category':
        updatedFilters.categories = filters?.categories?.filter(c => c !== chip?.value);
        if (updatedFilters?.categories?.length === 0) {
          delete updatedFilters?.categories;
        }
        break;
      case 'contentType':
        updatedFilters.contentTypes = filters?.contentTypes?.filter(t => t !== chip?.value);
        if (updatedFilters?.contentTypes?.length === 0) {
          delete updatedFilters?.contentTypes;
        }
        break;
      case 'tag':
        updatedFilters.tags = filters?.tags?.filter(t => t !== chip?.value);
        if (updatedFilters?.tags?.length === 0) {
          delete updatedFilters?.tags;
        }
        break;
      case 'dateRange':
        delete updatedFilters?.dateRange;
        break;
      case 'author':
        delete updatedFilters?.author;
        break;
      default:
        break;
    }

    onRemoveFilter(updatedFilters);
  };

  const filterChips = getFilterChips();

  if (filterChips?.length === 0) {
    return null;
  }

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-foreground">Active Filters</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearAll}
          iconName="X"
          iconPosition="left"
          iconSize={14}
        >
          Clear All
        </Button>
      </div>
      <div className="flex flex-wrap gap-2">
        {filterChips?.map((chip, index) => (
          <div
            key={`${chip?.type}-${chip?.value}-${index}`}
            className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-medium ${chip?.color} transition-smooth`}
          >
            <span>{chip?.label}</span>
            <button
              onClick={() => handleRemoveFilter(chip)}
              className="hover:bg-black/10 rounded-full p-0.5 transition-smooth"
              aria-label={`Remove ${chip?.label} filter`}
            >
              <Icon name="X" size={12} />
            </button>
          </div>
        ))}
      </div>
      <div className="mt-3 pt-3 border-t border-border">
        <p className="text-xs text-muted-foreground">
          {filterChips?.length} filter{filterChips?.length !== 1 ? 's' : ''} applied
        </p>
      </div>
    </div>
  );
};

export default ActiveFilters;