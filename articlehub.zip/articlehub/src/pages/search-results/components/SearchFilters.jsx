import React, { useState } from 'react';

import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const SearchFilters = ({ 
  filters, 
  onFiltersChange, 
  isVisible, 
  onToggle,
  isMobile = false 
}) => {
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [authorSearch, setAuthorSearch] = useState('');

  const categories = [
    { id: 'technology', label: 'Technology', count: 1247 },
    { id: 'business', label: 'Business', count: 892 },
    { id: 'science', label: 'Science', count: 634 },
    { id: 'health', label: 'Health & Wellness', count: 578 },
    { id: 'lifestyle', label: 'Lifestyle', count: 445 },
    { id: 'education', label: 'Education', count: 389 },
    { id: 'politics', label: 'Politics', count: 267 },
    { id: 'environment', label: 'Environment', count: 234 }
  ];

  const contentTypes = [
    { id: 'articles', label: 'Articles', count: 3456 },
    { id: 'series', label: 'Article Series', count: 234 },
    { id: 'collections', label: 'Collections', count: 156 }
  ];

  const popularTags = [
    'React', 'JavaScript', 'AI', 'Machine Learning', 'Web Development',
    'Startup', 'Leadership', 'Climate Change', 'Mental Health', 'Productivity'
  ];

  const handleCategoryChange = (categoryId, checked) => {
    const updatedCategories = checked 
      ? [...(filters?.categories || []), categoryId]
      : (filters?.categories || [])?.filter(id => id !== categoryId);
    
    onFiltersChange({ ...filters, categories: updatedCategories });
  };

  const handleContentTypeChange = (typeId, checked) => {
    const updatedTypes = checked 
      ? [...(filters?.contentTypes || []), typeId]
      : (filters?.contentTypes || [])?.filter(id => id !== typeId);
    
    onFiltersChange({ ...filters, contentTypes: updatedTypes });
  };

  const handleTagToggle = (tag) => {
    const updatedTags = (filters?.tags || [])?.includes(tag)
      ? (filters?.tags || [])?.filter(t => t !== tag)
      : [...(filters?.tags || []), tag];
    
    onFiltersChange({ ...filters, tags: updatedTags });
  };

  const handleDateRangeChange = (field, value) => {
    const newDateRange = { ...dateRange, [field]: value };
    setDateRange(newDateRange);
    onFiltersChange({ ...filters, dateRange: newDateRange });
  };

  const clearAllFilters = () => {
    onFiltersChange({});
    setDateRange({ start: '', end: '' });
    setAuthorSearch('');
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters?.categories?.length) count += filters?.categories?.length;
    if (filters?.contentTypes?.length) count += filters?.contentTypes?.length;
    if (filters?.tags?.length) count += filters?.tags?.length;
    if (filters?.dateRange?.start || filters?.dateRange?.end) count += 1;
    if (filters?.author) count += 1;
    return count;
  };

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Filter Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Filters</h3>
        <div className="flex items-center space-x-2">
          {getActiveFilterCount() > 0 && (
            <span className="text-xs bg-accent text-accent-foreground px-2 py-1 rounded-full">
              {getActiveFilterCount()}
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAllFilters}
            disabled={getActiveFilterCount() === 0}
          >
            Clear All
          </Button>
        </div>
      </div>

      {/* Content Type Filter */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground">Content Type</h4>
        <div className="space-y-2">
          {contentTypes?.map((type) => (
            <div key={type?.id} className="flex items-center justify-between">
              <Checkbox
                label={type?.label}
                checked={(filters?.contentTypes || [])?.includes(type?.id)}
                onChange={(e) => handleContentTypeChange(type?.id, e?.target?.checked)}
              />
              <span className="text-xs text-muted-foreground">{type?.count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Categories Filter */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground">Categories</h4>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {categories?.map((category) => (
            <div key={category?.id} className="flex items-center justify-between">
              <Checkbox
                label={category?.label}
                checked={(filters?.categories || [])?.includes(category?.id)}
                onChange={(e) => handleCategoryChange(category?.id, e?.target?.checked)}
              />
              <span className="text-xs text-muted-foreground">{category?.count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tags Filter */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground">Popular Tags</h4>
        <div className="flex flex-wrap gap-2">
          {popularTags?.map((tag) => (
            <button
              key={tag}
              onClick={() => handleTagToggle(tag)}
              className={`px-3 py-1 text-xs rounded-full border transition-smooth ${
                (filters?.tags || [])?.includes(tag)
                  ? 'bg-accent text-accent-foreground border-accent'
                  : 'bg-background text-muted-foreground border-border hover:border-accent'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Date Range Filter */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground">Date Range</h4>
        <div className="grid grid-cols-2 gap-3">
          <Input
            type="date"
            label="From"
            value={dateRange?.start}
            onChange={(e) => handleDateRangeChange('start', e?.target?.value)}
          />
          <Input
            type="date"
            label="To"
            value={dateRange?.end}
            onChange={(e) => handleDateRangeChange('end', e?.target?.value)}
          />
        </div>
      </div>

      {/* Author Filter */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground">Author</h4>
        <Input
          type="text"
          placeholder="Search by author name..."
          value={authorSearch}
          onChange={(e) => {
            setAuthorSearch(e?.target?.value);
            onFiltersChange({ ...filters, author: e?.target?.value });
          }}
        />
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <>
        {/* Mobile Filter Toggle Button */}
        <Button
          variant="outline"
          onClick={onToggle}
          iconName="Filter"
          iconPosition="left"
          className="mb-4"
        >
          Filters {getActiveFilterCount() > 0 && `(${getActiveFilterCount()})`}
        </Button>

        {/* Mobile Filter Slide-in */}
        {isVisible && (
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex">
            <div className="w-full max-w-sm bg-background border-r border-border p-6 overflow-y-auto elevation-2">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-foreground">Filters</h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onToggle}
                  iconName="X"
                />
              </div>
              <FilterContent />
            </div>
            <div className="flex-1" onClick={onToggle} />
          </div>
        )}
      </>
    );
  }

  return (
    <div className="w-80 bg-card border border-border rounded-lg p-6 h-fit sticky top-24">
      <FilterContent />
    </div>
  );
};

export default SearchFilters;