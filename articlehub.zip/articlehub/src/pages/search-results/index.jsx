import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import SearchFilters from './components/SearchFilters';
import SearchResultCard from './components/SearchResultCard';
import ActiveFilters from './components/ActiveFilters';
import SearchSortOptions from './components/SearchSortOptions';
import SearchSuggestions from './components/SearchSuggestions';
import NoResultsState from './components/NoResultsState';

const SearchResults = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [currentUser] = useState({
    id: 1,
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150"
  });

  // Extract search query from URL params
  const searchParams = new URLSearchParams(location.search);
  const initialQuery = searchParams?.get('q') || '';

  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [filters, setFilters] = useState({});
  const [sortBy, setSortBy] = useState('relevance');
  const [activeTab, setActiveTab] = useState('all');
  const [isFiltersVisible, setIsFiltersVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  // Mock search results data
  const [searchResults, setSearchResults] = useState({
    articles: [
      {
        id: 1,
        title: "Advanced React Patterns for Modern Web Development",
        subtitle: "Exploring compound components, render props, and custom hooks",
        excerpt: "Learn how to build scalable React applications using advanced patterns that promote code reusability and maintainability. This comprehensive guide covers the most important patterns every React developer should know.",
        coverImage: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800",
        author: {
          id: 1,
          name: "Sarah Chen",
          avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150",
          verified: true
        },
        publishedAt: "2025-01-05T10:30:00Z",
        readingTime: 12,
        likes: 245,
        comments: 34,
        tags: ["React", "JavaScript", "Web Development", "Frontend"],
        category: "technology",
        relevanceScore: 0.95,
        isBookmarked: false,
        isLiked: false
      },
      {
        id: 2,
        title: "The Future of Artificial Intelligence in Healthcare",
        subtitle: "How AI is revolutionizing medical diagnosis and treatment",
        excerpt: "Discover the groundbreaking applications of artificial intelligence in healthcare, from early disease detection to personalized treatment plans. Explore real-world case studies and future possibilities.",
        coverImage: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800",
        author: {
          id: 2,
          name: "Dr. Marcus Rodriguez",
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
          verified: true
        },
        publishedAt: "2025-01-04T14:15:00Z",
        readingTime: 8,
        likes: 189,
        comments: 27,
        tags: ["AI", "Healthcare", "Technology", "Medicine"],
        category: "science",
        relevanceScore: 0.87,
        isBookmarked: true,
        isLiked: false
      },
      {
        id: 3,
        title: "Building Sustainable Business Models in 2025",
        subtitle: "Strategies for long-term growth and environmental responsibility",
        excerpt: "Learn how successful companies are integrating sustainability into their core business models. This article explores practical strategies for building profitable and environmentally responsible businesses.",
        coverImage: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800",
        author: {
          id: 3,
          name: "Emily Watson",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
          verified: false
        },
        publishedAt: "2025-01-03T09:45:00Z",
        readingTime: 15,
        likes: 156,
        comments: 19,
        tags: ["Business", "Sustainability", "Strategy", "Environment"],
        category: "business",
        relevanceScore: 0.78,
        isBookmarked: false,
        isLiked: true
      },
      {
        id: 4,
        title: "Mental Health in the Digital Age: Finding Balance",
        subtitle: "Navigating technology\'s impact on our wellbeing",
        excerpt: "Explore the complex relationship between technology and mental health. This comprehensive guide offers practical strategies for maintaining psychological wellbeing in our increasingly digital world.",
        coverImage: "https://images.unsplash.com/photo-1544027993-37dbfe43562a?w=800",
        author: {
          id: 4,
          name: "Dr. James Park",
          avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150",
          verified: true
        },
        publishedAt: "2025-01-02T16:20:00Z",
        readingTime: 10,
        likes: 298,
        comments: 45,
        tags: ["Mental Health", "Technology", "Wellness", "Psychology"],
        category: "health",
        relevanceScore: 0.82,
        isBookmarked: false,
        isLiked: false
      }
    ],
    authors: [
      {
        id: 1,
        name: "Sarah Chen",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150",
        bio: "Senior Frontend Developer and React specialist with 8+ years of experience building scalable web applications.",
        verified: true,
        articleCount: 45,
        followers: 12500,
        joinedDate: "2020-03-15T00:00:00Z",
        isFollowing: false
      },
      {
        id: 2,
        name: "Dr. Marcus Rodriguez",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
        bio: "Medical researcher and AI enthusiast exploring the intersection of technology and healthcare.",
        verified: true,
        articleCount: 32,
        followers: 8900,
        joinedDate: "2019-11-22T00:00:00Z",
        isFollowing: true
      }
    ],
    tags: [
      {
        id: 1,
        name: "React",
        articleCount: 234,
        growth: 15,
        relatedTags: ["JavaScript", "Frontend", "Web Development", "Hooks", "Components"]
      },
      {
        id: 2,
        name: "AI",
        articleCount: 189,
        growth: 28,
        relatedTags: ["Machine Learning", "Deep Learning", "Neural Networks", "Data Science"]
      },
      {
        id: 3,
        name: "Sustainability",
        articleCount: 156,
        growth: 12,
        relatedTags: ["Environment", "Climate Change", "Green Technology", "ESG"]
      }
    ]
  });

  const [totalResults, setTotalResults] = useState(0);

  useEffect(() => {
    // Calculate total results based on active tab
    let total = 0;
    if (activeTab === 'all') {
      total = searchResults?.articles?.length + searchResults?.authors?.length + searchResults?.tags?.length;
    } else if (activeTab === 'articles') {
      total = searchResults?.articles?.length;
    } else if (activeTab === 'authors') {
      total = searchResults?.authors?.length;
    } else if (activeTab === 'tags') {
      total = searchResults?.tags?.length;
    }
    setTotalResults(total);
  }, [activeTab, searchResults]);

  useEffect(() => {
    // Update URL when search query changes
    if (searchQuery) {
      const newSearchParams = new URLSearchParams();
      newSearchParams?.set('q', searchQuery);
      navigate(`/search-results?${newSearchParams?.toString()}`, { replace: true });
    }
  }, [searchQuery, navigate]);

  const handleSearch = (newQuery) => {
    setSearchQuery(newQuery);
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  };

  const handleSortChange = (newSort) => {
    setSortBy(newSort);
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 300);
  };

  const handleClearAllFilters = () => {
    setFilters({});
  };

  const handleLoadMore = () => {
    setIsLoading(true);
    // Simulate loading more results
    setTimeout(() => {
      setIsLoading(false);
      setHasMore(false); // For demo purposes
    }, 1000);
  };

  const getFilteredResults = () => {
    // This would normally be handled by the backend
    let filteredArticles = [...searchResults?.articles];
    let filteredAuthors = [...searchResults?.authors];
    let filteredTags = [...searchResults?.tags];

    // Apply category filter
    if (filters?.categories?.length) {
      filteredArticles = filteredArticles?.filter(article => 
        filters?.categories?.includes(article?.category)
      );
    }

    // Apply tag filter
    if (filters?.tags?.length) {
      filteredArticles = filteredArticles?.filter(article =>
        article?.tags?.some(tag => filters?.tags?.includes(tag))
      );
    }

    return {
      articles: filteredArticles,
      authors: filteredAuthors,
      tags: filteredTags
    };
  };

  const filteredResults = getFilteredResults();
  const hasResults = filteredResults?.articles?.length > 0 || filteredResults?.authors?.length > 0 || filteredResults?.tags?.length > 0;

  const tabs = [
    { id: 'all', label: 'All', count: totalResults },
    { id: 'articles', label: 'Articles', count: filteredResults?.articles?.length },
    { id: 'authors', label: 'Authors', count: filteredResults?.authors?.length },
    { id: 'tags', label: 'Tags', count: filteredResults?.tags?.length }
  ];

  const renderResults = () => {
    if (!hasResults && !isLoading) {
      return (
        <NoResultsState
          query={searchQuery}
          onClearFilters={handleClearAllFilters}
          onNewSearch={handleSearch}
        />
      );
    }

    const renderArticles = () => (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredResults?.articles?.map((article) => (
          <SearchResultCard
            key={`article-${article?.id}`}
            result={article}
            type="article"
          />
        ))}
      </div>
    );

    const renderAuthors = () => (
      <div className="space-y-4">
        {filteredResults?.authors?.map((author) => (
          <SearchResultCard
            key={`author-${author?.id}`}
            result={author}
            type="author"
          />
        ))}
      </div>
    );

    const renderTags = () => (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredResults?.tags?.map((tag) => (
          <SearchResultCard
            key={`tag-${tag?.id}`}
            result={tag}
            type="tag"
          />
        ))}
      </div>
    );

    const renderAllResults = () => (
      <div className="space-y-8">
        {filteredResults?.articles?.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">Articles</h3>
            {renderArticles()}
          </div>
        )}
        
        {filteredResults?.authors?.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">Authors</h3>
            {renderAuthors()}
          </div>
        )}
        
        {filteredResults?.tags?.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">Tags</h3>
            {renderTags()}
          </div>
        )}
      </div>
    );

    switch (activeTab) {
      case 'articles':
        return renderArticles();
      case 'authors':
        return renderAuthors();
      case 'tags':
        return renderTags();
      default:
        return renderAllResults();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        currentUser={currentUser} 
        onNavigate={(path) => navigate(path)}
      />
      <main className="container mx-auto px-4 lg:px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Desktop Filters Sidebar */}
          <div className="hidden lg:block">
            <SearchFilters
              filters={filters}
              onFiltersChange={handleFiltersChange}
              isVisible={true}
              onToggle={() => {}}
              isMobile={false}
            />
          </div>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            {/* Search Header */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-foreground mb-2">
                    Search Results
                  </h1>
                  {searchQuery && (
                    <p className="text-muted-foreground">
                      Results for "<span className="font-medium text-foreground">{searchQuery}</span>"
                    </p>
                  )}
                </div>

                {/* Mobile Filters Button */}
                <div className="lg:hidden">
                  <SearchFilters
                    filters={filters}
                    onFiltersChange={handleFiltersChange}
                    isVisible={isFiltersVisible}
                    onToggle={() => setIsFiltersVisible(!isFiltersVisible)}
                    isMobile={true}
                  />
                </div>
              </div>

              {/* Search Tabs */}
              <div className="flex space-x-1 bg-muted p-1 rounded-lg mb-6">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => setActiveTab(tab?.id)}
                    className={`flex-1 px-4 py-2 text-sm font-medium rounded-md transition-smooth ${
                      activeTab === tab?.id
                        ? 'bg-background text-foreground shadow-sm'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {tab?.label}
                    {tab?.count > 0 && (
                      <span className="ml-2 text-xs bg-accent/20 text-accent px-2 py-0.5 rounded-full">
                        {tab?.count}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Active Filters */}
            <ActiveFilters
              filters={filters}
              onRemoveFilter={handleFiltersChange}
              onClearAll={handleClearAllFilters}
            />

            {/* Sort Options */}
            {hasResults && (
              <SearchSortOptions
                currentSort={sortBy}
                onSortChange={handleSortChange}
                resultCount={totalResults}
              />
            )}

            {/* Loading State */}
            {isLoading && (
              <div className="flex items-center justify-center py-12">
                <div className="flex items-center space-x-3">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-accent"></div>
                  <span className="text-muted-foreground">Searching...</span>
                </div>
              </div>
            )}

            {/* Results */}
            {!isLoading && (
              <div className="space-y-6">
                {renderResults()}

                {/* Load More Button */}
                {hasResults && hasMore && (
                  <div className="text-center pt-8">
                    <Button
                      variant="outline"
                      onClick={handleLoadMore}
                      loading={isLoading}
                      iconName="ChevronDown"
                      iconPosition="right"
                    >
                      Load More Results
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Search Suggestions Sidebar for No Results */}
            {!hasResults && !isLoading && searchQuery && (
              <div className="mt-8">
                <SearchSuggestions
                  query={searchQuery}
                  onSuggestionClick={handleSearch}
                  onSearchModify={() => {
                    // Focus search input in header
                    const searchInput = document.querySelector('input[type="search"]');
                    if (searchInput) {
                      searchInput?.focus();
                    }
                  }}
                />
              </div>
            )}
          </div>
        </div>
      </main>
      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="container mx-auto px-4 lg:px-6 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
                <Icon name="BookOpen" size={20} />
              </div>
              <span className="font-heading font-semibold text-xl text-foreground">
                ArticleHub
              </span>
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-sm text-muted-foreground mb-2">
                © {new Date()?.getFullYear()} ArticleHub. All rights reserved.
              </p>
              <div className="text-xs text-muted-foreground">
                Proudly supporting{' '}
                <a 
                  href="https://t.me/unity4change" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-accent hover:underline"
                >
                  Unity4Change
                </a>
                {' '}community
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default SearchResults;