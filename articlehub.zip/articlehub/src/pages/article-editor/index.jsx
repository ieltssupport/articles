import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useAuth } from '../../contexts/AuthContext';
import { articleService } from '../../services/articleService';
import { categoryService } from '../../services/categoryService';
import { storageService } from '../../services/storageService';
import { TiptapEditor } from '../../components/editor/TiptapEditor';
import EditorToolbar from './components/EditorToolbar';
import EditorPublishPanel from './components/EditorPublishPanel';
import EditorPreviewModal from './components/EditorPreviewModal';
import EditorStatusBar from './components/EditorStatusBar';
import EditorMetadataPanel from './components/EditorMetadataPanel';

export default function ArticleEditorPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  
  const [article, setArticle] = useState({
    title: '',
    subtitle: '',
    content: null,
    html_content: '',
    excerpt: '',
    cover_image_url: '',
    category_id: '',
    status: 'draft',
    scheduled_for: null,
    tags: []
  });
  
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showMetadata, setShowMetadata] = useState(false);
  const [autoSaveTimer, setAutoSaveTimer] = useState(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!user) {
      navigate('/login-register');
      return;
    }
  }, [user, navigate]);

  // Load existing article if editing
  useEffect(() => {
    if (slug && user) {
      loadArticle();
    }
  }, [slug, user]);

  // Load categories
  useEffect(() => {
    if (user) {
      loadCategories();
    }
  }, [user]);

  // Auto-save functionality
  useEffect(() => {
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
    }

    if (article?.title || article?.content) {
      const timer = setTimeout(() => {
        autoSave();
      }, 5000); // Auto-save every 5 seconds

      setAutoSaveTimer(timer);
    }

    return () => {
      if (autoSaveTimer) {
        clearTimeout(autoSaveTimer);
      }
    };
  }, [article?.title, article?.content]);

  const loadArticle = async () => {
    setLoading(true);
    try {
      const data = await articleService?.getArticleBySlug(slug);
      setArticle(data);
      setIsEditing(true);
    } catch (err) {
      setError('Failed to load article');
      console.error('Error loading article:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      const data = await categoryService?.getAllCategories();
      setCategories(data);
    } catch (err) {
      console.error('Error loading categories:', err);
    }
  };

  const autoSave = async () => {
    if (!article?.title || article?.status === 'published') return;

    try {
      const articleData = {
        ...article,
        status: 'draft'
      };

      if (isEditing) {
        await articleService?.updateArticle(article?.id, articleData);
      } else if (article?.title) {
        const newArticle = await articleService?.createArticle(articleData);
        setArticle(newArticle);
        setIsEditing(true);
        // Update URL without navigation
        window.history?.replaceState(null, '', `/write/${newArticle?.slug}`);
      }
    } catch (err) {
      console.error('Auto-save failed:', err);
    }
  };

  const handleInputChange = (field, value) => {
    setArticle(prev => ({
      ...prev,
      [field]: value
    }));
    setError('');
  };

  const handleContentChange = (json, html) => {
    setArticle(prev => ({
      ...prev,
      content: json,
      html_content: html
    }));
  };

  const handleCoverImageUpload = async (file) => {
    try {
      const { url } = await storageService?.uploadArticleImage(file, article?.id);
      handleInputChange('cover_image_url', url);
      setSuccess('Cover image uploaded successfully');
    } catch (err) {
      setError('Failed to upload cover image');
      console.error('Error uploading image:', err);
    }
  };

  const handleSave = async (status = 'draft') => {
    if (!article?.title) {
      setError('Please add a title');
      return;
    }

    setSaving(true);
    setError('');

    try {
      const articleData = {
        ...article,
        status,
        published_at: status === 'published' ? new Date()?.toISOString() : null,
        author_id: user?.id
      };

      let savedArticle;
      if (isEditing) {
        savedArticle = await articleService?.updateArticle(article?.id, articleData);
      } else {
        savedArticle = await articleService?.createArticle(articleData);
        setIsEditing(true);
      }

      setArticle(savedArticle);
      setSuccess(status === 'published' ? 'Article published successfully!' : 'Article saved as draft');
      
      if (status === 'published') {
        setTimeout(() => {
          navigate(`/article/${savedArticle?.slug}`);
        }, 2000);
      }
    } catch (err) {
      setError(err?.message || 'Failed to save article');
    } finally {
      setSaving(false);
    }
  };

  const handleSchedule = async (scheduledFor) => {
    if (!article?.title) {
      setError('Please add a title');
      return;
    }

    setSaving(true);
    setError('');

    try {
      const articleData = {
        ...article,
        status: 'scheduled',
        scheduled_for: scheduledFor,
        author_id: user?.id
      };

      let savedArticle;
      if (isEditing) {
        savedArticle = await articleService?.updateArticle(article?.id, articleData);
      } else {
        savedArticle = await articleService?.createArticle(articleData);
        setIsEditing(true);
      }

      setArticle(savedArticle);
      setSuccess('Article scheduled successfully!');
    } catch (err) {
      setError(err?.message || 'Failed to schedule article');
    } finally {
      setSaving(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Sign In Required</h2>
          <p className="text-gray-600 mb-4">Please sign in to access the article editor.</p>
          <button
            onClick={() => navigate('/login-register')}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading article...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{isEditing ? `Edit: ${article?.title || 'Untitled'}` : 'Write New Article'} | ArticleHub</title>
        <meta name="description" content="Write and publish your article on ArticleHub" />
      </Helmet>
      <div className="min-h-screen bg-gray-50">
        {/* Editor Toolbar */}
        <EditorToolbar
          article={article}
          onSave={() => handleSave('draft')}
          onPreview={() => setShowPreview(true)}
          onMetadata={() => setShowMetadata(true)}
          saving={saving}
          isEditing={isEditing}
        />

        <div className="container mx-auto px-4 py-8">
          <div className="flex gap-8">
            {/* Main Editor */}
            <div className="flex-1">
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                {/* Title Input */}
                <div className="p-6 border-b border-gray-200">
                  <input
                    type="text"
                    placeholder="Article title..."
                    value={article?.title}
                    onChange={(e) => handleInputChange('title', e?.target?.value)}
                    className="w-full text-3xl font-bold text-gray-900 placeholder-gray-400 border-none outline-none resize-none bg-transparent"
                    style={{ minHeight: '60px' }}
                  />
                  
                  <input
                    type="text"
                    placeholder="Subtitle (optional)..."
                    value={article?.subtitle}
                    onChange={(e) => handleInputChange('subtitle', e?.target?.value)}
                    className="w-full text-xl text-gray-600 placeholder-gray-400 border-none outline-none resize-none bg-transparent mt-4"
                  />
                </div>

                {/* Cover Image */}
                {article?.cover_image_url && (
                  <div className="relative">
                    <img
                      src={article?.cover_image_url}
                      alt="Cover"
                      className="w-full h-64 object-cover"
                    />
                    <button
                      onClick={() => handleInputChange('cover_image_url', '')}
                      className="absolute top-4 right-4 bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
                    >
                      ×
                    </button>
                  </div>
                )}

                {/* Content Editor */}
                <div className="p-6">
                  <TiptapEditor
                    content={article?.content}
                    onChange={handleContentChange}
                    className="min-h-[500px]"
                  />
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="w-80">
              <EditorPublishPanel
                article={article}
                categories={categories}
                onSave={handleSave}
                onSaveDraft={() => handleSave('draft')}
                onPublish={() => handleSave('published')}
                onPreview={() => setShowPreview(true)}
                onSchedule={handleSchedule}
                onInputChange={handleInputChange}
                onCoverImageUpload={handleCoverImageUpload}
                saving={saving}
                isDraftSaved={isEditing}
                isPublishing={saving}
                lastSaved={null}
                isCollapsed={false}
                onToggleCollapse={() => {}}
              />
            </div>
          </div>
        </div>

        {/* Status Messages */}
        {error && (
          <div className="fixed top-4 right-4 bg-red-500 text-white px-4 py-2 rounded-md shadow-lg z-50">
            {error}
            <button
              onClick={() => setError('')}
              className="ml-2 text-white hover:text-gray-200"
            >
              ×
            </button>
          </div>
        )}

        {success && (
          <div className="fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-md shadow-lg z-50">
            {success}
            <button
              onClick={() => setSuccess('')}
              className="ml-2 text-white hover:text-gray-200"
            >
              ×
            </button>
          </div>
        )}

        {/* Status Bar */}
        <EditorStatusBar
          article={article}
          saving={saving}
          wordCount={article?.html_content ? article?.html_content?.replace(/<[^>]*>/g, '')?.split(' ')?.filter(word => word)?.length : 0}
        />

        {/* Preview Modal */}
        {showPreview && (
          <EditorPreviewModal
            article={article}
            onClose={() => setShowPreview(false)}
          />
        )}

        {/* Metadata Panel */}
        {showMetadata && (
          <EditorMetadataPanel
            article={article}
            onInputChange={handleInputChange}
            onClose={() => setShowMetadata(false)}
          />
        )}
      </div>
    </>
  );
}