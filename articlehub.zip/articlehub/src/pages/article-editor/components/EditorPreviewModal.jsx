import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

import Button from '../../../components/ui/Button';

const EditorPreviewModal = ({ 
  isOpen, 
  onClose, 
  article, 
  viewMode = 'desktop' 
}) => {
  const [currentViewMode, setCurrentViewMode] = useState(viewMode);

  if (!isOpen) return null;

  const mockArticleContent = `
    <h1>${article?.title || 'Untitled Article'}</h1>
    ${article?.subtitle ? `<p class="subtitle">${article?.subtitle}</p>` : ''}
    
    <div class="article-meta">
      <div class="author-info">
        <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face" alt="Author" class="author-avatar" />
        <div>
          <p class="author-name">John Doe</p>
          <p class="publish-date">Published on ${new Date()?.toLocaleDateString()}</p>
        </div>
      </div>
      <div class="article-stats">
        <span>5 min read</span>
        <span>•</span>
        <span>${article?.category || 'Technology'}</span>
      </div>
    </div>

    ${article?.coverImage ? `<img src="${article?.coverImage}" alt="Cover" class="cover-image" />` : ''}

    <div class="article-content">
      <p>This is a preview of your article content. The actual content from your editor would be rendered here with proper formatting, including:</p>
      
      <h2>Headings and Subheadings</h2>
      <p>Your article content will maintain all the formatting you've applied in the editor, including <strong>bold text</strong>, <em>italic text</em>, and <code>inline code</code>.</p>
      
      <h3>Lists and Quotes</h3>
      <ul>
        <li>Bullet points will be preserved</li>
        <li>Numbered lists will maintain their order</li>
        <li>Nested lists will show proper indentation</li>
      </ul>
      
      <blockquote>
        Block quotes will appear with proper styling and indentation, making them stand out from regular paragraph text.
      </blockquote>
      
      <h3>Code Blocks</h3>
      <pre><code>// Code blocks will maintain syntax highlighting
function example() {
  return "This is how code will appear";
}</code></pre>
      
      <p>Links, images, and other media elements will be rendered exactly as they appear in your editor, ensuring a consistent reading experience for your audience.</p>
    </div>

    <div class="article-tags">
      ${article?.tags?.map(tag => `<span class="tag">${tag}</span>`)?.join('')}
    </div>
  `;

  const previewStyles = `
    <style>
      .preview-content {
        max-width: ${currentViewMode === 'desktop' ? '800px' : '100%'};
        margin: 0 auto;
        padding: ${currentViewMode === 'desktop' ? '2rem' : '1rem'};
        font-family: 'Charter', serif;
        line-height: 1.7;
        color: #1e293b;
      }
      
      .preview-content h1 {
        font-size: ${currentViewMode === 'desktop' ? '2.5rem' : '2rem'};
        font-weight: 600;
        margin-bottom: 1rem;
        line-height: 1.2;
      }
      
      .subtitle {
        font-size: ${currentViewMode === 'desktop' ? '1.25rem' : '1.125rem'};
        color: #64748b;
        margin-bottom: 2rem;
        font-weight: 400;
      }
      
      .article-meta {
        display: flex;
        ${currentViewMode === 'mobile' ? 'flex-direction: column; gap: 1rem;' : 'justify-content: space-between; align-items: center;'}
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #e2e8f0;
      }
      
      .author-info {
        display: flex;
        align-items: center;
        gap: 0.75rem;
      }
      
      .author-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
      }
      
      .author-name {
        font-weight: 500;
        margin: 0;
        font-size: 0.875rem;
      }
      
      .publish-date {
        color: #64748b;
        margin: 0;
        font-size: 0.75rem;
      }
      
      .article-stats {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.875rem;
        color: #64748b;
      }
      
      .cover-image {
        width: 100%;
        height: ${currentViewMode === 'desktop' ? '400px' : '250px'};
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 2rem;
      }
      
      .article-content h2 {
        font-size: ${currentViewMode === 'desktop' ? '1.875rem' : '1.5rem'};
        font-weight: 600;
        margin: 2rem 0 1rem 0;
        line-height: 1.3;
      }
      
      .article-content h3 {
        font-size: ${currentViewMode === 'desktop' ? '1.5rem' : '1.25rem'};
        font-weight: 600;
        margin: 1.5rem 0 0.75rem 0;
        line-height: 1.3;
      }
      
      .article-content p {
        margin-bottom: 1.5rem;
        font-size: ${currentViewMode === 'desktop' ? '1.125rem' : '1rem'};
      }
      
      .article-content ul, .article-content ol {
        margin-bottom: 1.5rem;
        padding-left: 1.5rem;
      }
      
      .article-content li {
        margin-bottom: 0.5rem;
        font-size: ${currentViewMode === 'desktop' ? '1.125rem' : '1rem'};
      }
      
      .article-content blockquote {
        border-left: 4px solid #2563eb;
        padding-left: 1.5rem;
        margin: 2rem 0;
        font-style: italic;
        color: #475569;
        font-size: ${currentViewMode === 'desktop' ? '1.125rem' : '1rem'};
      }
      
      .article-content pre {
        background: #f1f5f9;
        padding: 1rem;
        border-radius: 6px;
        overflow-x: auto;
        margin: 1.5rem 0;
        font-size: 0.875rem;
      }
      
      .article-content code {
        background: #f1f5f9;
        padding: 0.125rem 0.25rem;
        border-radius: 3px;
        font-size: 0.875rem;
        font-family: 'JetBrains Mono', monospace;
      }
      
      .article-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-top: 2rem;
        padding-top: 2rem;
        border-top: 1px solid #e2e8f0;
      }
      
      .tag {
        background: #f59e0b20;
        color: #f59e0b;
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-size: 0.75rem;
        font-weight: 500;
      }
    </style>
  `;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className={`bg-background border border-border rounded-lg elevation-2 flex flex-col max-h-[90vh] ${
        currentViewMode === 'desktop' ? 'w-full max-w-6xl' : 'w-full max-w-md'
      }`}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-4">
            <h3 className="font-semibold text-foreground">Article Preview</h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCurrentViewMode('desktop')}
                className={`p-2 rounded-md transition-smooth ${
                  currentViewMode === 'desktop' ?'bg-accent/20 text-accent' :'text-muted-foreground hover:text-foreground hover-ambient'
                }`}
                title="Desktop view"
              >
                <Icon name="Monitor" size={16} />
              </button>
              <button
                onClick={() => setCurrentViewMode('mobile')}
                className={`p-2 rounded-md transition-smooth ${
                  currentViewMode === 'mobile' ?'bg-accent/20 text-accent' :'text-muted-foreground hover:text-foreground hover-ambient'
                }`}
                title="Mobile view"
              >
                <Icon name="Smartphone" size={16} />
              </button>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('about:blank')?.document?.write(`
                <!DOCTYPE html>
                <html>
                <head>
                  <title>${article?.title || 'Article Preview'}</title>
                  ${previewStyles}
                </head>
                <body>
                  <div class="preview-content">${mockArticleContent}</div>
                </body>
                </html>
              `)}
              iconName="ExternalLink"
              iconPosition="left"
              iconSize={14}
            >
              Open in New Tab
            </Button>
            <button
              onClick={onClose}
              className="p-2 rounded-md hover-ambient transition-smooth"
              aria-label="Close preview"
            >
              <Icon name="X" size={20} className="text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Preview Content */}
        <div className="flex-1 overflow-auto bg-background">
          <div className={`${currentViewMode === 'mobile' ? 'max-w-sm mx-auto' : ''}`}>
            <style dangerouslySetInnerHTML={{ __html: previewStyles?.replace('<style>', '')?.replace('</style>', '') }} />
            <div 
              className="preview-content"
              dangerouslySetInnerHTML={{ __html: mockArticleContent }}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border bg-muted/30">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>
              Preview mode • Changes are not saved automatically
            </span>
            <div className="flex items-center space-x-4">
              <span>{article?.tags?.length} tags</span>
              <span>•</span>
              <span>{article?.category || 'No category'}</span>
              <span>•</span>
              <span>Last updated: {new Date()?.toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditorPreviewModal;