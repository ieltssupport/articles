import React from 'react';
import Icon from '../../../components/AppIcon';

const EditorStatusBar = ({ 
  wordCount = 0, 
  readingTime = 0, 
  isOnline = true,
  collaborators = [],
  currentUser 
}) => {
  const formatReadingTime = (minutes) => {
    if (minutes < 1) return '< 1 min read';
    return `${Math.round(minutes)} min read`;
  };

  const formatWordCount = (count) => {
    if (count < 1000) return `${count} words`;
    return `${(count / 1000)?.toFixed(1)}k words`;
  };

  return (
    <div className="h-8 bg-card border-t border-border flex items-center justify-between px-4 text-xs text-muted-foreground">
      {/* Left Section - Document Stats */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1">
          <Icon name="FileText" size={12} />
          <span>{formatWordCount(wordCount)}</span>
        </div>
        
        <div className="w-px h-3 bg-border" />
        
        <div className="flex items-center space-x-1">
          <Icon name="Clock" size={12} />
          <span>{formatReadingTime(readingTime)}</span>
        </div>
        
        <div className="w-px h-3 bg-border" />
        
        <div className="flex items-center space-x-1">
          <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-success' : 'bg-error'}`} />
          <span>{isOnline ? 'Online' : 'Offline'}</span>
        </div>
      </div>
      {/* Right Section - Collaboration */}
      <div className="flex items-center space-x-3">
        {/* Collaborators */}
        {collaborators?.length > 0 && (
          <div className="flex items-center space-x-2">
            <div className="flex -space-x-1">
              {collaborators?.slice(0, 3)?.map((collaborator, index) => (
                <div
                  key={collaborator?.id}
                  className="w-5 h-5 rounded-full bg-muted border border-background overflow-hidden"
                  title={collaborator?.name}
                >
                  <img
                    src={collaborator?.avatar || '/assets/images/no_image.png'}
                    alt={collaborator?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
              {collaborators?.length > 3 && (
                <div className="w-5 h-5 rounded-full bg-muted border border-background flex items-center justify-center text-xs">
                  +{collaborators?.length - 3}
                </div>
              )}
            </div>
            <span className="text-xs">
              {collaborators?.length === 1 
                ? `${collaborators?.[0]?.name} is editing`
                : `${collaborators?.length} people editing`
              }
            </span>
          </div>
        )}

        {/* Keyboard Shortcuts Hint */}
        <div className="flex items-center space-x-1">
          <Icon name="Keyboard" size={12} />
          <span>Press Ctrl+/ for shortcuts</span>
        </div>
      </div>
    </div>
  );
};

export default EditorStatusBar;