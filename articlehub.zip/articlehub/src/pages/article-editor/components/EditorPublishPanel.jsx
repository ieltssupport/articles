import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';

const EditorPublishPanel = ({ 
  onSaveDraft, 
  onPreview, 
  onPublish, 
  isDraftSaved, 
  isPublishing,
  lastSaved,
  isCollapsed,
  onToggleCollapse 
}) => {
  const [publishSettings, setPublishSettings] = useState({
    visibility: 'public',
    scheduledDate: '',
    scheduledTime: '',
    notifyFollowers: true,
    allowComments: true,
    showInFeed: true
  });

  const [showScheduler, setShowScheduler] = useState(false);

  const visibilityOptions = [
    { value: 'public', label: 'Public', description: 'Anyone can read this article' },
    { value: 'unlisted', label: 'Unlisted', description: 'Only people with the link can read' },
    { value: 'private', label: 'Private', description: 'Only you can read this article' }
  ];

  const handlePublish = () => {
    const publishData = {
      ...publishSettings,
      scheduledDateTime: publishSettings?.scheduledDate && publishSettings?.scheduledTime
        ? new Date(`${publishSettings.scheduledDate}T${publishSettings.scheduledTime}`)
        : null
    };
    onPublish(publishData);
  };

  const formatLastSaved = (timestamp) => {
    if (!timestamp) return 'Never saved';
    const now = new Date();
    const saved = new Date(timestamp);
    const diffMinutes = Math.floor((now - saved) / (1000 * 60));
    
    if (diffMinutes < 1) return 'Saved just now';
    if (diffMinutes < 60) return `Saved ${diffMinutes}m ago`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `Saved ${diffHours}h ago`;
    return saved?.toLocaleDateString();
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card border-l border-border flex flex-col items-center py-4">
        <button
          onClick={onToggleCollapse}
          className="p-2 rounded-md hover-ambient transition-smooth"
          aria-label="Expand publish panel"
        >
          <Icon name="ChevronLeft" size={20} className="text-muted-foreground" />
        </button>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-l border-border flex flex-col h-full">
      {/* Panel Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-semibold text-foreground">Publish</h3>
        <button
          onClick={onToggleCollapse}
          className="p-1 rounded-md hover-ambient transition-smooth"
          aria-label="Collapse publish panel"
        >
          <Icon name="ChevronRight" size={18} className="text-muted-foreground" />
        </button>
      </div>
      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Draft Status */}
        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Icon 
              name={isDraftSaved ? "Check" : "Clock"} 
              size={16} 
              className={isDraftSaved ? "text-success" : "text-warning"}
            />
            <span className="text-sm text-muted-foreground">
              {formatLastSaved(lastSaved)}
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onSaveDraft}
            disabled={isDraftSaved}
          >
            Save Draft
          </Button>
        </div>

        {/* Preview */}
        <div>
          <h4 className="font-medium text-foreground mb-3">Preview</h4>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onPreview('desktop')}
              iconName="Monitor"
              iconPosition="left"
              iconSize={16}
            >
              Desktop
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onPreview('mobile')}
              iconName="Smartphone"
              iconPosition="left"
              iconSize={16}
            >
              Mobile
            </Button>
          </div>
        </div>

        {/* Visibility Settings */}
        <div>
          <Select
            label="Visibility"
            options={visibilityOptions}
            value={publishSettings?.visibility}
            onChange={(value) => setPublishSettings(prev => ({ ...prev, visibility: value }))}
          />
        </div>

        {/* Schedule Publishing */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium text-foreground">Schedule</h4>
            <button
              onClick={() => setShowScheduler(!showScheduler)}
              className="text-sm text-accent hover:text-accent/80 transition-colors"
            >
              {showScheduler ? 'Publish now' : 'Schedule for later'}
            </button>
          </div>
          
          {showScheduler && (
            <div className="space-y-3">
              <Input
                label="Date"
                type="date"
                value={publishSettings?.scheduledDate}
                onChange={(e) => setPublishSettings(prev => ({ 
                  ...prev, 
                  scheduledDate: e?.target?.value 
                }))}
                min={new Date()?.toISOString()?.split('T')?.[0]}
              />
              <Input
                label="Time"
                type="time"
                value={publishSettings?.scheduledTime}
                onChange={(e) => setPublishSettings(prev => ({ 
                  ...prev, 
                  scheduledTime: e?.target?.value 
                }))}
              />
            </div>
          )}
        </div>

        {/* Publishing Options */}
        <div>
          <h4 className="font-medium text-foreground mb-3">Options</h4>
          <div className="space-y-3">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={publishSettings?.notifyFollowers}
                onChange={(e) => setPublishSettings(prev => ({ 
                  ...prev, 
                  notifyFollowers: e?.target?.checked 
                }))}
                className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-2 focus:ring-ring"
              />
              <span className="text-sm text-foreground">Notify followers</span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={publishSettings?.allowComments}
                onChange={(e) => setPublishSettings(prev => ({ 
                  ...prev, 
                  allowComments: e?.target?.checked 
                }))}
                className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-2 focus:ring-ring"
              />
              <span className="text-sm text-foreground">Allow comments</span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={publishSettings?.showInFeed}
                onChange={(e) => setPublishSettings(prev => ({ 
                  ...prev, 
                  showInFeed: e?.target?.checked 
                }))}
                className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-2 focus:ring-ring"
              />
              <span className="text-sm text-foreground">Show in feed</span>
            </label>
          </div>
        </div>

        {/* Version History */}
        <div>
          <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
            <Icon name="History" size={16} />
            Version History
          </h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 bg-muted/30 rounded-md">
              <div>
                <p className="text-sm font-medium text-foreground">Current Draft</p>
                <p className="text-xs text-muted-foreground">
                  {formatLastSaved(lastSaved)}
                </p>
              </div>
              <span className="text-xs bg-accent/20 text-accent px-2 py-1 rounded">
                Latest
              </span>
            </div>
            
            <div className="flex items-center justify-between p-2 hover-ambient rounded-md cursor-pointer">
              <div>
                <p className="text-sm text-foreground">Version 1.2</p>
                <p className="text-xs text-muted-foreground">2 hours ago</p>
              </div>
              <button className="text-xs text-accent hover:text-accent/80">
                Restore
              </button>
            </div>
            
            <div className="flex items-center justify-between p-2 hover-ambient rounded-md cursor-pointer">
              <div>
                <p className="text-sm text-foreground">Version 1.1</p>
                <p className="text-xs text-muted-foreground">Yesterday</p>
              </div>
              <button className="text-xs text-accent hover:text-accent/80">
                Restore
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Publish Actions */}
      <div className="p-4 border-t border-border space-y-3">
        <Button
          variant="default"
          fullWidth
          onClick={handlePublish}
          loading={isPublishing}
          iconName={showScheduler ? "Clock" : "Send"}
          iconPosition="left"
          iconSize={16}
        >
          {showScheduler ? 'Schedule Article' : 'Publish Article'}
        </Button>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onSaveDraft}
            disabled={isDraftSaved}
            iconName="Save"
            iconPosition="left"
            iconSize={14}
            className="flex-1"
          >
            Save Draft
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onPreview('desktop')}
            iconName="Eye"
            iconPosition="left"
            iconSize={14}
            className="flex-1"
          >
            Preview
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EditorPublishPanel;