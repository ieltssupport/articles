import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';


const EditorToolbar = ({ 
  editor, 
  isFloating = false, 
  position = { x: 0, y: 0 } 
}) => {
  const [activeDropdown, setActiveDropdown] = useState(null);

  if (!editor) return null;

  const toolbarItems = [
    {
      type: 'group',
      items: [
        {
          icon: 'Bold',
          action: () => editor?.chain()?.focus()?.toggleBold()?.run(),
          isActive: () => editor?.isActive('bold'),
          tooltip: 'Bold (Ctrl+B)'
        },
        {
          icon: 'Italic',
          action: () => editor?.chain()?.focus()?.toggleItalic()?.run(),
          isActive: () => editor?.isActive('italic'),
          tooltip: 'Italic (Ctrl+I)'
        },
        {
          icon: 'Underline',
          action: () => editor?.chain()?.focus()?.toggleUnderline()?.run(),
          isActive: () => editor?.isActive('underline'),
          tooltip: 'Underline (Ctrl+U)'
        },
        {
          icon: 'Strikethrough',
          action: () => editor?.chain()?.focus()?.toggleStrike()?.run(),
          isActive: () => editor?.isActive('strike'),
          tooltip: 'Strikethrough'
        }
      ]
    },
    {
      type: 'group',
      items: [
        {
          icon: 'Heading1',
          action: () => editor?.chain()?.focus()?.toggleHeading({ level: 1 })?.run(),
          isActive: () => editor?.isActive('heading', { level: 1 }),
          tooltip: 'Heading 1'
        },
        {
          icon: 'Heading2',
          action: () => editor?.chain()?.focus()?.toggleHeading({ level: 2 })?.run(),
          isActive: () => editor?.isActive('heading', { level: 2 }),
          tooltip: 'Heading 2'
        },
        {
          icon: 'Heading3',
          action: () => editor?.chain()?.focus()?.toggleHeading({ level: 3 })?.run(),
          isActive: () => editor?.isActive('heading', { level: 3 }),
          tooltip: 'Heading 3'
        }
      ]
    },
    {
      type: 'group',
      items: [
        {
          icon: 'List',
          action: () => editor?.chain()?.focus()?.toggleBulletList()?.run(),
          isActive: () => editor?.isActive('bulletList'),
          tooltip: 'Bullet List'
        },
        {
          icon: 'ListOrdered',
          action: () => editor?.chain()?.focus()?.toggleOrderedList()?.run(),
          isActive: () => editor?.isActive('orderedList'),
          tooltip: 'Numbered List'
        },
        {
          icon: 'Quote',
          action: () => editor?.chain()?.focus()?.toggleBlockquote()?.run(),
          isActive: () => editor?.isActive('blockquote'),
          tooltip: 'Quote'
        }
      ]
    },
    {
      type: 'group',
      items: [
        {
          icon: 'Link',
          action: () => {
            const url = window.prompt('Enter URL:');
            if (url) {
              editor?.chain()?.focus()?.setLink({ href: url })?.run();
            }
          },
          isActive: () => editor?.isActive('link'),
          tooltip: 'Add Link'
        },
        {
          icon: 'Code',
          action: () => editor?.chain()?.focus()?.toggleCode()?.run(),
          isActive: () => editor?.isActive('code'),
          tooltip: 'Inline Code'
        },
        {
          icon: 'FileCode',
          action: () => editor?.chain()?.focus()?.toggleCodeBlock()?.run(),
          isActive: () => editor?.isActive('codeBlock'),
          tooltip: 'Code Block'
        }
      ]
    },
    {
      type: 'group',
      items: [
        {
          icon: 'Image',
          action: () => {
            const url = window.prompt('Enter image URL:');
            if (url) {
              editor?.chain()?.focus()?.setImage({ src: url })?.run();
            }
          },
          tooltip: 'Add Image'
        },
        {
          icon: 'Table',
          action: () => editor?.chain()?.focus()?.insertTable({ rows: 3, cols: 3, withHeaderRow: true })?.run(),
          tooltip: 'Insert Table'
        },
        {
          icon: 'Minus',
          action: () => editor?.chain()?.focus()?.setHorizontalRule()?.run(),
          tooltip: 'Horizontal Rule'
        }
      ]
    }
  ];

  const formatItems = [
    {
      type: 'group',
      items: [
        {
          icon: 'AlignLeft',
          action: () => editor?.chain()?.focus()?.setTextAlign('left')?.run(),
          isActive: () => editor?.isActive({ textAlign: 'left' }),
          tooltip: 'Align Left'
        },
        {
          icon: 'AlignCenter',
          action: () => editor?.chain()?.focus()?.setTextAlign('center')?.run(),
          isActive: () => editor?.isActive({ textAlign: 'center' }),
          tooltip: 'Align Center'
        },
        {
          icon: 'AlignRight',
          action: () => editor?.chain()?.focus()?.setTextAlign('right')?.run(),
          isActive: () => editor?.isActive({ textAlign: 'right' }),
          tooltip: 'Align Right'
        }
      ]
    },
    {
      type: 'group',
      items: [
        {
          icon: 'Undo',
          action: () => editor?.chain()?.focus()?.undo()?.run(),
          disabled: () => !editor?.can()?.undo(),
          tooltip: 'Undo (Ctrl+Z)'
        },
        {
          icon: 'Redo',
          action: () => editor?.chain()?.focus()?.redo()?.run(),
          disabled: () => !editor?.can()?.redo(),
          tooltip: 'Redo (Ctrl+Y)'
        }
      ]
    }
  ];

  const renderToolbarGroup = (group, index) => (
    <div key={index} className="flex items-center">
      {group?.items?.map((item, itemIndex) => (
        <button
          key={itemIndex}
          onClick={item?.action}
          disabled={item?.disabled?.()}
          className={`p-2 rounded-md transition-smooth hover-ambient press-feedback ${
            item?.isActive?.()
              ? 'bg-accent/20 text-accent' :'text-muted-foreground hover:text-foreground'
          } ${
            item?.disabled?.() ? 'opacity-50 cursor-not-allowed' : ''
          }`}
          title={item?.tooltip}
        >
          <Icon name={item?.icon} size={16} />
        </button>
      ))}
      {index < toolbarItems?.length - 1 && (
        <div className="w-px h-6 bg-border mx-1" />
      )}
    </div>
  );

  if (isFloating) {
    return (
      <div
        className="fixed z-50 bg-popover border border-border rounded-lg elevation-2 p-2 animate-fade-in"
        style={{
          left: `${position?.x}px`,
          top: `${position?.y}px`,
          transform: 'translateY(-100%)'
        }}
      >
        <div className="flex items-center space-x-1">
          {toolbarItems?.slice(0, 3)?.map(renderToolbarGroup)}
        </div>
      </div>
    );
  }

  return (
    <div className="border-b border-border bg-card">
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center space-x-1">
          {toolbarItems?.map(renderToolbarGroup)}
        </div>
        
        <div className="flex items-center space-x-1">
          {formatItems?.map(renderToolbarGroup)}
        </div>
      </div>
    </div>
  );
};

export default EditorToolbar;