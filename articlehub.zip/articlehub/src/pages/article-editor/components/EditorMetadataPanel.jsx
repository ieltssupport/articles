import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const EditorMetadataPanel = ({ 
  metadata, 
  onMetadataChange, 
  isCollapsed, 
  onToggleCollapse 
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [tagInput, setTagInput] = useState('');
  const fileInputRef = useRef(null);

  const categoryOptions = [
    { value: 'technology', label: 'Technology' },
    { value: 'business', label: 'Business' },
    { value: 'design', label: 'Design' },
    { value: 'programming', label: 'Programming' },
    { value: 'startup', label: 'Startup' },
    { value: 'productivity', label: 'Productivity' },
    { value: 'career', label: 'Career' },
    { value: 'lifestyle', label: 'Lifestyle' }
  ];

  const suggestedTags = [
    'React', 'JavaScript', 'Web Development', 'UI/UX', 'Frontend',
    'Backend', 'Full Stack', 'Mobile', 'AI', 'Machine Learning',
    'Data Science', 'DevOps', 'Cloud', 'Security', 'Performance'
  ];

  const handleDrag = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    if (e?.type === 'dragenter' || e?.type === 'dragover') {
      setDragActive(true);
    } else if (e?.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    setDragActive(false);
    
    if (e?.dataTransfer?.files && e?.dataTransfer?.files?.[0]) {
      handleImageUpload(e?.dataTransfer?.files?.[0]);
    }
  };

  const handleImageUpload = (file) => {
    if (file && file?.type?.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        onMetadataChange('coverImage', e?.target?.result);
      };
      reader?.readAsDataURL(file);
    }
  };

  const handleFileSelect = (e) => {
    if (e?.target?.files && e?.target?.files?.[0]) {
      handleImageUpload(e?.target?.files?.[0]);
    }
  };

  const addTag = (tag) => {
    if (tag && !metadata?.tags?.includes(tag)) {
      onMetadataChange('tags', [...metadata?.tags, tag]);
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove) => {
    onMetadataChange('tags', metadata?.tags?.filter(tag => tag !== tagToRemove));
  };

  const handleTagInputKeyPress = (e) => {
    if (e?.key === 'Enter' || e?.key === ',') {
      e?.preventDefault();
      addTag(tagInput?.trim());
    }
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card border-r border-border flex flex-col items-center py-4">
        <button
          onClick={onToggleCollapse}
          className="p-2 rounded-md hover-ambient transition-smooth"
          aria-label="Expand metadata panel"
        >
          <Icon name="ChevronRight" size={20} className="text-muted-foreground" />
        </button>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-r border-border flex flex-col h-full">
      {/* Panel Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-semibold text-foreground">Article Settings</h3>
        <button
          onClick={onToggleCollapse}
          className="p-1 rounded-md hover-ambient transition-smooth"
          aria-label="Collapse metadata panel"
        >
          <Icon name="ChevronLeft" size={18} className="text-muted-foreground" />
        </button>
      </div>
      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Title */}
        <div>
          <Input
            label="Article Title"
            type="text"
            placeholder="Enter your article title..."
            value={metadata?.title}
            onChange={(e) => onMetadataChange('title', e?.target?.value)}
            required
          />
        </div>

        {/* Subtitle */}
        <div>
          <Input
            label="Subtitle (Optional)"
            type="text"
            placeholder="Add a compelling subtitle..."
            value={metadata?.subtitle}
            onChange={(e) => onMetadataChange('subtitle', e?.target?.value)}
          />
        </div>

        {/* Cover Image */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Cover Image
          </label>
          <div
            className={`relative border-2 border-dashed rounded-lg p-4 transition-colors ${
              dragActive
                ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            {metadata?.coverImage ? (
              <div className="relative">
                <div className="aspect-video rounded-md overflow-hidden bg-muted">
                  <Image
                    src={metadata?.coverImage}
                    alt="Cover image"
                    className="w-full h-full object-cover"
                  />
                </div>
                <button
                  onClick={() => onMetadataChange('coverImage', '')}
                  className="absolute top-2 right-2 p-1 bg-background/80 rounded-full hover-ambient transition-smooth"
                >
                  <Icon name="X" size={16} className="text-muted-foreground" />
                </button>
              </div>
            ) : (
              <div className="text-center">
                <Icon name="Upload" size={32} className="mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Drag & drop an image here, or click to select
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef?.current?.click()}
                >
                  Choose Image
                </Button>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
        </div>

        {/* Category */}
        <div>
          <Select
            label="Category"
            placeholder="Select a category..."
            options={categoryOptions}
            value={metadata?.category}
            onChange={(value) => onMetadataChange('category', value)}
            required
          />
        </div>

        {/* Tags */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Tags
          </label>
          <div className="space-y-3">
            <Input
              type="text"
              placeholder="Add tags (press Enter or comma to add)..."
              value={tagInput}
              onChange={(e) => setTagInput(e?.target?.value)}
              onKeyPress={handleTagInputKeyPress}
            />
            
            {/* Current Tags */}
            {metadata?.tags?.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {metadata?.tags?.map((tag, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center gap-1 px-2 py-1 bg-accent/10 text-accent rounded-md text-sm"
                  >
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="hover:text-accent/70 transition-colors"
                    >
                      <Icon name="X" size={12} />
                    </button>
                  </span>
                ))}
              </div>
            )}

            {/* Suggested Tags */}
            <div>
              <p className="text-xs text-muted-foreground mb-2">Suggested tags:</p>
              <div className="flex flex-wrap gap-1">
                {suggestedTags?.filter(tag => !metadata?.tags?.includes(tag))?.slice(0, 8)?.map((tag) => (
                    <button
                      key={tag}
                      onClick={() => addTag(tag)}
                      className="px-2 py-1 text-xs bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground rounded transition-colors"
                    >
                      {tag}
                    </button>
                  ))}
              </div>
            </div>
          </div>
        </div>

        {/* SEO Settings */}
        <div className="space-y-4">
          <h4 className="font-medium text-foreground flex items-center gap-2">
            <Icon name="Search" size={16} />
            SEO Settings
          </h4>
          
          <Input
            label="Canonical URL (Optional)"
            type="url"
            placeholder="https://example.com/original-article"
            value={metadata?.canonicalUrl}
            onChange={(e) => onMetadataChange('canonicalUrl', e?.target?.value)}
            description="Use if this article was originally published elsewhere"
          />
          
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Meta Description
            </label>
            <textarea
              className="w-full px-3 py-2 border border-input bg-input rounded-md text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
              rows={3}
              placeholder="Brief description for search engines (150-160 characters)..."
              value={metadata?.metaDescription}
              onChange={(e) => onMetadataChange('metaDescription', e?.target?.value)}
              maxLength={160}
            />
            <p className="text-xs text-muted-foreground mt-1">
              {metadata?.metaDescription?.length}/160 characters
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditorMetadataPanel;