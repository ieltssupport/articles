import React, { useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const SuccessMessage = ({ 
  isVisible, 
  message = "Successfully signed in!", 
  redirectMessage = "Redirecting to dashboard...",
  onComplete 
}) => {
  useEffect(() => {
    if (isVisible && onComplete) {
      const timer = setTimeout(() => {
        onComplete();
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [isVisible, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-card border border-border rounded-lg p-8 elevation-2 text-center max-w-sm mx-4">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center">
            <Icon name="CheckCircle" size={32} className="text-success" />
          </div>
        </div>
        
        <h3 className="text-lg font-medium text-card-foreground mb-2">
          Welcome!
        </h3>
        
        <p className="text-muted-foreground text-sm mb-4">
          {message}
        </p>
        
        <div className="flex items-center justify-center space-x-2 text-xs text-muted-foreground">
          <div className="animate-spin">
            <Icon name="Loader2" size={14} />
          </div>
          <span>{redirectMessage}</span>
        </div>
      </div>
    </div>
  );
};

export default SuccessMessage;