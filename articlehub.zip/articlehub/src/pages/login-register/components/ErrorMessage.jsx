import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ErrorMessage = ({ error, onRetry, onDismiss }) => {
  if (!error) return null;

  const getErrorIcon = (errorType) => {
    switch (errorType) {
      case 'network':
        return 'WifiOff';
      case 'auth':
        return 'AlertCircle';
      case 'validation':
        return 'AlertTriangle';
      default:
        return 'AlertCircle';
    }
  };

  const getErrorTitle = (errorType) => {
    switch (errorType) {
      case 'network':
        return 'Connection Error';
      case 'auth':
        return 'Authentication Failed';
      case 'validation':
        return 'Invalid Information';
      default:
        return 'Something went wrong';
    }
  };

  return (
    <div className="w-full max-w-md mx-auto mb-6">
      <div className="bg-error/10 border border-error/20 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0">
            <Icon 
              name={getErrorIcon(error?.type)} 
              size={20} 
              className="text-error mt-0.5" 
            />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-medium text-error mb-1">
              {getErrorTitle(error?.type)}
            </h4>
            <p className="text-sm text-error/80">
              {error?.message || 'An unexpected error occurred. Please try again.'}
            </p>
            
            {(onRetry || onDismiss) && (
              <div className="flex items-center space-x-3 mt-3">
                {onRetry && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={onRetry}
                    iconName="RefreshCw"
                    iconPosition="left"
                    iconSize={14}
                    className="border-error/30 text-error hover:bg-error/10"
                  >
                    Try again
                  </Button>
                )}
                {onDismiss && (
                  <button
                    onClick={onDismiss}
                    className="text-xs text-error/70 hover:text-error transition-smooth"
                  >
                    Dismiss
                  </button>
                )}
              </div>
            )}
          </div>
          
          {onDismiss && (
            <button
              onClick={onDismiss}
              className="flex-shrink-0 text-error/60 hover:text-error transition-smooth"
            >
              <Icon name="X" size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ErrorMessage;