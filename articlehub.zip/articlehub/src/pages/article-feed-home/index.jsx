import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '../../contexts/AuthContext';
import { articleService } from '../../services/articleService';
import { categoryService } from '../../services/categoryService';
import { ArticleCard } from './components/ArticleCard';
import ArticleSkeletonCard from './components/ArticleSkeletonCard';
import TrendingSidebar from './components/TrendingSidebar';
import RecommendationsSidebar from './components/RecommendationsSidebar';
import FilterChips from './components/FilterChips';
import SortDropdown from './components/SortDropdown';

export default function ArticleFeedHomePage() {
  const { user } = useAuth();
  const [articles, setArticles] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    category: null,
    sort: 'newest'
  });

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const [articlesData, categoriesData] = await Promise.all([
          articleService?.getAllArticles(filters),
          categoryService?.getAllCategories()
        ]);
        
        setArticles(articlesData);
        setCategories(categoriesData);
      } catch (err) {
        setError('Failed to load articles. Please try again later.');
        console.error('Error loading data:', err);
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, [filters]);

  const handleFilterChange = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const handleClearFilters = () => {
    setFilters({ category: null, sort: 'newest' });
  };

  const handleArticleUpdate = (updatedArticle) => {
    setArticles(prev => 
      prev?.map(article => 
        article?.id === updatedArticle?.id ? updatedArticle : article
      )
    );
  };

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="text-red-600 mb-4">{error}</div>
          <button 
            onClick={() => window.location?.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>ArticleHub - Discover Amazing Articles</title>
        <meta name="description" content="Discover and read amazing articles from talented writers on ArticleHub. Technology, lifestyle, and more." />
        <meta property="og:title" content="ArticleHub - Discover Amazing Articles" />
        <meta property="og:description" content="Join ArticleHub to discover and read amazing articles from talented writers worldwide." />
        <meta property="og:type" content="website" />
      </Helmet>
      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              Welcome to ArticleHub
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90">
              Discover amazing articles from talented writers worldwide
            </p>
            {!user && (
              <div className="space-x-4">
                <a 
                  href="/login-register" 
                  className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                >
                  Get Started
                </a>
                <a 
                  href="#articles" 
                  className="border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
                >
                  Browse Articles
                </a>
              </div>
            )}
          </div>
        </section>

        {/* Unity4Change Promo - Persistent Footer */}
        <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white py-3">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-center space-x-4">
              <span className="text-sm font-medium">Join Unity4Change on Telegram</span>
              <a 
                href="https://t.me/unityyforchange" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-white text-green-600 px-4 py-1 rounded-full text-sm font-semibold hover:bg-gray-100 transition-colors"
              >
                @unityyforchange
              </a>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main Content */}
            <main className="lg:w-2/3" id="articles">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4 md:mb-0">
                    Latest Articles
                  </h2>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <FilterChips 
                      categories={categories}
                      selectedCategory={filters?.category}
                      onCategorySelect={(category) => handleFilterChange({ category })}
                      onClearFilters={handleClearFilters}
                    />
                    <SortDropdown 
                      value={filters?.sort}
                      onChange={(sort) => handleFilterChange({ sort })}
                    />
                  </div>
                </div>

                {/* Articles Grid */}
                <div className="space-y-6">
                  {loading ? (
                    // Loading Skeletons
                    (Array.from({ length: 5 })?.map((_, index) => (
                      <ArticleSkeletonCard key={index} />
                    )))
                  ) : articles?.length > 0 ? (
                    // Articles List
                    (articles?.map((article) => (
                      <ArticleCard 
                        key={article?.id} 
                        article={article}
                        onUpdate={handleArticleUpdate}
                      />
                    )))
                  ) : (
                    // No Articles
                    (<div className="text-center py-12">
                      <div className="text-gray-500 mb-4">
                        No articles found matching your criteria.
                      </div>
                      <button 
                        onClick={handleClearFilters}
                        className="text-blue-600 hover:text-blue-800 font-medium"
                      >
                        Clear Filters
                      </button>
                    </div>)
                  )}
                </div>
              </div>
            </main>

            {/* Sidebar */}
            <aside className="lg:w-1/3 space-y-6">
              <TrendingSidebar 
                trendingTopics={[]}
                followedAuthors={[]}
                onFollowAuthor={() => {}}
              />
              <RecommendationsSidebar 
                recommendations={[]}
                readingProgress={[]}
                onContinueReading={() => {}}
              />
              
              {/* Unity4Change Promo Card - Large Screen Only */}
              <div className="hidden lg:block">
                <div className="bg-gradient-to-br from-green-500 to-blue-500 text-white rounded-lg p-6 shadow-sm">
                  <h3 className="text-lg font-bold mb-2">Join Unity4Change</h3>
                  <p className="text-sm opacity-90 mb-4">
                    Connect with a community working towards positive change and unity.
                  </p>
                  <a 
                    href="https://t.me/unityyforchange" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-2 bg-white text-green-600 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-sm"
                  >
                    <span>@unityyforchange</span>
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.594c-.121.553-.44.691-.889.43l-2.452-1.812-1.184 1.138c-.131.131-.242.242-.498.242l.178-2.488 4.589-4.145c.199-.177-.044-.275-.309-.098l-5.674 3.566-2.431-.758c-.529-.165-.54-.529.11-.781l9.498-3.664c.439-.164.825.108.683.776z"/>
                    </svg>
                  </a>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </>
  );
}