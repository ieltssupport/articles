import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ShareModal = ({ article, isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [shareUrl] = useState(`${window.location?.origin}/article-detail-reading?id=${article?.id}`);

  const shareOptions = [
    {
      name: 'Twitter',
      icon: 'Twitter',
      color: 'text-blue-500',
      action: () => {
        const text = `Check out this article: ${article?.title}`;
        const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareUrl)}`;
        window.open(url, '_blank');
      }
    },
    {
      name: 'Facebook',
      icon: 'Facebook',
      color: 'text-blue-600',
      action: () => {
        const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        window.open(url, '_blank');
      }
    },
    {
      name: 'LinkedIn',
      icon: 'Linkedin',
      color: 'text-blue-700',
      action: () => {
        const url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
        window.open(url, '_blank');
      }
    },
    {
      name: 'WhatsApp',
      icon: 'MessageCircle',
      color: 'text-green-600',
      action: () => {
        const text = `Check out this article: ${article?.title} ${shareUrl}`;
        const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
        window.open(url, '_blank');
      }
    },
    {
      name: 'Telegram',
      icon: 'Send',
      color: 'text-blue-500',
      action: () => {
        const text = `Check out this article: ${article?.title}`;
        const url = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(text)}`;
        window.open(url, '_blank');
      }
    },
    {
      name: 'Email',
      icon: 'Mail',
      color: 'text-gray-600',
      action: () => {
        const subject = `Interesting article: ${article?.title}`;
        const body = `I thought you might find this article interesting:\n\n${article?.title}\n${shareUrl}`;
        const url = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.location.href = url;
      }
    }
  ];

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard?.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  if (!isOpen || !article) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-popover border border-border rounded-lg w-full max-w-md elevation-2 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h3 className="text-lg font-semibold text-popover-foreground">Share Article</h3>
          <button
            onClick={onClose}
            className="p-2 rounded-md hover-ambient transition-smooth"
            aria-label="Close share modal"
          >
            <Icon name="X" size={20} className="text-muted-foreground" />
          </button>
        </div>

        {/* Article Preview */}
        <div className="p-6 border-b border-border">
          <div className="flex space-x-3">
            <div className="w-16 h-12 rounded overflow-hidden bg-muted flex-shrink-0">
              <img
                src={article?.coverImage}
                alt={article?.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.src = '/assets/images/no_image.png';
                }}
              />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-popover-foreground text-sm line-clamp-2 mb-1">
                {article?.title}
              </h4>
              <p className="text-xs text-muted-foreground">
                By {article?.author?.name}
              </p>
            </div>
          </div>
        </div>

        {/* Share Options */}
        <div className="p-6">
          <div className="grid grid-cols-3 gap-4 mb-6">
            {shareOptions?.map((option) => (
              <button
                key={option?.name}
                onClick={option?.action}
                className="flex flex-col items-center space-y-2 p-4 rounded-lg hover-ambient transition-smooth press-feedback"
              >
                <div className={`w-10 h-10 rounded-full bg-muted flex items-center justify-center ${option?.color}`}>
                  <Icon name={option?.icon} size={20} />
                </div>
                <span className="text-xs font-medium text-popover-foreground">{option?.name}</span>
              </button>
            ))}
          </div>

          {/* Copy Link */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-popover-foreground">
              Or copy link
            </label>
            <div className="flex space-x-2">
              <Input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1"
              />
              <Button
                variant={copied ? "success" : "outline"}
                onClick={handleCopyLink}
                iconName={copied ? "Check" : "Copy"}
                iconSize={16}
              >
                {copied ? 'Copied!' : 'Copy'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;