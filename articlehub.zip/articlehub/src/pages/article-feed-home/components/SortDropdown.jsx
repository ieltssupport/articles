import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const SortDropdown = ({ currentSort, onSortChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const sortOptions = [
    { value: 'newest', label: 'Newest First', icon: 'Clock' },
    { value: 'trending', label: 'Trending', icon: 'TrendingUp' },
    { value: 'most-liked', label: 'Most Liked', icon: 'Heart' },
    { value: 'personalized', label: 'For You', icon: 'Sparkles' },
    { value: 'oldest', label: 'Oldest First', icon: 'Archive' },
    { value: 'most-commented', label: 'Most Discussed', icon: 'MessageCircle' }
  ];

  const currentOption = sortOptions?.find(option => option?.value === currentSort) || sortOptions?.[0];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  const handleSortSelect = (sortValue) => {
    onSortChange(sortValue);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-4 py-2 bg-background border border-border rounded-md hover-ambient transition-smooth press-feedback"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <Icon name={currentOption?.icon} size={16} className="text-muted-foreground" />
        <span className="text-sm font-medium text-foreground">{currentOption?.label}</span>
        <Icon 
          name="ChevronDown" 
          size={16} 
          className={`text-muted-foreground transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-popover border border-border rounded-md elevation-2 z-50 animate-fade-in">
          <div className="py-1">
            {sortOptions?.map((option) => (
              <button
                key={option?.value}
                onClick={() => handleSortSelect(option?.value)}
                className={`flex items-center space-x-3 w-full px-4 py-2 text-sm text-left hover-ambient transition-smooth ${
                  currentSort === option?.value
                    ? 'bg-accent/10 text-accent' :'text-popover-foreground hover:text-foreground'
                }`}
              >
                <Icon 
                  name={option?.icon} 
                  size={16} 
                  className={currentSort === option?.value ? 'text-accent' : 'text-muted-foreground'}
                />
                <span>{option?.label}</span>
                {currentSort === option?.value && (
                  <Icon name="Check" size={16} className="text-accent ml-auto" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SortDropdown;