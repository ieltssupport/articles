import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const TrendingSidebar = ({ trendingTopics, followedAuthors, onFollowAuthor }) => {
  const navigate = useNavigate();

  const handleTopicClick = (topic) => {
    navigate(`/search-results?q=${encodeURIComponent(topic?.name)}`);
  };

  const handleAuthorClick = (author) => {
    navigate(`/user-profile?id=${author?.id}`);
  };

  const handleUnity4ChangeClick = () => {
    window.open('https://t.me/unity4change', '_blank');
  };

  return (
    <aside className="w-80 space-y-6">
      {/* Trending Topics */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="TrendingUp" size={20} className="text-accent" />
          <h3 className="font-semibold text-card-foreground">Trending Topics</h3>
        </div>
        
        <div className="space-y-3">
          {trendingTopics?.map((topic, index) => (
            <button
              key={topic?.id}
              onClick={() => handleTopicClick(topic)}
              className="flex items-center justify-between w-full p-3 rounded-md hover-ambient transition-smooth text-left"
            >
              <div className="flex items-center space-x-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-accent/10 text-accent text-xs font-medium">
                  {index + 1}
                </span>
                <div>
                  <p className="font-medium text-card-foreground">{topic?.name}</p>
                  <p className="text-xs text-muted-foreground">{topic?.articleCount} articles</p>
                </div>
              </div>
              <Icon name="ChevronRight" size={16} className="text-muted-foreground" />
            </button>
          ))}
        </div>
      </div>
      {/* Followed Authors */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Icon name="Users" size={20} className="text-accent" />
            <h3 className="font-semibold text-card-foreground">Suggested Authors</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/search-results?type=authors')}
          >
            See all
          </Button>
        </div>
        
        <div className="space-y-4">
          {followedAuthors?.map((author) => (
            <div key={author?.id} className="flex items-center space-x-3">
              <button
                onClick={() => handleAuthorClick(author)}
                className="flex items-center space-x-3 flex-1 min-w-0 hover-ambient rounded-md p-2 transition-smooth"
              >
                <div className="w-10 h-10 rounded-full overflow-hidden bg-muted">
                  <Image
                    src={author?.avatar}
                    alt={author?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-card-foreground truncate">{author?.name}</p>
                  <p className="text-xs text-muted-foreground">{author?.followers} followers</p>
                </div>
              </button>
              
              <Button
                variant={author?.isFollowing ? "outline" : "default"}
                size="sm"
                onClick={() => onFollowAuthor(author?.id, !author?.isFollowing)}
              >
                {author?.isFollowing ? 'Following' : 'Follow'}
              </Button>
            </div>
          ))}
        </div>
      </div>
      {/* Unity4Change Promotion */}
      <div className="bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/20 rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-3">
          <Icon name="Heart" size={20} className="text-accent" />
          <h3 className="font-semibold text-foreground">Join Our Community</h3>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4">
          Connect with like-minded individuals working towards positive change. Join Unity4Change on Telegram for inspiring discussions and collaborative action.
        </p>
        
        <Button
          variant="default"
          size="sm"
          onClick={handleUnity4ChangeClick}
          iconName="ExternalLink"
          iconPosition="right"
          iconSize={14}
          fullWidth
        >
          Join Unity4Change
        </Button>
      </div>
    </aside>
  );
};

export default TrendingSidebar;