import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RecommendationsSidebar = ({ recommendations, readingProgress, onContinueReading }) => {
  const navigate = useNavigate();

  const handleRecommendationClick = (article) => {
    navigate(`/article-detail-reading?id=${article?.id}`);
  };

  const handleContinueReading = (article) => {
    onContinueReading?.(article);
    navigate(`/article-detail-reading?id=${article?.id}`);
  };

  const formatReadingTime = (minutes) => {
    return minutes < 1 ? '< 1 min read' : `${Math.round(minutes)} min read`;
  };

  return (
    <aside className="w-80 space-y-6">
      {/* Continue Reading */}
      {readingProgress && readingProgress?.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Icon name="BookOpen" size={20} className="text-accent" />
            <h3 className="font-semibold text-card-foreground">Continue Reading</h3>
          </div>
          
          <div className="space-y-4">
            {readingProgress?.slice(0, 3)?.map((item) => (
              <div key={item?.id} className="space-y-3">
                <button
                  onClick={() => handleContinueReading(item)}
                  className="flex space-x-3 w-full text-left hover-ambient rounded-md p-2 transition-smooth"
                >
                  <div className="w-16 h-12 rounded overflow-hidden bg-muted flex-shrink-0">
                    <Image
                      src={item?.coverImage}
                      alt={item?.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-card-foreground text-sm line-clamp-2 mb-1">
                      {item?.title}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      {formatReadingTime(item?.readingTime)}
                    </p>
                  </div>
                </button>
                
                {/* Progress Bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{Math.round(item?.progress)}% complete</span>
                    <span>{Math.round((item?.readingTime * item?.progress) / 100)} min left</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-accent h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${item?.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Personalized Recommendations */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Icon name="Sparkles" size={20} className="text-accent" />
            <h3 className="font-semibold text-card-foreground">Recommended for You</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/search-results?type=recommendations')}
          >
            See all
          </Button>
        </div>
        
        <div className="space-y-4">
          {recommendations?.map((article) => (
            <button
              key={article?.id}
              onClick={() => handleRecommendationClick(article)}
              className="flex space-x-3 w-full text-left hover-ambient rounded-md p-2 transition-smooth"
            >
              <div className="w-16 h-12 rounded overflow-hidden bg-muted flex-shrink-0">
                <Image
                  src={article?.coverImage}
                  alt={article?.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-card-foreground text-sm line-clamp-2 mb-1">
                  {article?.title}
                </h4>
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <span>{article?.author?.name}</span>
                  <span>•</span>
                  <span>{formatReadingTime(article?.readingTime)}</span>
                </div>
                <div className="flex items-center space-x-3 mt-2">
                  <div className="flex items-center space-x-1">
                    <Icon name="Heart" size={12} />
                    <span>{article?.likes}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="MessageCircle" size={12} />
                    <span>{article?.comments}</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
      {/* Reading Stats */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="BarChart3" size={20} className="text-accent" />
          <h3 className="font-semibold text-card-foreground">Your Reading Stats</h3>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Articles read this week</span>
            <span className="font-semibold text-card-foreground">12</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Reading streak</span>
            <span className="font-semibold text-card-foreground">5 days</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Favorite category</span>
            <span className="font-semibold text-card-foreground">Technology</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Total reading time</span>
            <span className="font-semibold text-card-foreground">4.2 hours</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default RecommendationsSidebar;