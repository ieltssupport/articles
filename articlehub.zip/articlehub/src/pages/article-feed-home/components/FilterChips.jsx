import React from 'react';
import Icon from '../../../components/AppIcon';

const FilterChips = ({ categories, selectedCategory, onCategoryChange, tags, selectedTags, onTagChange }) => {
  const allCategories = [
    { id: 'all', name: 'All', count: 156 },
    ...categories
  ];

  const popularTags = tags?.slice(0, 8);

  const handleCategoryClick = (categoryId) => {
    onCategoryChange(categoryId === 'all' ? null : categoryId);
  };

  const handleTagClick = (tagName) => {
    const newSelectedTags = selectedTags?.includes(tagName)
      ? selectedTags?.filter(tag => tag !== tagName)
      : [...selectedTags, tagName];
    onTagChange(newSelectedTags);
  };

  return (
    <div className="bg-background border-b border-border sticky top-16 z-30">
      <div className="container px-4 lg:px-6 py-4">
        {/* Categories */}
        <div className="mb-4">
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="Filter" size={16} className="text-muted-foreground" />
            <span className="text-sm font-medium text-foreground">Categories</span>
          </div>
          <div className="flex space-x-2 overflow-x-auto scrollbar-hide pb-2">
            {allCategories?.map((category) => (
              <button
                key={category?.id}
                onClick={() => handleCategoryClick(category?.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-smooth press-feedback ${
                  (selectedCategory === category?.id) || (selectedCategory === null && category?.id === 'all')
                    ? 'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground'
                }`}
              >
                <span>{category?.name}</span>
                <span className="text-xs opacity-75">({category?.count})</span>
              </button>
            ))}
          </div>
        </div>

        {/* Tags */}
        <div>
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="Tag" size={16} className="text-muted-foreground" />
            <span className="text-sm font-medium text-foreground">Popular Tags</span>
            {selectedTags?.length > 0 && (
              <button
                onClick={() => onTagChange([])}
                className="text-xs text-accent hover:text-accent/80 transition-colors"
              >
                Clear all
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {popularTags?.map((tag) => (
              <button
                key={tag?.name}
                onClick={() => handleTagClick(tag?.name)}
                className={`flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-medium transition-smooth press-feedback ${
                  selectedTags?.includes(tag?.name)
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground'
                }`}
              >
                <span>#{tag?.name}</span>
                <span className="opacity-75">({tag?.count})</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterChips;