import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { Heart, MessageCircle, Bookmark, Share2, Eye } from 'lucide-react';
import { useAuth } from '../../../contexts/AuthContext';
import { articleService } from '../../../services/articleService';
import ShareModal from './ShareModal';

export function ArticleCard({ article, onUpdate }) {
  const { user } = useAuth();
  const [isLiking, setIsLiking] = useState(false);
  const [isBookmarking, setIsBookmarking] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);

  const handleLike = async (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    
    if (!user || isLiking) return;
    
    setIsLiking(true);
    try {
      const isLiked = await articleService?.toggleLike(article?.id);
      setLiked(isLiked);
      
      // Update the article in parent component
      onUpdate?.({
        ...article,
        likes_count: article?.likes_count + (isLiked ? 1 : -1)
      });
    } catch (error) {
      console.error('Failed to toggle like:', error);
    } finally {
      setIsLiking(false);
    }
  };

  const handleBookmark = async (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    
    if (!user || isBookmarking) return;
    
    setIsBookmarking(true);
    try {
      const isBookmarked = await articleService?.toggleBookmark(article?.id);
      setBookmarked(isBookmarked);
    } catch (error) {
      console.error('Failed to toggle bookmark:', error);
    } finally {
      setIsBookmarking(false);
    }
  };

  const handleShare = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    setShowShareModal(true);
  };

  const formatDate = (dateString) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch (error) {
      return 'Unknown date';
    }
  };

  return (
    <article className="bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow duration-200">
      <Link to={`/article/${article?.slug}`} className="block">
        {/* Cover Image */}
        {article?.cover_image_url && (
          <div className="aspect-w-16 aspect-h-9 rounded-t-lg overflow-hidden">
            <img
              src={article?.cover_image_url}
              alt={article?.title}
              className="w-full h-48 object-cover"
              loading="lazy"
            />
          </div>
        )}

        <div className="p-6">
          {/* Category & Reading Time */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              {article?.category && (
                <span 
                  className="px-2 py-1 text-xs font-medium rounded-full text-white"
                  style={{ backgroundColor: article?.category?.color || '#6366f1' }}
                >
                  {article?.category?.name}
                </span>
              )}
              {article?.reading_time && (
                <span className="text-sm text-gray-500">
                  {article?.reading_time} min read
                </span>
              )}
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Eye className="w-4 h-4 mr-1" />
              {article?.views_count || 0}
            </div>
          </div>

          {/* Title & Excerpt */}
          <h2 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2 hover:text-blue-600 transition-colors">
            {article?.title}
          </h2>
          
          {article?.excerpt && (
            <p className="text-gray-600 mb-4 line-clamp-3">
              {article?.excerpt}
            </p>
          )}

          {/* Tags */}
          {article?.article_tags?.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {article?.article_tags?.slice(0, 3)?.map((tagItem) => (
                <span 
                  key={tagItem?.tag?.id}
                  className="px-2 py-1 text-xs text-gray-600 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors"
                >
                  #{tagItem?.tag?.name}
                </span>
              ))}
              {article?.article_tags?.length > 3 && (
                <span className="px-2 py-1 text-xs text-gray-500 bg-gray-100 rounded-full">
                  +{article?.article_tags?.length - 3} more
                </span>
              )}
            </div>
          )}

          {/* Author & Date */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden">
                {article?.author?.avatar_url ? (
                  <img
                    src={article?.author?.avatar_url}
                    alt={article?.author?.full_name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-semibold">
                    {article?.author?.full_name?.charAt(0)?.toUpperCase() || 'A'}
                  </div>
                )}
              </div>
              <div>
                <div className="text-sm font-medium text-gray-900">
                  {article?.author?.full_name}
                </div>
                <div className="text-xs text-gray-500">
                  @{article?.author?.username} · {formatDate(article?.published_at || article?.created_at)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </Link>
      {/* Action Bar */}
      <div className="px-6 py-4 border-t border-gray-100 bg-gray-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            {/* Like Button */}
            <button
              onClick={handleLike}
              disabled={!user || isLiking}
              className={`flex items-center space-x-2 px-3 py-1 rounded-full transition-colors ${
                liked 
                  ? 'text-red-500 bg-red-50 hover:bg-red-100' :'text-gray-600 hover:text-red-500 hover:bg-red-50'
              } disabled:opacity-50`}
              title={user ? 'Like this article' : 'Sign in to like articles'}
            >
              <Heart className={`w-4 h-4 ${liked ? 'fill-current' : ''}`} />
              <span className="text-sm font-medium">{article?.likes_count || 0}</span>
            </button>

            {/* Comment Button */}
            <Link 
              to={`/article/${article?.slug}#comments`}
              className="flex items-center space-x-2 text-gray-600 hover:text-blue-500 px-3 py-1 rounded-full hover:bg-blue-50 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span className="text-sm font-medium">{article?.comments_count || 0}</span>
            </Link>
          </div>

          <div className="flex items-center space-x-2">
            {/* Bookmark Button */}
            <button
              onClick={handleBookmark}
              disabled={!user || isBookmarking}
              className={`p-2 rounded-full transition-colors ${
                bookmarked
                  ? 'text-blue-500 bg-blue-50 hover:bg-blue-100' :'text-gray-600 hover:text-blue-500 hover:bg-blue-50'
              } disabled:opacity-50`}
              title={user ? 'Bookmark this article' : 'Sign in to bookmark articles'}
            >
              <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-current' : ''}`} />
            </button>

            {/* Share Button */}
            <button
              onClick={handleShare}
              className="p-2 text-gray-600 hover:text-green-500 hover:bg-green-50 rounded-full transition-colors"
              title="Share this article"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
      {/* Share Modal */}
      {showShareModal && (
        <ShareModal
          article={article}
          onClose={() => setShowShareModal(false)}
        />
      )}
    </article>
  );
}