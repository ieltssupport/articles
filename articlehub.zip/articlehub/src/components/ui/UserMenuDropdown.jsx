import React, { useState, useRef, useEffect } from 'react';
import Icon from '../AppIcon';
import Image from '../AppImage';

const UserMenuDropdown = ({ currentUser, onNavigate, isMobile = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const menuItems = [
    { label: 'Profile', path: '/user-profile', icon: 'User' },
    { label: 'My Articles', path: '/user-profile?tab=articles', icon: 'FileText' },
    { label: 'Bookmarks', path: '/user-profile?tab=bookmarks', icon: 'Bookmark' },
    { label: 'Drafts', path: '/user-profile?tab=drafts', icon: 'Edit3' },
    { type: 'divider' },
    { label: 'Settings', path: '/user-profile?tab=settings', icon: 'Settings' },
    { label: 'Help & Support', path: '/help', icon: 'HelpCircle' },
    { type: 'divider' },
    { label: 'Sign Out', action: 'logout', icon: 'LogOut', variant: 'destructive' },
  ];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  const handleItemClick = (item) => {
    if (item?.action === 'logout') {
      // Handle logout logic here
      console.log('Logging out...');
      setIsOpen(false);
      return;
    }

    if (item?.path && onNavigate) {
      onNavigate(item?.path);
    }
    setIsOpen(false);
  };

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  if (isMobile) {
    return (
      <button
        onClick={toggleDropdown}
        className="flex items-center space-x-2 p-2 rounded-full hover-ambient transition-smooth"
      >
        <div className="w-8 h-8 rounded-full overflow-hidden bg-muted">
          <Image
            src={currentUser?.avatar || '/assets/images/no_image.png'}
            alt={currentUser?.name || 'User'}
            className="w-full h-full object-cover"
          />
        </div>
      </button>
    );
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={toggleDropdown}
        className="flex items-center space-x-2 p-1 rounded-full hover-ambient transition-smooth press-feedback"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <div className="w-8 h-8 rounded-full overflow-hidden bg-muted ring-2 ring-transparent hover:ring-accent/20 transition-smooth">
          <Image
            src={currentUser?.avatar || '/assets/images/no_image.png'}
            alt={currentUser?.name || 'User'}
            className="w-full h-full object-cover"
          />
        </div>
        <Icon 
          name="ChevronDown" 
          size={16} 
          className={`text-muted-foreground transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 bg-popover border border-border rounded-md elevation-2 z-50 animate-fade-in">
          <div className="p-3 border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-muted">
                <Image
                  src={currentUser?.avatar || '/assets/images/no_image.png'}
                  alt={currentUser?.name || 'User'}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-popover-foreground truncate">
                  {currentUser?.name || 'User Name'}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {currentUser?.email || 'user@example.com'}
                </p>
              </div>
            </div>
          </div>

          <div className="py-1">
            {menuItems?.map((item, index) => {
              if (item?.type === 'divider') {
                return <div key={index} className="h-px bg-border my-1" />;
              }

              return (
                <button
                  key={index}
                  onClick={() => handleItemClick(item)}
                  className={`flex items-center space-x-3 w-full px-4 py-2 text-sm text-left hover-ambient transition-smooth ${
                    item?.variant === 'destructive' ?'text-destructive hover:bg-destructive/10' :'text-popover-foreground hover:text-foreground'
                  }`}
                >
                  <Icon 
                    name={item?.icon} 
                    size={16} 
                    className={item?.variant === 'destructive' ? 'text-destructive' : 'text-muted-foreground'}
                  />
                  <span>{item?.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default UserMenuDropdown;