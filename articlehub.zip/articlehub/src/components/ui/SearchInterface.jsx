import React, { useState, useRef, useEffect } from 'react';
import Icon from '../AppIcon';
import Input from './Input';

const SearchInterface = ({ onSearch, isMobile = false }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState([
    'React best practices',
    'JavaScript tutorials',
    'Web development trends',
    'UI/UX design'
  ]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef?.current && !searchRef?.current?.contains(event?.target)) {
        setIsExpanded(false);
        setShowSuggestions(false);
      }
    };

    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        setIsExpanded(false);
        setShowSuggestions(false);
        setSearchQuery('');
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, []);

  const handleSearchSubmit = (e) => {
    e?.preventDefault();
    if (searchQuery?.trim()) {
      onSearch(searchQuery?.trim());
      setShowSuggestions(false);
      if (isMobile) {
        setIsExpanded(false);
      }
      
      // Add to recent searches
      setRecentSearches(prev => {
        const updated = [searchQuery?.trim(), ...prev?.filter(s => s !== searchQuery?.trim())];
        return updated?.slice(0, 5);
      });
    }
  };

  const handleRecentSearchClick = (search) => {
    setSearchQuery(search);
    onSearch(search);
    setShowSuggestions(false);
    if (isMobile) {
      setIsExpanded(false);
    }
  };

  const handleInputChange = (e) => {
    setSearchQuery(e?.target?.value);
    setShowSuggestions(e?.target?.value?.length > 0);
  };

  const handleInputFocus = () => {
    setShowSuggestions(searchQuery?.length > 0 || recentSearches?.length > 0);
  };

  const expandSearch = () => {
    setIsExpanded(true);
    setTimeout(() => {
      inputRef?.current?.focus();
    }, 100);
  };

  if (isMobile) {
    return (
      <div className="w-full mb-4" ref={searchRef}>
        <form onSubmit={handleSearchSubmit}>
          <div className="relative">
            <Input
              ref={inputRef}
              type="search"
              placeholder="Search articles..."
              value={searchQuery}
              onChange={handleInputChange}
              onFocus={handleInputFocus}
              className="pl-10 pr-4"
            />
            <Icon 
              name="Search" 
              size={18} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
            />
          </div>
        </form>
        {showSuggestions && (
          <div className="absolute left-4 right-4 mt-2 bg-popover border border-border rounded-md elevation-2 z-50 animate-fade-in">
            {searchQuery?.length > 0 && (
              <div className="p-2 border-b border-border">
                <button
                  onClick={handleSearchSubmit}
                  className="flex items-center space-x-3 w-full px-3 py-2 text-left hover-ambient rounded-md transition-smooth"
                >
                  <Icon name="Search" size={16} className="text-muted-foreground" />
                  <span className="text-sm">Search for "{searchQuery}"</span>
                </button>
              </div>
            )}
            
            {recentSearches?.length > 0 && (
              <div className="p-2">
                <p className="text-xs font-medium text-muted-foreground px-3 py-1">Recent searches</p>
                {recentSearches?.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => handleRecentSearchClick(search)}
                    className="flex items-center space-x-3 w-full px-3 py-2 text-left hover-ambient rounded-md transition-smooth"
                  >
                    <Icon name="Clock" size={16} className="text-muted-foreground" />
                    <span className="text-sm">{search}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative" ref={searchRef}>
      {!isExpanded ? (
        <button
          onClick={expandSearch}
          className="p-2 rounded-md hover-ambient transition-smooth press-feedback"
          aria-label="Search"
        >
          <Icon name="Search" size={20} className="text-muted-foreground" />
        </button>
      ) : (
        <form onSubmit={handleSearchSubmit} className="flex items-center">
          <div className="relative">
            <Input
              ref={inputRef}
              type="search"
              placeholder="Search articles..."
              value={searchQuery}
              onChange={handleInputChange}
              onFocus={handleInputFocus}
              className="w-64 pl-10 pr-4"
            />
            <Icon 
              name="Search" 
              size={18} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
            />
          </div>
          
          <button
            type="button"
            onClick={() => {
              setIsExpanded(false);
              setSearchQuery('');
              setShowSuggestions(false);
            }}
            className="ml-2 p-2 rounded-md hover-ambient transition-smooth"
            aria-label="Close search"
          >
            <Icon name="X" size={16} className="text-muted-foreground" />
          </button>
        </form>
      )}
      {isExpanded && showSuggestions && (
        <div className="absolute right-0 mt-2 w-80 bg-popover border border-border rounded-md elevation-2 z-50 animate-fade-in">
          {searchQuery?.length > 0 && (
            <div className="p-2 border-b border-border">
              <button
                onClick={handleSearchSubmit}
                className="flex items-center space-x-3 w-full px-3 py-2 text-left hover-ambient rounded-md transition-smooth"
              >
                <Icon name="Search" size={16} className="text-muted-foreground" />
                <span className="text-sm">Search for "{searchQuery}"</span>
              </button>
            </div>
          )}
          
          {recentSearches?.length > 0 && (
            <div className="p-2">
              <p className="text-xs font-medium text-muted-foreground px-3 py-1">Recent searches</p>
              {recentSearches?.map((search, index) => (
                <button
                  key={index}
                  onClick={() => handleRecentSearchClick(search)}
                  className="flex items-center space-x-3 w-full px-3 py-2 text-left hover-ambient rounded-md transition-smooth"
                >
                  <Icon name="Clock" size={16} className="text-muted-foreground" />
                  <span className="text-sm">{search}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchInterface;