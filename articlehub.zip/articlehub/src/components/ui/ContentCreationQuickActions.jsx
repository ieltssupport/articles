import React, { useState } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const ContentCreationQuickActions = ({ 
  onSaveDraft,
  onPublish,
  onPreview,
  isDraftSaved = false,
  isPublishing = false,
  isMobile = false 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showPublishOptions, setShowPublishOptions] = useState(false);

  const quickActions = [
    {
      label: 'Save Draft',
      icon: 'Save',
      action: onSaveDraft,
      variant: 'ghost',
      disabled: isDraftSaved,
      tooltip: isDraftSaved ? 'Draft saved' : 'Save as draft'
    },
    {
      label: 'Preview',
      icon: 'Eye',
      action: onPreview,
      variant: 'outline',
      tooltip: 'Preview article'
    },
    {
      label: 'Publish',
      icon: 'Send',
      action: () => setShowPublishOptions(true),
      variant: 'default',
      loading: isPublishing,
      tooltip: 'Publish article'
    }
  ];

  const publishOptions = [
    {
      label: 'Publish Now',
      description: 'Make article public immediately',
      icon: 'Globe',
      action: () => onPublish({ visibility: 'public', schedule: null })
    },
    {
      label: 'Schedule',
      description: 'Publish at a specific time',
      icon: 'Clock',
      action: () => onPublish({ visibility: 'scheduled' })
    },
    {
      label: 'Private',
      description: 'Only visible to you',
      icon: 'Lock',
      action: () => onPublish({ visibility: 'private' })
    }
  ];

  if (isMobile) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <div className={`flex flex-col-reverse space-y-reverse space-y-3 transition-all duration-300 ${
          isExpanded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}>
          {quickActions?.slice(0, -1)?.map((action, index) => (
            <Button
              key={index}
              variant={action?.variant}
              size="icon"
              onClick={action?.action}
              disabled={action?.disabled}
              className="w-12 h-12 rounded-full elevation-2 bg-background border-border"
              aria-label={action?.tooltip}
            >
              <Icon name={action?.icon} size={20} />
            </Button>
          ))}
        </div>
        <Button
          variant="default"
          size="icon"
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-14 h-14 rounded-full elevation-2 mt-3"
          loading={isPublishing}
          aria-label="Quick actions"
        >
          <Icon name={isExpanded ? 'X' : 'Plus'} size={24} />
        </Button>
        {/* Mobile Publish Options Modal */}
        {showPublishOptions && (
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-60 flex items-end">
            <div className="w-full bg-background border-t border-border rounded-t-lg p-6 elevation-2 animate-slide-in">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold">Publish Options</h3>
                <button
                  onClick={() => setShowPublishOptions(false)}
                  className="p-2 rounded-md hover-ambient transition-smooth"
                >
                  <Icon name="X" size={20} />
                </button>
              </div>
              
              <div className="space-y-3">
                {publishOptions?.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      option?.action();
                      setShowPublishOptions(false);
                      setIsExpanded(false);
                    }}
                    className="flex items-center space-x-4 w-full p-4 rounded-lg hover-ambient transition-smooth text-left"
                  >
                    <div className="flex-shrink-0 w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center">
                      <Icon name={option?.icon} size={20} className="text-accent" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{option?.label}</p>
                      <p className="text-sm text-muted-foreground">{option?.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-40">
      <div className="flex flex-col space-y-3 bg-background border border-border rounded-lg p-3 elevation-2">
        {quickActions?.map((action, index) => (
          <Button
            key={index}
            variant={action?.variant}
            size="icon"
            onClick={action?.action}
            disabled={action?.disabled}
            loading={action?.loading}
            className="w-10 h-10"
            title={action?.tooltip}
          >
            <Icon name={action?.icon} size={18} />
          </Button>
        ))}
      </div>
      {/* Desktop Publish Options Dropdown */}
      {showPublishOptions && (
        <div className="absolute right-full mr-3 top-0 w-64 bg-popover border border-border rounded-lg elevation-2 z-50 animate-fade-in">
          <div className="p-3 border-b border-border">
            <h4 className="font-medium text-sm">Publish Options</h4>
          </div>
          
          <div className="p-2">
            {publishOptions?.map((option, index) => (
              <button
                key={index}
                onClick={() => {
                  option?.action();
                  setShowPublishOptions(false);
                }}
                className="flex items-center space-x-3 w-full p-3 rounded-md hover-ambient transition-smooth text-left"
              >
                <Icon name={option?.icon} size={16} className="text-accent" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-popover-foreground">{option?.label}</p>
                  <p className="text-xs text-muted-foreground">{option?.description}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ContentCreationQuickActions;