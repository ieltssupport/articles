import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const NavigationProgressIndicator = ({ 
  articleTitle = "Article Title",
  readingTime = 5,
  onNavigateBack,
  showProgress = true 
}) => {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset;
      const docHeight = document.documentElement?.scrollHeight - window.innerHeight;
      const scrollPercent = (scrollTop / docHeight) * 100;
      
      setScrollProgress(Math.min(Math.max(scrollPercent, 0), 100));
      setIsVisible(scrollTop > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const formatReadingTime = (minutes) => {
    return minutes < 1 ? '< 1 min read' : `${Math.round(minutes)} min read`;
  };

  return (
    <div className={`fixed top-16 left-0 right-0 z-40 bg-background/95 backdrop-blur border-b border-border transition-all duration-300 ${
      isVisible ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
    }`}>
      {/* Progress Bar */}
      {showProgress && (
        <div className="absolute bottom-0 left-0 h-0.5 bg-primary transition-all duration-150 ease-out"
             style={{ width: `${scrollProgress}%` }} />
      )}
      
      <div className="container flex items-center justify-between h-12 px-4 lg:px-6">
        {/* Back Navigation */}
        <div className="flex items-center space-x-4">
          <button
            onClick={onNavigateBack}
            className="flex items-center space-x-2 px-3 py-1.5 rounded-md hover-ambient transition-smooth press-feedback"
            aria-label="Go back"
          >
            <Icon name="ArrowLeft" size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground hidden sm:inline">Back</span>
          </button>
          
          <div className="h-4 w-px bg-border hidden sm:block" />
          
          <div className="flex items-center space-x-3 min-w-0">
            <h1 className="text-sm font-medium text-foreground truncate max-w-xs lg:max-w-md">
              {articleTitle}
            </h1>
            <span className="text-xs text-muted-foreground whitespace-nowrap hidden md:inline">
              {formatReadingTime(readingTime)}
            </span>
          </div>
        </div>

        {/* Article Actions */}
        <div className="flex items-center space-x-2">
          <button
            className="p-2 rounded-md hover-ambient transition-smooth press-feedback"
            aria-label="Bookmark article"
          >
            <Icon name="Bookmark" size={16} className="text-muted-foreground" />
          </button>
          
          <button
            className="p-2 rounded-md hover-ambient transition-smooth press-feedback"
            aria-label="Share article"
          >
            <Icon name="Share" size={16} className="text-muted-foreground" />
          </button>
          
          <div className="h-4 w-px bg-border" />
          
          <button
            className="p-2 rounded-md hover-ambient transition-smooth press-feedback"
            aria-label="More options"
          >
            <Icon name="MoreHorizontal" size={16} className="text-muted-foreground" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NavigationProgressIndicator;