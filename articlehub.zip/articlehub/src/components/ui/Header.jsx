import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';
import UserMenuDropdown from './UserMenuDropdown';
import SearchInterface from './SearchInterface';

const Header = ({ currentUser = null, onNavigate }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const navigationItems = [
    { label: 'Home', path: '/article-feed-home', icon: 'Home' },
    { label: 'Write', path: '/article-editor', icon: 'PenTool' },
    { label: 'Search', path: '/search-results', icon: 'Search' },
    { label: 'Profile', path: '/user-profile', icon: 'User', authRequired: true },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigation = (path) => {
    if (onNavigate) {
      onNavigate(path);
    } else {
      navigate(path);
    }
    setIsMobileMenuOpen(false);
  };

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  const filteredNavItems = navigationItems?.filter(item => 
    !item?.authRequired || currentUser
  );

  return (
    <header className={`sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 transition-smooth ${
      isScrolled ? 'elevation-1' : ''
    }`}>
      <div className="container flex h-16 items-center justify-between px-4 lg:px-6">
        {/* Logo */}
        <div className="flex items-center">
          <button
            onClick={() => handleNavigation('/article-feed-home')}
            className="flex items-center space-x-2 hover-ambient rounded-md px-2 py-1 transition-smooth"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Icon name="BookOpen" size={20} />
            </div>
            <span className="font-heading font-semibold text-xl text-foreground">
              ArticleHub
            </span>
          </button>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {filteredNavItems?.map((item) => (
            <button
              key={item?.path}
              onClick={() => handleNavigation(item?.path)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-smooth hover-ambient press-feedback ${
                isActivePath(item?.path)
                  ? 'bg-accent/10 text-accent' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name={item?.icon} size={16} />
              <span>{item?.label}</span>
            </button>
          ))}
        </nav>

        {/* Desktop Right Section */}
        <div className="hidden md:flex items-center space-x-4">
          <SearchInterface onSearch={(query) => handleNavigation(`/search-results?q=${query}`)} />
          
          {currentUser ? (
            <UserMenuDropdown 
              currentUser={currentUser} 
              onNavigate={handleNavigation}
            />
          ) : (
            <Button
              variant="outline"
              onClick={() => handleNavigation('/login-register')}
              iconName="LogIn"
              iconPosition="left"
              iconSize={16}
            >
              Sign In
            </Button>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden items-center space-x-2">
          {currentUser && (
            <UserMenuDropdown 
              currentUser={currentUser} 
              onNavigate={handleNavigation}
              isMobile={true}
            />
          )}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 rounded-md hover-ambient transition-smooth"
            aria-label="Toggle menu"
          >
            <Icon name={isMobileMenuOpen ? 'X' : 'Menu'} size={20} />
          </button>
        </div>
      </div>
      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background elevation-2">
          <nav className="container px-4 py-4 space-y-2">
            <SearchInterface 
              onSearch={(query) => {
                handleNavigation(`/search-results?q=${query}`);
                setIsMobileMenuOpen(false);
              }}
              isMobile={true}
            />
            
            {filteredNavItems?.map((item) => (
              <button
                key={item?.path}
                onClick={() => handleNavigation(item?.path)}
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-md text-left transition-smooth hover-ambient press-feedback ${
                  isActivePath(item?.path)
                    ? 'bg-accent/10 text-accent' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon name={item?.icon} size={20} />
                <span className="font-medium">{item?.label}</span>
              </button>
            ))}
            
            {!currentUser && (
              <div className="pt-4 border-t border-border">
                <Button
                  variant="outline"
                  onClick={() => handleNavigation('/login-register')}
                  iconName="LogIn"
                  iconPosition="left"
                  iconSize={16}
                  fullWidth
                >
                  Sign In
                </Button>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;