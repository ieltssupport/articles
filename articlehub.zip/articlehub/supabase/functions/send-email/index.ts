import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

// Declare Deno global for type safety
declare const Deno: {
  env: {
    get: (key: string) => string | undefined;
  };
};

serve(async (req) => {
  // CORS preflight
  if (req?.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      }
    });
  }

  try {
    const { type, to, data } = await req?.json();

    // Email templates based on type
    let subject = "";
    let html = "";

    switch (type) {
      case "welcome":
        subject = "Welcome to ArticleHub!";
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #3b82f6;">Welcome to ArticleHub!</h1>
            <p>Hi ${data?.fullName},</p>
            <p>Thank you for joining ArticleHub! We're excited to have you as part of our community of writers and readers.</p>
            <p>Start your journey by:</p>
            <ul>
              <li>Writing your first article</li>
              <li>Following interesting authors</li>
              <li>Exploring articles by category</li>
            </ul>
            <p>Happy writing!</p>
            <p>The ArticleHub Team</p>
          </div>
        `;
        break;

      case "new_article":
        subject = `New article from ${data?.authorName}: ${data?.articleTitle}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #3b82f6;">New Article Published!</h1>
            <p>Hi there,</p>
            <p><strong>${data?.authorName}</strong> has published a new article that you might be interested in:</p>
            <h2>${data?.articleTitle}</h2>
            <p>${data?.articleExcerpt}</p>
            <a href="${data?.articleUrl}" style="display: inline-block; background-color: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0;">Read Article</a>
            <p>Happy reading!</p>
            <p>The ArticleHub Team</p>
          </div>
        `;
        break;

      case "new_comment":
        subject = `New comment on your article: ${data?.articleTitle}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #3b82f6;">New Comment!</h1>
            <p>Hi ${data?.authorName},</p>
            <p><strong>${data?.commenterName}</strong> left a comment on your article:</p>
            <h3>${data?.articleTitle}</h3>
            <blockquote style="border-left: 4px solid #3b82f6; margin: 20px 0; padding-left: 20px; color: #666;">
              "${data?.commentContent}"
            </blockquote>
            <a href="${data?.articleUrl}#comments" style="display: inline-block; background-color: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0;">View Comment</a>
            <p>Keep the conversation going!</p>
            <p>The ArticleHub Team</p>
          </div>
        `;
        break;

      case "new_follower":
        subject = `${data?.followerName} is now following you on ArticleHub`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #3b82f6;">You have a new follower!</h1>
            <p>Hi ${data?.authorName},</p>
            <p><strong>${data?.followerName}</strong> (@${data?.followerUsername}) is now following you on ArticleHub!</p>
            <p>This means they'll be notified when you publish new articles. Keep up the great work!</p>
            <a href="${data?.profileUrl}" style="display: inline-block; background-color: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0;">View Profile</a>
            <p>Happy writing!</p>
            <p>The ArticleHub Team</p>
          </div>
        `;
        break;

      default:
        throw new Error("Unknown email type");
    }

    // Send email using Resend API
    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${Deno.env.get("RESEND_API_KEY")}`,
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: [to],
        subject: subject,
        html: html,
      }),
    });

    if (!resendResponse?.ok) {
      const error = await resendResponse?.text();
      throw new Error(`Resend API error: ${error}`);
    }

    const result = await resendResponse?.json();

    return new Response(JSON.stringify({
      success: true,
      messageId: result.id
    }), {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });

  } catch (error) {
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
});