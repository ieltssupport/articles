-- Location: supabase/migrations/20250809215411_articlehub_complete_schema.sql
-- Schema Analysis: Fresh Supabase project with no existing schema
-- Integration Type: Complete new system creation
-- Dependencies: None - creating complete ArticleHub schema

-- 1. Extensions & Types
CREATE TYPE public.user_role AS ENUM ('admin', 'moderator', 'author', 'reader');
CREATE TYPE public.article_status AS ENUM ('draft', 'scheduled', 'published', 'archived', 'removed');
CREATE TYPE public.comment_status AS ENUM ('visible', 'hidden', 'removed');
CREATE TYPE public.report_status AS ENUM ('pending', 'reviewed', 'resolved', 'dismissed');
CREATE TYPE public.notification_type AS ENUM ('new_article', 'new_comment', 'new_follower', 'article_liked', 'comment_reply', 'system');

-- 2. Core User Table (Intermediary for PostgREST compatibility)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    username TEXT UNIQUE,
    bio TEXT,
    avatar_url TEXT,
    website_url TEXT,
    twitter_handle TEXT,
    linkedin_url TEXT,
    role public.user_role DEFAULT 'reader'::public.user_role,
    is_active BOOLEAN DEFAULT true,
    email_notifications BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Categories
CREATE TABLE public.categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    description TEXT,
    color TEXT DEFAULT '#6366f1',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Tags
CREATE TABLE public.tags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Articles
CREATE TABLE public.articles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    subtitle TEXT,
    content JSONB NOT NULL,
    html_content TEXT,
    excerpt TEXT,
    cover_image_url TEXT,
    category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
    status public.article_status DEFAULT 'draft'::public.article_status,
    is_featured BOOLEAN DEFAULT false,
    reading_time INTEGER DEFAULT 0,
    views_count INTEGER DEFAULT 0,
    likes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    published_at TIMESTAMPTZ,
    scheduled_for TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. Article Tags Junction Table
CREATE TABLE public.article_tags (
    article_id UUID REFERENCES public.articles(id) ON DELETE CASCADE,
    tag_id UUID REFERENCES public.tags(id) ON DELETE CASCADE,
    PRIMARY KEY (article_id, tag_id)
);

-- 7. Comments
CREATE TABLE public.comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    article_id UUID NOT NULL REFERENCES public.articles(id) ON DELETE CASCADE,
    author_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    parent_comment_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    status public.comment_status DEFAULT 'visible'::public.comment_status,
    likes_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. Likes
CREATE TABLE public.likes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    article_id UUID REFERENCES public.articles(id) ON DELETE CASCADE,
    comment_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CHECK ((article_id IS NOT NULL) != (comment_id IS NOT NULL))
);

-- 9. Bookmarks
CREATE TABLE public.bookmarks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    article_id UUID NOT NULL REFERENCES public.articles(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, article_id)
);

-- 10. Follows
CREATE TABLE public.follows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    follower_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    following_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(follower_id, following_id),
    CHECK (follower_id != following_id)
);

-- 11. Reports
CREATE TABLE public.reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    article_id UUID REFERENCES public.articles(id) ON DELETE CASCADE,
    comment_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
    reason TEXT NOT NULL,
    details TEXT,
    status public.report_status DEFAULT 'pending'::public.report_status,
    reviewed_by UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    reviewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CHECK ((article_id IS NOT NULL) != (comment_id IS NOT NULL))
);

-- 12. Notifications
CREATE TABLE public.notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    type public.notification_type NOT NULL,
    title TEXT NOT NULL,
    message TEXT,
    data JSONB,
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 13. Essential Indexes
CREATE INDEX idx_user_profiles_username ON public.user_profiles(username);
CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_categories_slug ON public.categories(slug);
CREATE INDEX idx_tags_slug ON public.tags(slug);
CREATE INDEX idx_articles_author_id ON public.articles(author_id);
CREATE INDEX idx_articles_slug ON public.articles(slug);
CREATE INDEX idx_articles_category_id ON public.articles(category_id);
CREATE INDEX idx_articles_status ON public.articles(status);
CREATE INDEX idx_articles_published_at ON public.articles(published_at);
CREATE INDEX idx_articles_created_at ON public.articles(created_at);
CREATE INDEX idx_comments_article_id ON public.comments(article_id);
CREATE INDEX idx_comments_author_id ON public.comments(author_id);
CREATE INDEX idx_comments_parent_comment_id ON public.comments(parent_comment_id);
CREATE INDEX idx_likes_user_id ON public.likes(user_id);
CREATE INDEX idx_likes_article_id ON public.likes(article_id);
CREATE INDEX idx_likes_comment_id ON public.likes(comment_id);
CREATE INDEX idx_bookmarks_user_id ON public.bookmarks(user_id);
CREATE INDEX idx_bookmarks_article_id ON public.bookmarks(article_id);
CREATE INDEX idx_follows_follower_id ON public.follows(follower_id);
CREATE INDEX idx_follows_following_id ON public.follows(following_id);
CREATE INDEX idx_reports_status ON public.reports(status);
CREATE INDEX idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX idx_notifications_is_read ON public.notifications(is_read);

-- 14. Enable RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.article_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- 15. Helper Functions (Created BEFORE RLS policies)
CREATE OR REPLACE FUNCTION public.is_admin_from_auth()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' = 'admin' 
         OR au.raw_app_meta_data->>'role' = 'admin')
)
$$;

CREATE OR REPLACE FUNCTION public.is_moderator_or_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    WHERE up.id = auth.uid() 
    AND up.role IN ('admin', 'moderator')
)
$$;

CREATE OR REPLACE FUNCTION public.can_moderate_content(content_author_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT (
    auth.uid() = content_author_id OR
    EXISTS (
        SELECT 1 FROM public.user_profiles up
        WHERE up.id = auth.uid() 
        AND up.role IN ('admin', 'moderator')
    )
)
$$;

-- 16. RLS Policies
-- Pattern 1: Core User Tables - user_profiles (simple ownership)
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Public read for user profiles (for author information)
CREATE POLICY "public_can_read_user_profiles"
ON public.user_profiles
FOR SELECT
TO public
USING (true);

-- Pattern 4: Categories and Tags - Public read, admin write
CREATE POLICY "public_can_read_categories"
ON public.categories
FOR SELECT
TO public
USING (true);

CREATE POLICY "admin_manage_categories"
ON public.categories
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

CREATE POLICY "public_can_read_tags"
ON public.tags
FOR SELECT
TO public
USING (true);

CREATE POLICY "admin_manage_tags"
ON public.tags
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- Pattern 4: Articles - Public read published, author manage own
CREATE POLICY "public_can_read_published_articles"
ON public.articles
FOR SELECT
TO public
USING (status = 'published'::public.article_status);

CREATE POLICY "authors_manage_own_articles"
ON public.articles
FOR ALL
TO authenticated
USING (author_id = auth.uid())
WITH CHECK (author_id = auth.uid());

CREATE POLICY "moderators_manage_articles"
ON public.articles
FOR UPDATE, DELETE
TO authenticated
USING (public.is_moderator_or_admin());

-- Pattern 2: Article Tags - Simple ownership through article
CREATE POLICY "article_tags_match_article_access"
ON public.article_tags
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.articles a 
        WHERE a.id = article_id 
        AND a.author_id = auth.uid()
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.articles a 
        WHERE a.id = article_id 
        AND a.author_id = auth.uid()
    )
);

-- Public read for published article tags
CREATE POLICY "public_can_read_article_tags"
ON public.article_tags
FOR SELECT
TO public
USING (
    EXISTS (
        SELECT 1 FROM public.articles a 
        WHERE a.id = article_id 
        AND a.status = 'published'::public.article_status
    )
);

-- Pattern 4: Comments - Public read, user manage own
CREATE POLICY "public_can_read_comments"
ON public.comments
FOR SELECT
TO public
USING (status = 'visible'::public.comment_status);

CREATE POLICY "users_manage_own_comments"
ON public.comments
FOR ALL
TO authenticated
USING (author_id = auth.uid())
WITH CHECK (author_id = auth.uid());

CREATE POLICY "moderators_manage_comments"
ON public.comments
FOR UPDATE, DELETE
TO authenticated
USING (public.is_moderator_or_admin());

-- Pattern 2: Likes - Simple user ownership
CREATE POLICY "users_manage_own_likes"
ON public.likes
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "public_can_read_likes"
ON public.likes
FOR SELECT
TO public
USING (true);

-- Pattern 2: Bookmarks - Simple user ownership
CREATE POLICY "users_manage_own_bookmarks"
ON public.bookmarks
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 2: Follows - Simple user ownership
CREATE POLICY "users_manage_own_follows"
ON public.follows
FOR ALL
TO authenticated
USING (follower_id = auth.uid())
WITH CHECK (follower_id = auth.uid());

CREATE POLICY "public_can_read_follows"
ON public.follows
FOR SELECT
TO public
USING (true);

-- Pattern 2: Reports - User manage own, moderators see all
CREATE POLICY "users_manage_own_reports"
ON public.reports
FOR INSERT, SELECT
TO authenticated
USING (reporter_id = auth.uid())
WITH CHECK (reporter_id = auth.uid());

CREATE POLICY "moderators_manage_reports"
ON public.reports
FOR ALL
TO authenticated
USING (public.is_moderator_or_admin())
WITH CHECK (public.is_moderator_or_admin());

-- Pattern 2: Notifications - Simple user ownership
CREATE POLICY "users_manage_own_notifications"
ON public.notifications
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 17. Functions for automatic profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, full_name, username, role)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'reader')::public.user_role
  );
  RETURN NEW;
END;
$$;

-- 18. Trigger for new user creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 19. Storage buckets for article images and user avatars
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
    ('article-images', 'article-images', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']),
    ('user-avatars', 'user-avatars', true, 2097152, ARRAY['image/jpeg', 'image/png', 'image/webp']);

-- 20. Storage RLS policies
-- Article images - public read, authenticated upload
CREATE POLICY "public_can_view_article_images"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'article-images');

CREATE POLICY "authenticated_users_upload_article_images"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'article-images');

CREATE POLICY "users_manage_own_article_images"
ON storage.objects
FOR UPDATE, DELETE
TO authenticated
USING (bucket_id = 'article-images' AND owner = auth.uid());

-- User avatars - public read, users manage own
CREATE POLICY "public_can_view_user_avatars"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'user-avatars');

CREATE POLICY "users_upload_own_avatars"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'user-avatars' 
    AND owner = auth.uid()
    AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "users_manage_own_avatars"
ON storage.objects
FOR UPDATE, DELETE
TO authenticated
USING (bucket_id = 'user-avatars' AND owner = auth.uid());

-- 21. Mock Data
DO $$
DECLARE
    admin_uuid UUID := gen_random_uuid();
    author_uuid UUID := gen_random_uuid();
    reader_uuid UUID := gen_random_uuid();
    tech_category_id UUID := gen_random_uuid();
    lifestyle_category_id UUID := gen_random_uuid();
    javascript_tag_id UUID := gen_random_uuid();
    react_tag_id UUID := gen_random_uuid();
    wellness_tag_id UUID := gen_random_uuid();
    article1_id UUID := gen_random_uuid();
    article2_id UUID := gen_random_uuid();
    article3_id UUID := gen_random_uuid();
BEGIN
    -- Create auth users with required fields
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (admin_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@articlehub.com', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Admin User", "role": "admin", "username": "admin"}'::jsonb, 
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (author_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'john@articlehub.com', crypt('author123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "John Smith", "role": "author", "username": "johnsmith"}'::jsonb, 
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (reader_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'reader@articlehub.com', crypt('reader123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Sarah Johnson", "role": "reader", "username": "sarahjohnson"}'::jsonb, 
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Categories
    INSERT INTO public.categories (id, name, slug, description, color) VALUES
        (tech_category_id, 'Technology', 'technology', 'Latest trends in technology and programming', '#3b82f6'),
        (lifestyle_category_id, 'Lifestyle', 'lifestyle', 'Health, wellness, and lifestyle tips', '#10b981');

    -- Tags
    INSERT INTO public.tags (id, name, slug) VALUES
        (javascript_tag_id, 'JavaScript', 'javascript'),
        (react_tag_id, 'React', 'react'),
        (wellness_tag_id, 'Wellness', 'wellness');

    -- Articles
    INSERT INTO public.articles (
        id, author_id, title, slug, subtitle, content, html_content, excerpt, 
        category_id, status, reading_time, views_count, likes_count, published_at
    ) VALUES
        (article1_id, author_uuid, 'Getting Started with React Hooks', 'getting-started-with-react-hooks',
         'A comprehensive guide to modern React development', 
         '{"type": "doc", "content": [{"type": "heading", "attrs": {"level": 1}, "content": [{"type": "text", "text": "Getting Started with React Hooks"}]}, {"type": "paragraph", "content": [{"type": "text", "text": "React Hooks revolutionized how we write React components. In this comprehensive guide, we will explore the most important hooks and how to use them effectively in your applications."}]}]}'::jsonb,
         '<h1>Getting Started with React Hooks</h1><p>React Hooks revolutionized how we write React components. In this comprehensive guide, we will explore the most important hooks and how to use them effectively in your applications.</p>',
         'Learn how to use React Hooks to build better components with cleaner, more maintainable code.',
         tech_category_id, 'published'::public.article_status, 5, 150, 12, now()),
        (article2_id, author_uuid, 'Building a Modern Website Architecture', 'building-modern-website-architecture',
         'Best practices for scalable web development', 
         '{"type": "doc", "content": [{"type": "heading", "attrs": {"level": 1}, "content": [{"type": "text", "text": "Building a Modern Website Architecture"}]}, {"type": "paragraph", "content": [{"type": "text", "text": "Modern web development requires careful planning and architecture decisions. This article covers the essential patterns and technologies you need to know."}]}]}'::jsonb,
         '<h1>Building a Modern Website Architecture</h1><p>Modern web development requires careful planning and architecture decisions. This article covers the essential patterns and technologies you need to know.</p>',
         'Discover the key principles and technologies for building scalable modern web applications.',
         tech_category_id, 'published'::public.article_status, 8, 230, 18, now()),
        (article3_id, admin_uuid, 'The Art of Mindful Living', 'the-art-of-mindful-living',
         'Finding balance in our digital age', 
         '{"type": "doc", "content": [{"type": "heading", "attrs": {"level": 1}, "content": [{"type": "text", "text": "The Art of Mindful Living"}]}, {"type": "paragraph", "content": [{"type": "text", "text": "In our fast-paced digital world, finding moments of mindfulness has become more important than ever. Learn practical techniques to incorporate mindfulness into your daily routine."}]}]}'::jsonb,
         '<h1>The Art of Mindful Living</h1><p>In our fast-paced digital world, finding moments of mindfulness has become more important than ever. Learn practical techniques to incorporate mindfulness into your daily routine.</p>',
         'Discover practical mindfulness techniques to improve your well-being and find balance in daily life.',
         lifestyle_category_id, 'published'::public.article_status, 6, 95, 8, now());

    -- Article Tags
    INSERT INTO public.article_tags (article_id, tag_id) VALUES
        (article1_id, javascript_tag_id),
        (article1_id, react_tag_id),
        (article2_id, javascript_tag_id),
        (article3_id, wellness_tag_id);

    -- Comments
    INSERT INTO public.comments (article_id, author_id, content) VALUES
        (article1_id, reader_uuid, 'Great explanation of React Hooks! This really helped me understand useState better.'),
        (article2_id, reader_uuid, 'Very comprehensive guide. The architecture patterns you mentioned are really useful for large projects.'),
        (article3_id, author_uuid, 'Love this approach to mindfulness. I have been trying to implement some of these techniques in my daily routine.');

    -- Follows
    INSERT INTO public.follows (follower_id, following_id) VALUES
        (reader_uuid, author_uuid),
        (reader_uuid, admin_uuid);

    -- Bookmarks
    INSERT INTO public.bookmarks (user_id, article_id) VALUES
        (reader_uuid, article1_id),
        (reader_uuid, article3_id);

    -- Likes
    INSERT INTO public.likes (user_id, article_id) VALUES
        (reader_uuid, article1_id),
        (reader_uuid, article2_id),
        (author_uuid, article3_id);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error: %', SQLERRM;
END $$;

-- 22. Cleanup function for development
CREATE OR REPLACE FUNCTION public.cleanup_articlehub_test_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    auth_user_ids_to_delete UUID[];
BEGIN
    -- Get auth user IDs first
    SELECT ARRAY_AGG(id) INTO auth_user_ids_to_delete
    FROM auth.users
    WHERE email LIKE '%@articlehub.com';

    -- Delete in dependency order (children first)
    DELETE FROM public.article_tags WHERE article_id IN (
        SELECT id FROM public.articles WHERE author_id = ANY(auth_user_ids_to_delete)
    );
    DELETE FROM public.notifications WHERE user_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.reports WHERE reporter_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.follows WHERE follower_id = ANY(auth_user_ids_to_delete) OR following_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.bookmarks WHERE user_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.likes WHERE user_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.comments WHERE author_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.articles WHERE author_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.categories WHERE name IN ('Technology', 'Lifestyle');
    DELETE FROM public.tags WHERE name IN ('JavaScript', 'React', 'Wellness');
    DELETE FROM public.user_profiles WHERE id = ANY(auth_user_ids_to_delete);

    -- Delete auth.users last (after all references are removed)
    DELETE FROM auth.users WHERE id = ANY(auth_user_ids_to_delete);
EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key constraint prevents deletion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END $$;